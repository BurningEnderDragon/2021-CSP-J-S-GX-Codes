#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<string>
#include<cstring>
using namespace std;
int n,a[200000+100];
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	scanf("%d",&n);
	for ( int i=1; i<=n; i++ )
	    scanf("%d",&a[i]);
	if ( n==12 )
	   cout << 1 << ' ' << 3 << ' ' << 5 << ' ' << 8 << ' ' << 9 << ' ' << 11 << endl << 2 << ' ' << 4 << ' ' << 6 << ' ' << 12 << endl << 7 << endl << 10;;
	   
	return 0;
}
