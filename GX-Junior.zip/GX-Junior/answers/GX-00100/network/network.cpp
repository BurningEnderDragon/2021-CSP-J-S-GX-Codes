#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<string>
#include<cstring>
using namespace std;
int n,sum,num;
string op,ad;
struct lnm
{
	int a,b,c,d,e,bh,flag;
	string dz;
}fw[1000+100];
struct dylnm
{
	int a,b,c,d,e,flag;
	string dz;
}kh[1000+100];
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	cin >> n;
	for ( int i=1; i<=n; i++ )
	{
	    cin >> op >> ad;
	    if ( op=="Server" )
	    {
			int f=1;
			sum++;
			fw[sum].bh=sum;
			fw[sum].dz=ad;
			int len=ad.size(),dh=0,mh=0;
			for ( int j=0; j<len; j++ )
			{
				if ( ad[j]=='.' )
				{
					if ( f==1 && (fw[sum].a<0 || fw[sum].a>255) )
					{
						fw[sum].flag=1;
						cout << "ERR" << endl;
						break;
					}
					if ( f==2 && (fw[sum].b<0 || fw[sum].b>255) )
					{
						fw[sum].flag=1;
						cout << "ERR" << endl;
						break;
					}
					if ( f==3 && (fw[sum].c<0 || fw[sum].c>255) )
					{ 
						fw[sum].flag=1;
						cout << "ERR" << endl;
						break;
					}
					if ( f==4 && (fw[sum].d<0 || fw[sum].d>255) )
					{
						fw[sum].flag=1;
						cout << "ERR" << endl;
						break;
					}
					if ( f==5 && (fw[sum].e<0 || fw[sum].e>65535) )
					{
						fw[sum].flag=1;
						cout << "ERR" << endl;
						break;
					}
					dh++;
					f++;
					if ( dh>3 )
					{
						fw[sum].flag=1;
						cout << "ERR" << endl;
						break;
					}
				}
				else
				{
				   if ( ad[j]==':' )
				   {
					   if ( f==1 && (fw[sum].a<0 || fw[sum].a>255) )
					   {
						    fw[sum].flag=1;
					    	cout << "ERR" << endl;
						    break;
					   }
					   if ( f==2 && (fw[sum].b<0 || fw[sum].b>255) )
					   {
						    fw[sum].flag=1;
						    cout << "ERR" << endl;
						    break;
					   }
					   if ( f==3 && (fw[sum].c<0 || fw[sum].c>255) )
					   {
						    fw[sum].flag=1;
						    cout << "ERR" << endl;
						    break;
					   }
					   if ( f==4 && (fw[sum].d<0 || fw[sum].d>255) )
					   {
						    fw[sum].flag=1;
					    	cout << "ERR" << endl;
					    	break;
					   }
					   if ( f==5 && (fw[sum].e<0 || fw[sum].e>65535) )
					   {
						    fw[sum].flag=1;
						    cout << "ERR" << endl;
						    break;
					   }
					   mh++;
					   f++;
					   if ( mh>1 )
					   {
						   fw[sum].flag=1;
						   cout << "ERR" << endl;
						   break;
					   }
				   }
				   else
				   {
					   if ( ad[j]=='0' && ad[j+1]>='0' && ad[j+1]<='9' )
					   {
						   fw[sum].flag=1;
						   cout << "ERR" << endl;
						   break;
					   }
					   else
					   {
						   if ( f==1 )
						      fw[sum].a=fw[sum].a*10+(ad[j]-'0');
						   if ( f==2 )
						      fw[sum].b=fw[sum].b*10+(ad[j]-'0');
						   if ( f==3 )
						      fw[sum].c=fw[sum].c*10+(ad[j]-'0');
						   if ( f==4 )
						      fw[sum].d=fw[sum].d*10+(ad[j]-'0');
						   if ( f==5 )
						      fw[sum].e=fw[sum].e*10+(ad[j]-'0');
					   }
				   }
			    }
			}
			if ( fw[sum].flag==1 )
			   continue;
			for ( int j=1; j<sum; j++ )
			{
				if ( fw[j].dz==fw[sum].dz )
				{
					fw[sum].flag=1;
					cout << "FAIL" << endl;
					break;
				}
			}
			if ( fw[sum].flag==0 )
			   cout << "OK" << endl;
		}
		if ( op=="Client" )
		{
			num++;
			kh[num].dz=ad;
			int len=ad.size(),dh=0,mh=0,f=1;
			for ( int j=0; j<len; j++ )
			{
				if ( ad[j]=='.' )
				{
					if ( f==1 && (kh[num].a<0 || kh[num].a>255) )
					{
						kh[num].flag=1;
						cout << "ERR" << endl;
						break;
					}
					if ( f==2 && (kh[num].b<0 || kh[num].b>255) )
					{
						kh[num].flag=1;
						cout << "ERR" << endl;
						break;
					}
					if ( f==3 && (kh[num].c<0 || kh[num].c>255) )
					{
						kh[num].flag=1;
						cout << "ERR" << endl;
						break;
					}
					if ( f==4 && (kh[num].d<0 || kh[num].d>255) )
					{
						kh[num].flag=1;
						cout << "ERR" << endl;
						break;
					}
					if ( f==5 && (kh[num].e<0 || kh[num].e>65535) )
					{
						kh[num].flag=1;
						cout << "ERR" << endl;
						break;
					}
					dh++;
					f++;
					if ( dh>3 )
					{
						kh[num].flag=1;
						cout << "ERR" << endl;
						break;
					}
				}
				else
				{
				   if ( ad[j]==':' )
				   {
					   if ( f==1 && (kh[num].a<0 || kh[num].a>255) )
					   {  
						   kh[num].flag=1;
						   cout << "ERR" << endl;
						   break;
					   }
					   if ( f==2 && (kh[num].b<0 || kh[num].b>255) )
					   {
						   kh[num].flag=1;
					       cout << "ERR" << endl;
						   break;
					   }
					   if ( f==3 && (kh[num].c<0 || kh[num].c>255) )
					   {
						   kh[num].flag=1;
						   cout << "ERR" << endl;
						   break;
					   }
					   if ( f==4 && (kh[num].d<0 || kh[num].d>255) )
					   {
						   kh[num].flag=1;
						   cout << "ERR" << endl;
						   break;
					   }
					   if ( f==5 && (kh[num].e<0 || kh[num].e>65535) )
					   {
						   kh[num].flag=1;
						   cout << "ERR" << endl;
						   break;
					   }
					   mh++;
					   f++;
					   if ( mh>1 )
					   {
						   kh[num].flag=1;
						   cout << "ERR" << endl;
						   break;
					   }
				   }
				   else
				   {
					   if ( ad[j]=='0' && ad[j+1]>='0' && ad[j+1]<='9' )
					   {
						   kh[num].flag=1;
						   cout << "ERR" << endl;
						   break;
					   }
					   else
					   {
						   if ( f==1 )
						      kh[num].a=kh[num].a*10+(ad[j]-'0');
						   if ( f==2 )
						      kh[num].b=kh[num].b*10+(ad[j]-'0');
						   if ( f==3 )
						      kh[num].c=kh[num].c*10+(ad[j]-'0');
						   if ( f==4 )
						      kh[num].d=kh[num].d*10+(ad[j]-'0');
						   if ( f==5 )
						      kh[num].e=kh[num].e*10+(ad[j]-'0');
					   }
				   }
			    }
			}
			if ( kh[num].flag==1 )
			   continue;
			kh[num].flag=1;
			for ( int j=1; j<=sum; j++ )
			{
				if ( fw[j].flag==0 && fw[j].dz==kh[num].dz )
				{
					kh[num].flag=0;
					cout << j << endl;
					break;
				}
			}
			if ( kh[num].flag==1 )
			   cout << "FAIL" << endl;
		}
	}
	return 0;
}
