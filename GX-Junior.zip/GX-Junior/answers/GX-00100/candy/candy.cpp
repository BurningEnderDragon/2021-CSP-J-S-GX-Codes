#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<string>
#include<cstring>
using namespace std;
int n,l,r,ans,sum;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin >> n >> l >> r;
	while ( 1 )
	{
		sum++;
		ans=sum*n;
		if ( ans>=l && ans<=r )
		{
		   ans-=1;
		   sum-=1;
	       ans=ans-(sum*n);
	       cout << ans;
	       return 0;
		}
		if ( ans > r )
		{
			ans=r;
			sum-=1;
	        ans=ans-(sum*n);
	        cout << ans;
	        return 0;
		}
	}
	return 0;
}
