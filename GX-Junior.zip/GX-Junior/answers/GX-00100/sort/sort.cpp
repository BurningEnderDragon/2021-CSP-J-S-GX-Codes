#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<string>
#include<cstring>
using namespace std;
int n,q,sum,x,v,b[8000+100];
struct lnm
{
	int s,ff=0,h;
}a[8000+100];
bool cmp( lnm a,lnm b )
{
	if ( a.s==b.s )
	   return a.h<b.h;
	else
	   return a.s<b.s;
}
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	cin >> n >> q;
	for ( int i=1; i<=n; i++ )
	{
	    cin >> a[i].s;
	    b[i]=a[i].s;
	    a[i].h=i;
	}
	for ( int i=1; i<=q; i++ )
	{
		cin >> sum;
		if ( sum==1 )
		{
			cin >> x >> v;
			a[x].s=v;
			b[x]=v;
		}
		if ( sum==2 )
		{
			cin >> x;
			a[x].ff=1;
			sort(a+1,a+1+n,cmp);
			for ( int j=1; j<=n; j++ )
			{
				a[j].h=j;
				if ( a[j].ff==1 )
				   cout << a[j].h << endl;
				a[j].ff=0;
				a[j].s=b[j];
			}
		}
	}
	return 0;
}
