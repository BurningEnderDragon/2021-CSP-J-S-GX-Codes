#include<algorithm>
#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
int n,a,b,sum,s[10000],maxx;
int main()
{
  freopen("candy.in","r",stdin);
  freopen("candy.out","w",stdout);
  cin>>n>>a>>b;
  sum=a;
  for(int i=1;i<=n;i++)
  {
	  for(int j=1;j<=n+1;j++)
	  {
	    for(int k=1;k<=n;k++)
	  {
		  if(sum>=n && sum<=b)
	        sum=sum-n;
	  }	
	  s[i]=sum;
	  if(a<b)
	    sum=a+1;
    }
	  maxx=max(s[i],s[i]+1);
  }
  cout<<maxx;
  return 0;
}
