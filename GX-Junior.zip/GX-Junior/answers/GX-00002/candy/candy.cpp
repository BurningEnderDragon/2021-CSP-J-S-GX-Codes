#include<bits/stdc++.h>
using namespace std;
long long n,l,r,maxx=-1;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    cin>>n>>l>>r;
    for(int i=l;i<=r;i++)
    {
        maxx=max(maxx,i%n);
    }
    cout<<maxx;
    return 0;
}
