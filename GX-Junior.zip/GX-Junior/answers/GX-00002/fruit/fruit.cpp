#include<bits/stdc++.h>
using namespace std;
long long n,a[100001],m,s,b[100001];
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
        b[i]=i;
    }
    m=a[1];
    do
    {
        m=a[1];
        for(int i=1;i<=n;i++)
        {
            if(i==1)
            {
                m=a[i];
                cout<<b[i]<<" ";
                for(int l=2;l<=n;l++)
                {
                    a[l-1]=a[l];
                    b[l-1]=b[l];
                }
                n--;
            }
            if(a[i]!=m)
            {
                m=a[i];
                cout<<b[i]<<" ";
                for(int l=i+1;l<=n;l++)
                {
                    a[l-1]=a[l];
                    b[l-1]=b[l];
                }
                n--;
                i--;
            }
        }
        cout<<endl;
    }while(n!=0);
    return 0;
}
