#include<iostream>
using namespace std;
int main() {
    int n,L,R;
    freopen("candy.in","r",stdin);
    freoprn("candy.out","w",stdout);
    if(n<=2){
        for(int i = L;i >=n;i--){
            for(int j = R;j<=L;j--){
                if(j>i){
                    cout<<j<<endl;
                }else{
                    cout<<i<<endl;
                }
            }
        }
    }
    return 0;
}
