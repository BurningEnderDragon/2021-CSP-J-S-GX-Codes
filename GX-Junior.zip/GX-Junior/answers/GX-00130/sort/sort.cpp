#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int n,q;
struct student
{
    int ans,start;
}a[8010];
int t,x,v;
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++)
	{
	  scanf("%d",&a[i].ans);
	  a[i].start=i;
	}
	for(int i=1;i<=n;i++)
      for(int j=i;j>=2;j--)
        if(a[j].ans<a[j-1].ans)
        {
		  swap(a[j].ans,a[j-1].ans);
		  swap(a[j].start,a[j-1].start);
	    }
	for(int i=1;i<=q;i++)
	{
	  scanf("%d",&t);
	  if(t==1)
	  {
	    scanf("%d%d",&x,&v);
	    for(int j=1;i<=n;j++)
	      if(a[j].start==x)
	      {
	        a[j].ans=v;
	        break;
	      }
	    for(int j=1;j<=n;j++)
          for(int k=j;k>=2;k--)
            if(a[k].ans<a[k-1].ans)
            {
				swap(a[k].ans,a[k-1].ans);
				swap(a[k].start,a[k-1].start);
			}
	  }
	  if(t==2)
	  {
		scanf("%d",&x);
		for(int j=1;j<=n;j++)
		  if(a[j].start==x)
		  {
		    printf("%d\n",j);
		    break;
		  }
	  }
	}
	return 0;
}
