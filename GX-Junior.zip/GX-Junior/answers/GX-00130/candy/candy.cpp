#include<iostream>
#include<cstdio>
using namespace std;
long long n,l,r;
long long ans;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%lld%lld%lld",&n,&l,&r);
	ans=r-l;
	l%=n;
	r%=n;
	if(n-1-l<ans) printf("%lld",n-1);
	else printf("%lld",r);
	return 0;
}
