#include <bits/stdc++.h>

using namespace std;

int main()
{
    frepoen("sort.in","r",stdin);
    frepoen("sort.out","w",stdout);
    return 0;
}
