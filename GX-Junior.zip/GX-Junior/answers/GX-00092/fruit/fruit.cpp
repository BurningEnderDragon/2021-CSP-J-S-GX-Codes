#include <bits/stdc++.h>

using namespace std;

int main()
{
    frepoen("furit.in","r",stdin);
    frepoen("furit.out","w",stdout);
    return 0;
}
