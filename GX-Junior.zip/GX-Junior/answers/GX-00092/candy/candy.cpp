#include <bits/stdc++.h>

using namespace std;

int main()
{
    frepoen("candy.in","r",stdin);
    frepoen("candy.out","w",stdout);
    int n,l,r,k;
    cin>>n>>l>>r;
    return 0;
}
