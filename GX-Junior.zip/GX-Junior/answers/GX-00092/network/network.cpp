#include <bits/stdc++.h>

using namespace std;

int main()
{
    frepoen("network.in","r",stdin);
    frepoen("network.out","w",stdout);
    return 0;
}
