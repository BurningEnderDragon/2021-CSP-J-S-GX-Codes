#include<iostream>
#include<cstdio>
#include<iomanip>
#include<cmath>
#include<algorithm>
#include<string>
#include<map>
using namespace std;

int n[10000+10],q[10000+10];
long long int a[10000000000+10];
int main()
{
	freopen("sort1.in","r",stdin);
	freopen("sort.out","w",stdout);

	while(cin>> n>> q)
	{
		for(int i=1;i<=n[i];i++)
	}
	return 0;
}

