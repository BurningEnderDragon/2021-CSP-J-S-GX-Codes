#include<iostream>
#include<cstdio>
#include<iomanip>
#include<cmath>
#include<algorithm>
#include<string>
#include<map>
#include<set>
#include<iomanip>
#include<queue>
using namespace std;

long long n,l,r,ans,k,q;
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);

	cin>> n>> l>> r;
	if(n<l) k=l;
	else
		if(n>=l) k=n;
	for(long long i=k;i<=r;i++)
	{
		q=i;
		while(q>=n)
			q-=n;
		if(q+1==n) break;
	}
	cout<< q;
	return 0;
}

