#include<bits/stdc++.h>
using namespace std;
//int sharu(int a[]){
//    return 0;
//}
int main(){
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int n,q;
    cin>>n>>q;
    int a[n+1];
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    int lx=0;//leixing
    //int b[q+1][4];
    for(int k=1;k<=q;k++){
        cin>>lx;
        if(lx==2){
            int w;
            int b[3][n+1];
            cin>>w;
            for(int i=1;i<=n;i++){
                b[2][i]=0;
            }
            for(int i=1;i<=n;i++){
                b[1][i]=a[i];
                //b[2][i]=0;
            }
            b[2][w]=1;
            for (int i = 1; i <= n; i++){
                for (int j = i; j>=2; j--)
                    if ( b[1][j] < b[1][j-1]){
                        int t = b[1][j-1];
                        b[1][j-1] = b[1][j];
                        b[1][j] = t;
                        if(b[2][j]==1){
                            b[2][j-1]=1;
                            b[2][j]=0;
                            continue;
                        }
                        if(b[2][j-1]==1){
                            b[2][j-1]=0;
                            b[2][j]=1;
                            continue;
                        }
                    }
                }
            for(int i=1;i<=n;i++){
                 //   cout<<b[2][i];
                if(b[2][i]==1)cout<<i<<endl;
            }
            //cout<<w<<endl;
        }
        if(lx==1){
            int x,v;
            cin>>x>>v;
            a[x]=v;
            //cout<<c<<" "<<d<<endl;
        }
        lx=0;
    }

    //for (int i = 1; i <= n; i++)
    //    for (int j = i; j>=2; j--)
     //       if ( a[j] < a[j-1] ){
     //           int t = a[j-1];
     //           a[j-1] = a[j];
      //          a[j] = t;
      //  }
   // for(int i=1;i<=3;i++){
        //cout<<a[i];
   // }
    return 0;
}
