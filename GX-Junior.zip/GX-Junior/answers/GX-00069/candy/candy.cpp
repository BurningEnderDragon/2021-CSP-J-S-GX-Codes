#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);

    int n,l,r;
    cin>>n;
    cin>>l;
    cin>>r;
    int a[r-l+2]={0};
    int temp=1;
    int i=l;
    for(i;i<=r;i++){
        //cout<<i<<endl;
        a[temp]=i%n;
        temp++;
    }
    sort(a+1,a+r-l+2);
    for(int i=1;i<=r-l+1;i++){
        //cout<<a[i]<<endl;
    }
    cout<<a[r-l+1];
    return 0;
}
