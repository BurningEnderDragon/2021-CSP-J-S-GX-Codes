#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int len,n;
    char op[7],ad[26];
    cin>>n;
    for(int i=1;i<=n;i++)
    {
       cin>>op>>ad;
       len=strlen(ad);
       for(int j=1;j<=n;j++)
       {
           if(op=="Server")
           {
                if(len<=21) cout<<"OK";
                else if(ad[j]!=ad[j+1]) cout<<"FAIL";
                else cout<<"ERR";
           }
           if(op=="Client")
           {
                if(ad[j]==ad[j-1]) cout<<j-1;
                else if(ad[j]!=ad[j-1]) cout<<"FAIL";
                else cout<<"ERR";
           }
        }
    }
    return 0;
}
