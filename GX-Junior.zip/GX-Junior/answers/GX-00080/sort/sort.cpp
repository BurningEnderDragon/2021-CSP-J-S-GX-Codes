#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);

    return 0;
}
