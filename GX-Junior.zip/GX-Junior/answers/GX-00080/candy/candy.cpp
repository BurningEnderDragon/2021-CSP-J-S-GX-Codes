#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    long long n,r,l,a,b,c;
    cin>>n>>l>>r;
    a=l-(l/n)*n;
    b=r-l;
    c=a+b;
    for(long long i=0;i<b;i++)
    {
        if(c==n-1||c<n)
        {
            cout<<c;
            break;
        }
        else if(c>n-1) c-=1;
    }
    return 0;
}
