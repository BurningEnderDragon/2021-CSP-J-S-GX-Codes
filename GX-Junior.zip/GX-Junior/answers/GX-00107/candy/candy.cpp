#include <iostream>
#include <cstdio>
using namespace std;
it main(){
  int n,L,R,a,k,b;
  freopen("candy.in","r",stdin);
  freopen("candy.out","r"stdout);
  scanf("%d %d %d",&n,&L,&R);
  for (a=2;a<=1000000000;a++){
	  if (k-n<n)  printf("%d",k-n);
	  else b=k-n {
		  if (b-n<n) printf("%d",b-n);
		  else print("yi ci lei tui");
	  }
  }
  fclose(stdin);
  fclose(stdout);
  retrun 0;
}
