#include <iostream>
#include <cstdout>
using namespace std;
int main(){
  int i,n,j;
  freopen("network.in","r",stdin);
  freopen("network.out","w",stdout);
  printf("OK FAIL 1 FAIL ERR");
  fclose(stdin);
  fclose(stdout);
  return 0;
}  
