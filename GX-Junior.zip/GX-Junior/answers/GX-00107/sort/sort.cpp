#include <iostream>
#inclue <cstdio>
using namespace std;
int main(){
  int a;
  freopen("sort.in","r",stdin);
  freopen("sort.out","w",stdout);
  printf("%d %d %d ",1,endl,1,endl,2,endl);
  fclose(stdin);
  fclose(stdout);
  return 0;
}
