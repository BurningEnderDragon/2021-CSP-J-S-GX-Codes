#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in";"r";stdin);
    freopen("candy.out";"w";stdout);
    int n=0,L=0,R=0,k=0,b=0,a=0;
    cin>>n>>L>>R;
    k=L;
    for(int i=k;i<=R;i++)
    {
        while(1)
        {
           if(i>n)
           {
                k=i-n;
           }
           if(k<n)
           {
                b=k;
                if(b>a)
                {
                    a=b;
                }
           }
        }
    }
    cout<<a;
    return 0;
}
