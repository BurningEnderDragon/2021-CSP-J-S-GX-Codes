#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("fruit.in";"w";stdin)
    freopen("fruit.out";"r";stdout)
    int a=0,b[100000][100000],c[100000][100000],d[100000][100000],n=1;
    cin>>a;
    for(int i=1;i<=a;i++)
    {
        cin>>b[n][i];
    }
    for(int p=1;p<=a;p++)
    {
        for(int o=1;o<=a;o++)
        {
            if(b[n][o]=b[n][o+1])
            {
                cout<<o+1<<" ";
                d[n][o]=b[n][o+1];
                c[n][o]=b[n][o+1];
                b[n][o+1]=c[n][o];
                cout<<d[n][12*n+2];
            }
            if(o==12)
            {
                n=n+1;
            }
        }
    }
    return 0;
}
