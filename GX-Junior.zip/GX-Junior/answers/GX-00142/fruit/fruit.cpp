#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    long long n;
    cin>>n;
    long long work=n;
    int tist[n+2]={-1},tlst[n+2]={1},mn[n+2]={0};
    for(long long i=1;i<n+1;i++)cin>>tist[i];
    tist[n+1]=-1;
    tlst[n+1]=1;
    for(;work!=0;)
    {
        for(long long i=1;i<n+1;i++)
        {
            if(tlst[i]!=1&&tist[i]!=tist[i-1])
            {
                cout<<i<<" ";
                tlst[i]=1;
                mn[i]=1;
                work--;
            }
        }
        for(long long i=1;i<n+1;i++)
            if(mn[i]==1)
                tist[i]=-1;
        cout<<endl;
    }
    return 0;
}
