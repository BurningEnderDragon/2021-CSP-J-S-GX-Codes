#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int n,Q;
    cin>>n>>Q;
    long long a[n],tlst[n];
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
        tlst[i]=i;
    }
    for(int i=1;i<=Q;i++)
    {
        int h,b,c;
        cin>>h;
        if(h==1)
        {
            cin>>b>>c;
            a[b+1]=c;
        }
        else
        {
            cin>>b;
            for(int k=1;k<=n;k++)
            {
                for(int j=k;j>=2;j--)
                {
                    if(a[j]<a[j-1])
                    {
                        int t=a[j-1],tl=tlst[j-1];
                        a[j-1]=a[j];
                        tlst[j-1]=tlst[j];
                        a[j]=t;
                        tlse[j]=tl;
                    }
                }
            }
            cout<<tl[b-1]+1;
        }
    }
    return 0;
}
