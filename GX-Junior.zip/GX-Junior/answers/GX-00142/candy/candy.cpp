#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    feeopen("candy.out","w",stdout);
    long long n,L,R,sum=0;
    cin>>n,L,R;
    for(long long i=L;i<=R;i++)
    {
        long long h;
        for(h=i;h>=n;h=h-n)
        {

        }
        if(h>=sum)sum=h;
    }
    cout<<sum;
    return 0;
}
