#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int n;
    cin>>n;
    int g=0,n=1,h=-1;
    string op,ad,nj="1";
    for(int i=0;i<n;i++)
    {
        int j=1;
        cin>>op>>ad;
        for(int i=op.length()-1;i>=0;i--)
        {
            if(op[i]=='.'||op[i]==':')
            {
                if(op[i+1]=='0')
                {
                    cout<<"ERR"<<endl;
                    n=0;
                    g=4;
                    j=0;
                }
                if(n)g++;
            }
        }
        if(g!=4)
        {
            cout<<"ERR"<<endl;
            j=0;
        }
        if(j)
        {
            if(op=="Server")
            {
                if(ad!=nj)
                {
                    nj=op;
                    h=i;
                    cout<<"OK"<<endl;
                }
                else
                {
                    cout<<"FAIL"<<endl;
                }
            }
            else
            {
                if(ad==nj)cout<<h+1<<endl;
            }
        }
    }
    return 0;
}
