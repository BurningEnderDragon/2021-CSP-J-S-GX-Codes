#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
int n,q;
int a[8000+10];
int cyt(int b[8000+10],int f)
{
	int c[8000+10]={0};
	for(int i=1;i<=n;i++)
	  c[i]=b[i];
	for(int i=1;i<=n;i++)
	{
		if(i!=f)
		{
		  for(int j=i;j>=2;j--)
		  {
		    if(c[j]<c[j-1]) 
		    {
				swap(c[j-1],c[j]);
				if(j-1==f) f++;
			}
			else break;
	      }
	    }
	    else
	    {
			for(int j=i;j>=2;j--)
		  {
		    if(c[j]<c[j-1]) {swap(c[j],c[j-1]); f--;}
		    else break;
		  }
		}
	}
	return f;
}
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d %d",&n,&q);
	for(int i=1;i<=n;i++)
	  scanf("%d",&a[i]);
	for(int i=1;i<=q;i++)
	{
		int fl;
		scanf("%d",&fl);
		if(fl==1)
		{
			int x,y;
			scanf("%d %d",&x,&y);
			a[x]=y;
		}
		if(fl==2)
		{
			int id,aid;
			scanf("%d",&id);
			aid=cyt(a,id);
			printf("%d\n",aid);
		}
	}
	return 0;
}

