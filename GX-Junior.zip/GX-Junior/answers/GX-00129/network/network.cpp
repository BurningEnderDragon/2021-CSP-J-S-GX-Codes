#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
int n,ll=0;
struct cop
{
  string q;
  int idd;
}b[1000+10];
struct computer
{
	string fl;
	string id;
	int nu;
}a[1000+10];
bool sth(string s)
{
	string ss,t;
	int sum=0,p=0,m=0,l=s.size();
	for(int j=0;j<l;j++)
	{
	  if(s[j]>='0'&&s[j]<='9') {sum=sum*10+s[j]-'0'; ss+=s[j];}
	  else
		{
		   if(s[j]=='.') p++;
		   if(s[j]==':') m++;
		   if(sum>255||sum<0) return 0;
		   while(sum!=0)
		   {
			   int g=sum%10;
			   t+=g+'0';
			   sum/=10;
		   }
		   if(ss[0]!=t[t.size()-1]) return 0;
		   t="";
		   ss="";
		}
	}
	if(sum>65535||sum<0) return 0;
    while(sum!=0)
    {
	    int g=sum%10;
		t+=g+'0';
		sum/=10;
	}
	if(ss[0]!=t[t.size()-1]) return 0;
	if(p>3||m>1) return 0;
	return 1;
}
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	  {cin>>a[i].fl>>a[i].id; a[i].nu=i;}
	for(int i=1;i<=n;i++)
	{
		if(!sth(a[i].id)) printf("ERR\n");
		else
		{
			if(a[i].fl=="Server")
		    {
				bool fg=0;
				for(int w=1;w<=ll;w++)
				  if(a[i].id==b[w].q) {printf("FAIL\n"); fg=1; break;}
				if(!fg) {printf("OK\n"); b[++ll].q=a[i].id; b[ll].idd=a[i].nu;}
		    }
		   else
		  {
			    int fgg=0;
		     	for(int j=1;j<=ll;j++)
			      if(a[i].id==b[j].q) {fgg=1; printf("%d\n",b[j].idd); break;}
		        if(!fgg) printf("FAIL\n");
		   }
		}
	}
	return 0;
}
