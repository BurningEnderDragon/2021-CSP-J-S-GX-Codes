#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
int n,t=1;
struct sombod
{
	int fl,le,an;
}f[200000+10];
struct fru
{
	int id,nu;
}a[200000+10];
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	  {scanf("%d",&a[i].nu); a[i].id=i;}
	while(1)
	{  
	  for(int i=1;i<=n;i++)
	  {
		  if(f[t].fl==0&&a[i].nu==a[i+1].nu) {f[t].an++; f[t].fl=1; f[t].le=a[i].id;} 
	      if(f[t].fl==1&&a[i].nu==a[i+1].nu) f[t].an++;
	      if(a[i].nu!=a[i+1].nu) t++;
	  }
	  for(int i=1;i<=t;i++)
	    printf("%d ",f[i].le);
	  cout<<endl;
	  int c[200000+10];
	  for(int i=1;i<=n;i++)
	  {
		  int fff=0;
		  for(int j=1;j<=t;j++)
		    if(fff)
	  }
	  n-=t;
	  t=1;
	}
	return 0;
}
