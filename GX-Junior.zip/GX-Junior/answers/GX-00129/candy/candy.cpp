#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
int n,l,r;
int ma=0x80000000;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>n>>l>>r;
	for(int i=l;i<=r;i++)
	{
		int x=i%n;
		ma=max(x,ma);
	}
	cout<<ma;
	return 0;
}
