#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,r,l,mx=0;
int main()
{
   freopen("candy.in","r",stdin);
   freopen("candy.out","w",stdout);
   cin>>n>>l>>r;
   if(r-l>=n)
      cout<<n-1;
   else
      cout<<r%n;
   return 0;
}
