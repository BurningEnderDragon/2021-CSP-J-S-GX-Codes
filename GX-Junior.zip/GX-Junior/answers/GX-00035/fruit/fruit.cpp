#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
   freopen("fruit.in","r",stdin);
   freopen("fruit.out","w",stdout);
   for(int i=1;i<=5;i++)
      cout<<i<<endl;
   return 0;
}



