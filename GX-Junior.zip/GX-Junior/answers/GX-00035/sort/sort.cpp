#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n,q,f,x,y,a[8080];
int main()
{
   freopen("sort2.in","r",stdin);
   freopen("sort.out","w",stdout);
   cin>>n>>q;
   for(int i=1;i<=n;i++)
      scanf("%d",&a[i]);
   for(int i=1;i<=q;i++)
   {  
	   scanf("%d",&f);
	   if(f==1)
	   {
	      scanf("%d%d",&x,&y);
	      a[x]=y;
	   }
	   else
	   {
	      scanf("%d",&x);
	      printf("%d\n",a[x]);
	   }  
   }
   return 0;
}
