#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
string s1,s2;
int n,t=1,a[1001];
int main()
{
   freopen("network.in","r",stdin);
   freopen("network.out","w",stdout);
   cin>>n;
   for(int i=1;i<=n;i++)
   {
	   cin>>s1>>s2;
	   if(s1=="Server")
	   {
		  puts("OK"); 
	      a[i]=i;
	   }
	   else
       {
		  if(a[t]!=0)
	         printf("%d\n",a[t]);
	      else
	         printf("FAIL");
	      ++t;
	   }
   }
   return 0;
}


