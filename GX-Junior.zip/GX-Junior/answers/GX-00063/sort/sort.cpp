#include<bits/stdc++.h>
using namespace std;
int c,d[200001],e[8001];
bool px(int n1,int m)
{
    return n1<m;
}
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int n,q;
    int a[8001],b[8001];
    cin>>n>>q;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
        e[i]=i;
    }
    int x,y,z;
    for(int i=1;i<=q;i++)
    {
        cin>>x;
        if(x==1)
        {
            cin>>y>>z;
            a[y]=z;
        }
        if(x==2)
        {
            cin>>y;
            for(int ii=1;ii<=n;ii++)
            {
                b[ii]=a[ii];
                if(ii==y)
                {
                    c=a[ii];
                }
            }
            sort(b+1,b+1+n,px);
            for(int ii=1;ii<=n;ii++)
            {
                if(b[ii]==c)
                {
                    d[i]=ii;
                    break;
                }
            }
        }
    }
    for(int i=1;i<=q;i++)
    {
        if(d[i]!=0)
        {
            cout<<d[i]<<endl;
        }
    }
    return 0;
}
