#include<bits/stdc++.h>
using namespace std;
int b[200001];
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    int n;
    cin>>n;
    int a[200001];
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
    }
    while(1==1)
    {
        for(int i=1;i<=n;i++)
        {
            if(b[i]!=0)
            {
                for(int ii=i+1;ii<=n;ii++)
                {
                    if(b[ii]==0)
                    {
                        if(a[ii]!=a[i])
                        {
                            b[i]=1;
                            cout<<i<<" ";
                            break;
                        }
                    }
                }
            }
        }
        cout<<endl;
        int o=0;
        for(int i=1;i<=n;i++)
        {
            if(b[i]==0)
            {
                o=1;
            }
        }
        if(o==0)
        {
            break;
        }
    }
    return 0;
}
