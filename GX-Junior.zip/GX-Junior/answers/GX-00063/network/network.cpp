#include<bits/stdc++.h>
using namespace std;
int f[1001];
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int n;
    cin>>n;
    string s[1001];
    char x[1001],y[1001],z[1001],w[1001];
    int a[1001],b[1001],c[1001],d[1001],e[1001];
    for(int i=1;i<=n;i++)
    {
        cin>>s[i]>>a[i]>>x[i]>>b[i]>>y[i]>>c[i]>>z[i]>>d[i]>>w[i]>>e[i];
        int pd=1;
        if(s[i]=="Server")
        {
            if((x[i]=='.'&&y[i]=='.'&&z[i]=='.'&&w[i]==':')&&(a[i]>=0&&b[i]>=0&&c[i]>=0&&d[i]>=0&&e[i]>=0)&&((a[i]>=0&&a[i]<=255)&&(b[i]>=0&&b[i]<=255)&&(c[i]>=0&&c[i]<=255)&&(d[i]>=0&&d[i]<=255)&&(e[i]>=0&&e[i]<=65535)))
            {
                pd=1;
            }
            else
            {
                pd++;
            }
            if(pd!=1)
            {
                cout<<"ERR"<<endl;
            }
            else if(a[i]==a[i-1]&&b[i]==b[i-1]&&c[i]==c[i-1]&&d[i]==d[i-1]&&e[i]==e[i-1]&&x[i]==x[i-1]&&y[i]==y[i-1]&&z[i]==z[i-1]&&w[i]==w[i-1])
            {
                cout<<"FAIL"<<endl;
            }
            else
            {
                cout<<"OK"<<endl;
            }
        }
        if(s[i]=="Client")
        {
            if((x[i]=='.'&&y[i]=='.'&&z[i]=='.'&&w[i]==':')&&(a[i]>=0&&b[i]>=0&&c[i]>=0&&d[i]>=0&&e[i]>=0)&&((a[i]>=0&&a[i]<=255)&&(b[i]>=0&&b[i]<=255)&&(c[i]>=0&&c[i]<=255)&&(d[i]>=0&&d[i]<=255)&&(e[i]>=0&&e[i]<=65535)))
            {
                pd=1;
            }
            else
            {
                pd++;
            }
            if(pd!=1)
            {
                cout<<"ERR"<<endl;
            }
            else
            {
                int u=0;
                for(int ii=1;ii<=n;ii++)
                {
                    if(s[ii]=="Server")
                    {
                        if(a[i]==a[ii]&&b[i]==b[ii]&&c[i]==c[ii]&&d[i]==d[ii]&&e[i]==e[ii]&&x[i]==x[ii]&&y[i]==y[ii]&&z[i]==z[ii]&&w[i]==w[ii])
                        {
                            cout<<ii<<endl;
                            u=1;
                            break;
                        }
                    }
                }
                if(u==0)
                {
                    cout<<"FAIL"<<endl;
                }
            }
        }
    }
    return 0;
}
