#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,a,b;
    cin>>n>>a>>b;
    int z=0,max=0;
    for(int i=a;i<=b;i++)
    {
        int ii=i;
        while(1==1)
        {
            if(ii>=n)
            {
                ii-=n;
            }
            else
            {
                max=ii;
                break;
            }
        }
        if(max>z)
        {
            z=max;
        }
        max=0;
    }
    cout<<z;
    return 0;
}
