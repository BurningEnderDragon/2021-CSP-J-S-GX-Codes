#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
struct Computer
{
	int id;
	char op[10], ad[30];
} a[1001];
int main()
{
	freopen("network.in", "r", stdin);
	freopen("network.out", "w", stdout);
	int n;
	cin >> n;
	char ads[1001][30];
	int adsid[1001];
	int pos = 0;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i].op >> a[i].ad;
		a[i].id = i;
		int len = strlen(a[i].ad);
		bool is_ok = 1;
		int numberpos = 0, charpos = 0;
		int number = 0;
		for (int j = 0; j < len; j++)
		{
			if (j == 0 && a[i].ad[j] == '0' && a[i].ad[j+2] != '.' )
			{
				is_ok = 0;
				break;
			}
			if (a[i].ad[j] == '.' && a[i].ad[j+1]=='0' )
			{
				char p = a[i].ad[j+2];
				if (p >= '0' && p <= '9')
				{
				        is_ok = 0;
					break;
				}
			}
			if (a[i].ad[j] == ':' && a[i].ad[j+1]=='0')
			{
				is_ok = 0;
				break;
			}
			if (j == 0)
			{
				numberpos++, number = 0;
				int k = j;
				while (a[i].ad[k] >= '0' && a[i].ad[k] <= '9')
				{
					number *= 10;
					number += (a[i].ad[k] - '0');
					k++;
				}
				if (number >= 256)
				{
					is_ok = 0;
					break;
				}
			}
			if (a[i].ad[j] == '.' || a[i].ad[j] == ':')
			{
				charpos++;
				if (charpos >= 5)
				{
					is_ok = 0;
					break;
				}
				if (charpos <= 3 && a[i].ad[j] == ':')
				{
					is_ok = 0;
					break;
				}
				if (charpos == 4 && a[i].ad[j] == '.')
				{
					is_ok = 0;
					break;
				}
			}
			if (a[i].ad[j - 1] == '.' || a[i].ad[j - 1] == ':')
			{
				numberpos++, number = 0;
				int k = j;
                                while (a[i].ad[k] >= '0' && a[i].ad[k] <= '9')
                                {
                                        number *= 10;
                                        number += (a[i].ad[k] - '0');
                                        k++;
                                }
                                if (number >= 256 && numberpos <= 4)
                                {
					is_ok = 0;
                                        break;
                                }
				if (number >= 65536)
				{
					is_ok = 0;
					break;
				}
			}
			if (j == len - 1 && charpos <= 3)
			{
				is_ok = 0;
				break;
			}
		}
		if (is_ok == 0)
		{
			cout << "ERR" << endl;
			continue;
		}
		if (a[i].op[0] == 'S')
		{
			bool flag = 1;
			for (int j = 1; j <= pos; j++)
			{
				if (pos == 0) break;
				bool flag2 = 1;
				for (int k = 0; k < 30; k++)
				{
					if (a[i].ad[k] != ads[j][k])
					{
						flag2 = 0;
						break;
					}
				}
				if (flag2)
				{
					cout << "FAIL" << endl;
					flag = 0;
					break;
				}
			}
			if (!flag) continue;
			pos++;
			for (int j = 0; j < len; j++)
			{
				ads[pos][j] = a[i].ad[j];
			}
			adsid[pos] = a[i].id;
			cout << "OK" << endl;
		}
		else
		{
			bool flag = 0;
			for (int j = 1; j <= pos; j++)
                        {
                                bool flag2 = 1;
                                for (int k = 0; k < 30; k++)
                                {
                                        if (a[i].ad[k] != ads[j][k])
                                        {
                                                flag2 = 0;
                                                break;
                                        }
                                }
                                if (flag2)
                                {
                                        cout << adsid[j] << endl;
                                        flag = 1;
                                        break;
                                }
                        }
			if (!flag)
			{
				cout << "FAIL" << endl;
			}
		}
	}
	return 0;
}

