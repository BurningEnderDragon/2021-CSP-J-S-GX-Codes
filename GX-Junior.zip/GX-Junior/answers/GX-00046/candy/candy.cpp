#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
	freopen("candy.in", "r", stdin);
	freopen("candy.out", "w", stdout);
	long long n, l, r;
	cin >> n >> l >> r;
	long long k = r - (r % n) - 1;
	if (k < l) k = r;
	long long ans = k % n;
	cout << ans << endl;
	return 0;
}
