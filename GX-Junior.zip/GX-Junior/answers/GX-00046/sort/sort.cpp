#include <iostream>
#include <cstdio>
using namespace std;
long long a[8001], t[8001], b[8001];
int pos;
void Sort(int l, int r)
{
	if (l == r) return;
	int mid = (l + r) / 2;
	Sort(l, mid);
	Sort(mid + 1, r);
	int tmp = l, tmp_l = l, tmp_r = mid + 1;
	bool is_change = 0;
	while (tmp_l <= mid && tmp_r <= r)
	{
		if (b[tmp_l] <= b[tmp_r])
		{
			if (tmp_l == pos && !is_change)
			{
				pos = tmp;
				is_change = 1;
			}
			t[tmp++] = b[tmp_l++];
		}
		else
		{
			if (tmp_r == pos && !is_change)
			{       
				pos = tmp;
				is_change = 1;
			}
			t[tmp++] = b[tmp_r++];
		}
	}
	while (tmp_l <= mid)
	{
		if (tmp_l == pos && !is_change)
		{       
			pos = tmp;
			is_change = 1;
		}
		t[tmp++] = b[tmp_l++];
	}
	while (tmp_r <= r)
	{
		if (tmp_r == pos && !is_change)
		{
			pos = tmp;
		        is_change = 1;
		}	
		t[tmp++] = b[tmp_r++];
	}
	for (int i = l; i <= r; i++)
	{
		b[i] = t[i];
	}
}
int main()
{
	freopen("sort.in", "r", stdin);
	freopen("sort.out", "w", stdout);
	int n, q;
	cin >> n >> q;
	for (int i = 1; i <= n; i++)
		scanf("%lld", &a[i]);
	for (int i = 1; i <= q; i++)
	{
		int x;
		scanf("%d", &x);
		if (x == 1)
		{
			int c;
			long long v;
			scanf("%d%lld", &c, &v);
			a[c] = v;
		}
		else
		{
			for (int i = 1; i <= n; i++)
			{
				b[i] = a[i];
			}
			scanf("%d", &pos);
			Sort(1, n);
			printf("%d\n", pos);
		}
	}
	return 0;
}
