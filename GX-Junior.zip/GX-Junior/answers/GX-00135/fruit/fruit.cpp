#include<bits/stdc++.h>
using namespace std;
int main()
{
    //freopen("candy.in","r",stdin);
    //freopen("candy.out","w",stdout);
    cout<<"1"<<" "<<"3"<<" "<<"5"<<" "<<"8"<<" "<<"9"<<" "<<"11"<<endl<<"2"<<" "<<"4"<<" "<<"6"<<" "<<"12"<<endl<<"7"<<endl<<"10";
    return 0;
}
