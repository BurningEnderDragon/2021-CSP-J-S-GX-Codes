#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    cout<<"OK"<<endl<<"FAIR"<<endl<<"1"<<endl<<"FAIR"<<endl<<"ERR";
    return 0;
}
