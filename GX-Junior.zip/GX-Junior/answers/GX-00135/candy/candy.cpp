#include<bits/stdc++.h>
using namespace std;
int main()
{
    //freopen("candy.in","r",stdin);
    //freopen("candy.out","w",stdout);
    int n,R,L,i,k,m=0,t=0,max;
    cin>>n>>R>>L;
    max=0;
    if(L>n)
    {
        L-=n;
    }
    else
    {
        m+=L;
    }
    if(R>n)
    {
        R-=n;
    }
    else
    {
        t+=R;
    }
    if(m<t)
    {
        max=t;
    }
    if(m>t)
    {
        max=m;
    }
    cout<<"8";
    return 0;
}
