#include<iostream>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.ans","w",stdout);
    int n,L,R,f,k;
    cin>>n>>L>>R;
    if(k>=n&&L<=k<=R)
        f=k-n;
    else
        if(k<n) cout<<k<<endl;
}
return 0;
