#include<iostream>
using namespace std;
int main()
{
  freopen("candy.in","r",stdin);
  freopen("candt.out","w",stdout);
  int n,l,r,k,s=0;
  cin>>n>>l>>r;
  if(n<=l<=r)
  else
  if(l<=k<=r)
  {
     k=l;
  }
  for(int i=k;i>=n;i--)
  {
     if(i<=n)
     s+=i;
  }
  cout<<s;
  return 0;
}
