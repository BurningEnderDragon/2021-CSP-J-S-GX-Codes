#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    const int N=n;
    char op[6];
    char ad[25];
    for (int i=0;i<N;i++)
    {
        cin>>op[][i]>>ad[][i];
    }
    for (int i=0;i<N-1;i++)
    {
        a= (ad[1][i]-'0')*100+(ad[2][i]-'0')*10+(ad[3][i]-'0');
        b= (ad[5][i]-'0')*100+(ad[6][i]-'0')*10+(ad[7][i]-'0');
        c= (ad[9][i]-'0')*100+(ad[10][i]-'0')*10+(ad[11][i]-'0');
        d= (ad[13][i]-'0')*100+(ad[14][i]-'0')*10+(ad[15][i]-'0');
        e= (ad[17][i]-'0')*10000+(ad[18][i]-'0')*1000+(ad[19][i]-'0')*100+(ad[20][i]-'0')*10+(ad[21][i]-'0');
        if(op[][i]==Server)
        {
            if(a,b,c,d,e>=0&&a,b,c,d<=255&&e<=65535)
            {
                if(op[][i]==op[][i+1]&&ad[][i]==ad[][i+1])
                {
                    cout<<"FAIL"<<endl;
                }
                else
                {
                    cout<<"OK"<<endl;
                }
            }
            else
            {
                cout<<"ERR"<<endl;
            }
        else
        {
            if(a,b,c,d,e>=0&&a,b,c,d<=255&&e<=65535)
            {
                for(int x=0;x<N;x++)
                {
                    if(op[][i]!=op[][x])
                    {
                       if(ad[][i]==ad[][x])
                       {
                           cout<<"1"<<endl;
                       }
                       else
                       {
                           cout<<"FAIL"<<endl;
                       }
                    }
                }
            }
            else
            {
                cout<<"ERR"<<endl;
            }
        }
    }
    return 0;
}
