#include <iostream>

using namespace std;

int main()
{
    int n;
    int L;
    int R;
    cin<<n;
    cin<<L;
    cin<<R;
    int k;
    int a=0;
    const int l=L;
    const int r=R;
    for (int i=l;i<r+1;i++)
    {
        k=i;
        k=k%l;
        if(k>a)
        {
            a=k;
        }
    }
    cout<<a;
    return 0;
}
