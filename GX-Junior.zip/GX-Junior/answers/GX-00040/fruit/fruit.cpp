#include <iostream>

using namespace std;

int main()
{

    int n;
    cin>>n;
    const int N=n;
    int a[N];
    cin>>a;
    int z[N];
    int c=0;
    while(N!=0)
    {
        for (int i=1;i<N;i++)
        {
            if(a[i]==a[i-1])
            {
                z[c]=a[i-1];
                c++;
                for(inr x=0;x<N-1;x++)
                {
                    N--;
                    a[x+1]=a[x];
                }
            }
        }
        cout<<z;
    }
    return 0;
}
