#include<cstdio>
#include<iostream>
#include<cmath>
#include<algorithm>
#include<queue>
#include<string>
#include<set>
using namespace std;
int main()
{
  freopen("candy.in","r",stdin);
  freopen("candy.out","w",stdout);
  int n,l,r,ans=0;
  cin>>n>>l>>r;
  for(int i=l;i<=r;i++)
  {
	  int t=0;
	  t = i%n;
	  ans = max(ans,t);
  }
  cout<<ans;
  return 0;
}
