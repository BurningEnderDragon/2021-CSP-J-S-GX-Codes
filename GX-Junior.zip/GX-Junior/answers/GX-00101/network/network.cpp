#include<cstdio>
#include<iostream>
#include<cmath>
#include<algorithm>
#include<queue>
#include<string>
#include<set>
using namespace std;
int v[1001],w[1001],x[1001],y[1001],z[1001];
int main()
{
  freopen("network.in","r",stdin);
  freopen("network.out","w",stdout);
  int n,a,b,c,d,e;
  char a1,b1,c1,d1;
  cin>>n;
  for(int i=1;i<=n;i++)
  {
	  string s;
	  cin>>s>>a>>a1>>b>>b1>>c>>c1>>d>>d1>>e;
	  if(a<0)
	  {
		  cout<<"ERR"<<endl;
		  continue;
	  }
	  if(a1!='.')
	  {
		  cout<<"ERR"<<endl;
		  continue;
	  }
	  if(b1!='.')
	  {
		  cout<<"ERR"<<endl;
		  continue;
	  }
	  if(c1!='.')
	  {
		  cout<<"ERR"<<endl;
		  continue;
	  }
	  if(d>255)
	  {
		  cout<<"ERR"<<endl;
		  continue;
	  }
	  if(d1!=':')
	  {
		  cout<<"ERR"<<endl;
		  continue;
	  }
      if(e<0 or e>65535)
	  {
		  cout<<"ERR"<<endl;
		  continue;
	  }
	  if(s=="Server")
	  {
		  int flag = 0;
		  for(int j=1;j<=i;j++)
		  {
			  if(v[j]==a and w[j]==b and x[j]==c and y[j]==d  and z[j]==e){flag=1;}
			  if(flag==1)break;
		  }
		  if(flag==0)
		  {
		  v[i]=a;
		  w[i]=b;
		  x[i]=c;
		  y[i]=d;
		  z[i]=e;
		  cout<<"OK"<<endl;
	      }
	      else
	      {
			  cout<<"FAIL"<<endl;
		  }
		  }
		 if(s=="Client")
		 {
		  int flag = 0;
		  for(int j=1;j<=i;j++)
		  {
			  if(v[j]==a and w[j]==b and x[j]==c and y[j]==d and z[j]==e){flag=1;}
			  if(flag==1){cout<<j<<endl;break;}
		  }
		  if(flag==0)cout<<"FAIL"<<endl;
		 }
		 
  }
  return 0;
}
