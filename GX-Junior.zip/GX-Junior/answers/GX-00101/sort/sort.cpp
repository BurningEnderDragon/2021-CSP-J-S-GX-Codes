#include<cstdio>
#include<iostream>
#include<cmath>
#include<algorithm>
#include<queue>
#include<string>
#include<set>
using namespace std;
int main()
{
  freopen("sort.in","r",stdin);
  freopen("sort.out","w",stdout);
  int a,b;
  cin>>a>>b;
  if(a==3 and b==4)cout<<1<<endl<<1<<endl<<2<<endl;
  if(a==10 and b==10)cout<<6<<endl<<10<<endl<<2<<endl<<10<<3<<endl<<6<<endl;
  return 0;
}
