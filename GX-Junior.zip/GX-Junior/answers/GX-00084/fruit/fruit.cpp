#include<iostream>
#include<fstream>
using namespace std;
int main(){
    ifstream myfile("fruit.in.txt");
    ofstream outfile("fruit.out.txt",trunc);
    int n,num=0;
    myfile>>n;
    int fruit[n],fruit2[n];
    for(int i=0;i<n;i++){
        myfile>>fruit[i];
    }
    for(int i=0;i<n;i++){
        for(int j=i+1;j<=n;j++){
            if(fruit[i]==fruit[j] && fruit2[i]!=fruit[j]){
                fruit2[num]=j;
                num++;
            }
        }
    }
    for(int i=0;i<n;i++){
        outfile<<fruit2[i]<<" ";
    }
    myfile.close();
    outfile.close();
    return 0;
}
