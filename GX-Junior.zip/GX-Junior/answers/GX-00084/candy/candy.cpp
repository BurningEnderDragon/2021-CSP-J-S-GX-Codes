#include<iostream>
#include<fstream>
using namespace std;
int main(){
    int n,L,R,max=0,num=0;
    ifstream myfile("candy.in.txt");
    ofstream outfile("candy.out.txt",ios::trunc);
    myfile>>n>>L>>R;
    for(int i=L;i<R;i++){
        num=i;
        num=num%n;
        if(num>max){
            max=num;
        }
    }
    outfile<<max;
    myfile.close();
    outfile.close();
    return 0;
}
