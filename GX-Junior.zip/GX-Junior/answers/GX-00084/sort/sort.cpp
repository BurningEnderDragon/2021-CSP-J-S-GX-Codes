#include<iostream>
#include<fstream>
using namespace std;
int main(){
    int n,Q;
    ifstream myfile("sort.in.txt");
    ofstream outfile("sort.out.txt");
    myfile>>n>>Q;
    for(int i=1;i<=n;i++){
        for(int j=i;j>=2;j‐‐){
            if ( a[j] < a[j‐1] ){
               int t = a[j‐1];
               a[j‐1] = a[j];
               a[j] = t;
            }
        }
    }
    myfile.close();
    outfile.close();
    return 0;
}

