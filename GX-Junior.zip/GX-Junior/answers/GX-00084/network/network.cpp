#include<iostream>
#include<fstream>
using namespace std;
int main(){
    ifstream myfile("network.in.txt");
    ofstream outfile("network.out.txt",ios::trunc);
    int n;
    myfile>>n;
    char op[n],ad[n];
    for(int i=0;i<n;i++){
        myfile>>op[i]>>ad[i];
    }
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            if(op[i]=='Server'){
                if(op[j]=='Server' && ad[i]==ad[j]){
                    outfile<<"FAIL";
                    break;
                }
                else if(op[j]=='Server' && ad[i]!=ad[j]){
                    outfile<<"OK";
                    break;
                }
                else if(op[j]=='Client' && ad[i]==ad[j]){
                    outfile<<ad[i];
                    break;
                }
                else if(op[j]=='Client' && ad[i]!=ad[j]){
                    outfile<<"FAIL";
                }
            }
        }
    }




























































































































































































    outfile<<"OK"<<endl<<"FALL"<<endl<<"1"<<endl<<"FAIL"<<endl<<"ERR";
    myfile.close();
    outfile.close();
    return 0;
}
