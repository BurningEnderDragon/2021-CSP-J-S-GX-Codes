#include<iostream>
#include<cstdio>
#include<algorithm>
#include<string>
#include<cstring>
#include<queue>
using namespace std;
int sum[1001];
int n;
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		int ans=0,tot=0,num=0;
		string a,b;
		cin>>a>>b;
		int len=b.size();
		if(a[0]=='C')
		{
		  for(int j=0;j<len;j++)
		      num+=a[j];
          if(ans==num) cout<<1<<endl;
		  else cout<<"FAIL"<<endl;
		}
		if(a[0]=='S')
		{
		  for(int j=0;j<len;j++)
		  {
			  if(b[j]!='.'&&b[j]!=':')
			    ans=ans*10+b[j]-'0';
			  else
			  {
				  if(b[j+1]==0) {cout<<"EER"<<endl;break;}
				  tot++;
				  if(tot==4)
					  if(ans>255) {cout<<"EER"<<endl;break;}
				  if(tot==1)
				      if(ans<0) {cout<<"EER"<<endl;break;}
				  ans=0;
			  }
			  sum[i]+=b[j];
			  
		  }
	    	if(tot==4)
	     		if(ans>255) cout<<"EER"<<endl;
	    	for(int j=1;j<i;j++)
	    	  if(sum[i]==sum[j]) {cout<<"FAIL"<<endl;break;}
	    	cout<<"OK"<<endl;
	    }
	}
	return 0;
}

