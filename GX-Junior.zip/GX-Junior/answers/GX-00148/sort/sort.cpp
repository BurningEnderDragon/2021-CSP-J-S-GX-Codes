#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
#include<queue>
using namespace std;
int n,q;
int a[8010],b[8010];
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++)
	{
	  scanf("%d",&a[i]);
	  b[i]=a[i];
	}
	for(int i=1;i<=q;i++)
	{
		int x,y,z;
		scanf("%d",&x);
		if(x==2)
		{
			scanf("%d",&y);
			sort(b+1,b+n+1);
			for(int j=1;j<=n;j++)
			  if(a[y]==b[j]&&b[j]!=b[j+1]) {cout<<j<<endl;break;}
		}
		else 
		{
			scanf("%d%d",&y,&z);
			a[y]=z;
			for(int j=1;j<=n;j++)
			  b[j]=a[j];
		}
		
	}
	return 0;
}

