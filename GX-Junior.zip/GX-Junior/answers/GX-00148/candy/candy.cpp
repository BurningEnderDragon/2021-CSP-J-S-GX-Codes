#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
#include<queue>
using namespace std;
int n,l,r;
int sum=-1;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d%d%d",&n,&l,&r);
	for(int i=r;i>=l;i--)
	{
		int ans=0;
		ans=ans+(i%n);
		sum=max(ans,sum);
	}
	cout<<sum;
	return 0;
}

