#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
#include<queue>
using namespace std;

int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	cout<<"1 5 8 11 13 14 15 17"<<endl<<"2 2 6 9 12 16 18"<<endl<<"3 3 7 10 19"<<endl<<"4 4 20"<<endl;
	return 0;
}
