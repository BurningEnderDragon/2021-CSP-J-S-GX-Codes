#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int n,q,b[10000],a[10000],j,t,k,i,x,v,c,g,d;
    cin>>n>>q;
    for(k=1; k<=n; k++)
    {
        cin>>b[k];
    }
    for(k=0; k<q; k++)
    {
        cin>>c;
        if(c==1)
        {
            cin>>x>>v;
            b[x]=v;
        }
        else if(c==2)
        {
            cin>>x;
            d=b[x];
            for(g=1; g<=n; g++)
            {
                a[g]=b[g];
            }
            for (i=1; i<=n; i++)
                for (j=i; j>=2; j--)
                    if (a[j]<a[j-1])
                    {
                        t=a[j-1];
                        a[j-1]=a[j];
                        a[j]=t;
                    }
            for(g=1; g<=n; g++)
            {
                if(a[g]==d)
                {
                    cout<<g<<endl;
                    break;
                }
            }
        }
    }
    return 0;
}
