#include<iostream>
using namespace std;
int main()
{
    int n,a[10000],i,t,j,f,b[100][100],c,d;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>a[i];
    }
    for(j=0;j<n;j++)
    {
        for(i=0;a[i]!=2;i++)
        {
            t=a[i];
        }
        c=0;
        for(i=0;i<n;i++)
        {
            if(a[i]!=2)
            {
                if(a[i]!=t)
                {
                    t=a[i];
                    a[i]=2;
                    c++;
                }
            }
        }
        for(i=0;i<c;i++)
        {
            if(a[i]==2)
            {
                b[j][i]=i;
            }
        }
        f=1;
        for(i=0;i<n;i++)
        {
            if(a[i]!=2)
            {
                f=0;
                break;
            }
        }
        if(f==1)
        {
            break;
        }

    }
    for(i=0;i<j;i++)
    {
        d=0;
        while(a[d]!=0)
        {
            cout<<b[i][d]<<" ";
            d++;
        }
        cout<<endl;
    }
    return 0;
}
