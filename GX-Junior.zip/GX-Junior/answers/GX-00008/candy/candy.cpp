#include<iostream>
#include<iomanip>
#include<cstdio>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,l,r,t,i,a=0;
    cin>>n>>l>>r;
    for(i=l;i<=r;i++)
    {
        t=i%n;
        if(t>a)
        {
            swap(a,t);
        }
    }
    cout<<a;
    return 0;
}
