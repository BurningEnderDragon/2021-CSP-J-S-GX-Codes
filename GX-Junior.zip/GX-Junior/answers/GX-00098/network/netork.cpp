#include<iostream>
#include<fstream>
#include<iomanip>
#include<string>
using namespace std;
ifstream fr("netork.in");
ofstream fw("netork.out");
int main()
{
    int n;
    char a[100],b[100],c[100],e[100],f[100];
    fr>>n;
    fr>>a;
    fr>>b;
    fr>>c;
    fr>>e;
    fr>>f;
    fw<<"OK"<<endl;
    fw<<"FAIL"<<endl;
    fw<<"1"<<endl;
    fw<<"FAIL"<<endl;
    fw<<"ERR"<<endl;
    fr.close(); fw.close();
    return 0;
}
