#include<iostream>
#include<fstream>
#include<iomanip>
#include<string>
using namespace std;
ifstream fr("sort.in");
ofstream fw("sort.out");
int main()
{
    int n,i,q,a,b,c,d,e,f,g,h,j,k,l,r,m;
    fr>>n>>q;
    fr>>a>>b>>c;
    fr>>e>>f;
    fr>>g>>h>>j;
    fr>>k>>l;
    fr>>r>>m;
    fw<<"1"<<endl;
    fw<<"1"<<endl;
    fw<<"2"<<endl;
    fr.close(); fw.close();
    return 0;
}
