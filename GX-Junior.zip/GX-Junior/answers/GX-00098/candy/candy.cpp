#include<iostream>
#include<fstream>
#include<iomanip>
#include<string>
using namespace std;
ifstream fr("candy.in");
ofstream fw("candy.out");
int main()
{
    int i,n,l,r,k,b,c,s=0;
    long a[10000];
    fr>>n>>l>>r;
    a[0]=0;
    /*fw<<n<<"  "<<l<<"  "<<r<<endl;*/
    for(i=l;i<=r;++i)
    {
        k=i;
        while(k>=n)
        {
            k=k-n;
            /*fw<<k<<"  ";*/
        }
        if(a[0]<k) {a[0]=k;}
    }
    b=s-1;
    for(i=0;i<b;++i)
        if(a[i]<a[i+1]) {

        }
    /*for(i=0;i<b;++i)
    {
        fw<<a[i]<<"  ";
    }*/
    fw<<a[0]<<endl;
    fr.close(); fw.close();
    return 0;
}
