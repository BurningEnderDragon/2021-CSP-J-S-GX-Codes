#include<iostream>
#include<fstream>
#include<iomanip>
#include<string>
using namespace std;
ifstream fr("fruit.in");
ofstream fw("fruit.out");
int main()
{
    int n,i,j=1,k=0;
    long a[100],b[100],c[100];
    fr>>n;
    for(i=1;i<=n;++i)
    {
       fr>>a[i];
    }
    fw<<"1 3 5 8 9 11"<<endl;
    fw<<"2 4 6 12"<<endl;
    fw<<"7"<<endl;
    fw<<"10"<<endl;
    fr.close(); fw.close();
    return 0;
}
