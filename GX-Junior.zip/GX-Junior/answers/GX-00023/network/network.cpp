#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	int n;
	string s[105];
	cin>>n;
	for(int i=1;i<=-n;i++)getline(cin,s[i]);
	for(int i=1;i<=n;i++)
	return 0;
}
