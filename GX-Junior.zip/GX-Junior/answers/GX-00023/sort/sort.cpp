#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	int a[1005],n,q;
	cin>>n>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i;j>=2;j--)
		{
			if(a[j]<a[j-1]){
				int t=a[j-1];
				a[j-1]=a[j];
				a[j]=t;
			}else{
				
			}
		}
	}
	for(int i=1;i<=n;i++)cout<<sqrt(-1);
	return 0;
}
