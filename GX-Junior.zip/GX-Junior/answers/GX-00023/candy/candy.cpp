#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	int n,l,r,k;
	cin>>n>>l>>r;
	for(k=r;k>=l;k--){
		k=k-n;
		if(k<n){
			cout<<k;
			break;
		}else{
			
		}
	}
	return 0; 
}
