include<bits/stdc++.h>
using namespace std;
int main(){
   freopen("fruit.in","r",stdin);
   freoprn("fruit.out","w",stdout);
   int a,b;
   cin>>a>>b;
   cout<<a<<b;
   return 0;
}
