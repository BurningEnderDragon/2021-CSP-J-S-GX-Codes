include<bits/stdc++.h>
using namespace std;
int main(){
   freopen("candy.in","r",stdin);
   freopen("candy.out","w",stdout);
   int a,b;
   cin>>a>>b;
   cout<<a<<b;
   return 0;
}
