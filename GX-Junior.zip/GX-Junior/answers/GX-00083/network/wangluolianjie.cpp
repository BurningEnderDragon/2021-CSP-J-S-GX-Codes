include<bits/stdc++.h>
using namespace std;
int main(){
   freopen("network.in","r",stdin);
   freoprn("network.out","w",stdout);
   int a,b;
   cin>>a>>b;
   cout<<a<<b;
   return 0;
}
