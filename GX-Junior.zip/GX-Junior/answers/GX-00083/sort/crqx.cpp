include<bits/stdc++.h>
using namespace std;
int main(){
   freopen("sort.in","r",stdin);
   freopen("sort.out","w",stdout);
   int a,b;
   cin>>a>>b;
   cout<<a<<b;
   return 0;
}
