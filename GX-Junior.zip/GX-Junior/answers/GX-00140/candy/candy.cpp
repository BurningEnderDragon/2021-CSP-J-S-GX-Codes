#include<iostream>
#include<cstdio>
using namespace std;
int candy(int q,int w,int e)
{
	long long max=0;
	for(int j=w;j<=e;j++)
	{
        int d=j;
		for(;;)
		{
			if(d<q)
				break;
			else
				d=d-q;
		}
		if(d>max)
			max=d;
		else
			;
	}
	return max;
}
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
	long long n,L,R;
	cin>>n>>L>>R;
	cout<<candy(n,L,R);
	return 0;
}
