#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("sort4.in","r",stdin);
    freopen("sort.out","w",stdout);
    long long int n,Q,a[100000],b[100000],c[100000],f;
    cin>>n>>Q;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
        b[i]=a[i];
    }


    for(int i=1;i<=Q;i++)
    {   int h=0,g=0;
        cin>>f>>h;
        if(f==1)
        {
            cin>>g;
            a[h]=g;
        }
        else
        {  for(int w=1;w<=n;w++)
             {   c[w]=a[w];
            //for(int w=1;w<=n;w++)
            for(int j=w;j>=2;j--)
                if(c[j]<c[j-1])
                {
                    int t=c[j-1];
                    c[j-1]=c[j];
                    c[j]=t;
                }

                }
            /*cin>>h;*/
            for(int k=1;k<=n;k++)
                if(b[h]==c[k])
                {cout<<k<<endl;
                break;}





        }




    }
    return 0;
}
