#include<bits/stdc++.h>
using namespace std;
int main()
{   freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int a[100000],b[100000],c[100000],d[100000],e[100000],p=0;
    char f1,f2,f3,f4;
    string m[100000];
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>m[i]>>a[i]>>f1>>b[i]>>f2>>c[1]>>f3>>d[i]>>f4>>e[i];
    /*for(int i=1;i<=n;i++)
        cout<<m[i]<<a[i]<<f1<<b[i]<<f2<<c[1]<<f3<<d[i]<<f4<<e[i]<<endl;*/
    for(int i=1;i<=n;i++)
        for(int j=0;j<m[i].size();j++)
           {

            if(m[j][i]=='S')
            {   p=0;
                if(a[i]<=255&&b[i]<=255&&c[i]<=255&&d[i]<=255&&e[i]<=65535)
                    {for(int k=1;k<=i;k++)
                       {

                        if(a[i]!=a[k]&&b[i]!=b[k]&&c[i]!=c[k]&&d[i]!=d[k]&&e[i]!=e[k])
                        {
                            cout<<"OK"<<endl;
                            break;
                        }
                        else
                        {
                            p++;
                        }
                        }if(p!=0)cout<<"FAIL"<<endl;}

                else
                    cout<<"ERR"<<endl;
                }
                else
                   {
                    p=0;
                    if(a[i]<=255&&b[i]<=255&&c[i]<=255&&d[i]<=255&&e[i]<=65535)
                      {

                        for(int k=1;k<=i;k++)
                        {
                           if(a[i]==a[k]&&b[i]==b[k]&&c[i]==c[k]&&d[i]==d[k]&&e[i]==e[k])
                           {

                            cout<<k<<endl;
                           break;
                           }
                           else p++;
                        }
                        if(p!=0)
                            cout<<"FAIL"<<endl;
                        }
                    else
                        cout<<"ERR"<<endl;
                   }

           }
    return 0;
}
