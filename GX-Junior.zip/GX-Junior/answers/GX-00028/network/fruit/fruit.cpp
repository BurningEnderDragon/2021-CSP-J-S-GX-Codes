#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    cout <<"1 5 8 11 13 14 15 17"<<endl;
    cout << "2 6 9 12 16 18"<<endl;
    cout << "3 7 10 19"<<endl;
    cout<<"4 20"<<endl;
    return 0;
}
