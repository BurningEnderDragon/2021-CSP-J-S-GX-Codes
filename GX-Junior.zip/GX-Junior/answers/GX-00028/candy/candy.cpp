#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen ("candy.in","r",stdin);
    freopen ("candy.out","w",stdout);
    int n,l,r;
    cin>>n>>l>>r;
    while (n<l)
    {
        l--;
    }
    cout <<l;
    return 0;
}
