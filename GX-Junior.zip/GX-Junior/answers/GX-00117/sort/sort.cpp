#include<bits/stdc++.h>
using namespace std;
int a[8005],b[8005];
int main(){
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int n,Q,fu,x,v,po;
    cin>>n>>Q;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    for(int i=1;i<=n;i++){
        b[i]=a[i];
    }
    for(int i=1;i<=Q;i++){
        cin>>fu;
        if(fu==1){
            cin>>x>>v;
            a[x]=v;
            b[x]=v;
        }
        else if(fu==2){
            cin>>x;
            po=x;
            for(int i=1;i<=n;i++){
                b[i]=a[i];
            }
            for(int k=1;k<=n;k++){
                for(int j=k;j>=2;j--){
                    int z=j-1;
                    if(b[j]<b[z]){
                        if(po==j)po=z;
                        else if(po==z)po=j;
                        int t = b[z];
                        b[z] = b[j];
                        b[j] = t;

                    }
                }
            }
        cout<<po<<endl;
        }

    }


    return 0;
}
