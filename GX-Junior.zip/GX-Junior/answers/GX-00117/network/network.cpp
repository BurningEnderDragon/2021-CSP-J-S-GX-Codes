#include<bits/stdc++.h>
using namespace std;
string a[1005],b[1005];
int fa(int a,int b){
    int c=a;
    for(int i=2;i<b;i++){
        c=c*a
    }
}
int main(){

    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int n,cnt=1,sum;
    bool flag1,flag2,flag3;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i]>>b[i];
    }
    for(int i=1;i<=b[i].length();i++){
        if(b[i]=='.'){
            for(int j=i-1;j>=0;j--){
                sum=sum+fa(10,cnt)*((int)b[i]-48);
                cnt++;
            }
        }
        if(b[i]=='.'){
            for(int j=i-1;j>=0;j--){
                sum=sum+fa(10,cnt)*((int)b[i]-48);
                cnt++;
            }
        }
        if(b[i]=='.'){
            for(int j=i-1;j>=0;j--){
                sum=sum+fa(10,cnt)*((int)b[i]-48);
                cnt++;
            }
        }
        if(b[i]=='.'){
            for(int j=i-1;j>=0;j--){
                sum=sum+fa(10,cnt)*((int)b[i]-48);
                cnt++;
            }
        }
    }
    return 0;
}
