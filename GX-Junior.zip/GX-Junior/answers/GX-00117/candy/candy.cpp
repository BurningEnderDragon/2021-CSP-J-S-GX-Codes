#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,L,R,big,sum;
    cin>>n>>L>>R;
    big=L%n;
    for(int i=L;i<=R;i++){
        sum=i%n;
        if(big<sum){
            big=sum;
        }
    }
    cout<<big;
    return 0;
}
