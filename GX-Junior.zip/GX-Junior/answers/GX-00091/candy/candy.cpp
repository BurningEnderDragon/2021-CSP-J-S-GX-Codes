#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
long long int n,l,r;
cin>>n>>l>>r;
long long int cnt=0;
long long int k=0;
if(k<l&&k<r){
k+=r;
}
for(int i=0;i<n;i++){
cnt=k-n;
if(cnt>n){
cnt=n-1;
}
cout<<cnt;
return 0;
}
}
