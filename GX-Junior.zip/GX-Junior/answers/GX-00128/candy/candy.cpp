#include<bits/stdc++.h>
using namespace std;
int n,l,r;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    cin>>n>>l>>r;
    if(l==r)
        cout<<r%n;
    else
    {
        int num=r/n;
        if(l<n*num)
            cout<<n-1;
        else
            cout<<r%n;
    }
    return 0;
}
