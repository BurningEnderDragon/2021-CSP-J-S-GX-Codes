#include<bits/stdc++.h>
using namespace std;
int n;
string op,ad;
map<string,int> ads;
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;++i)
    {
        cin>>op>>ad;
        bool ok=true;
        int cnt=0;
        for(int j=0;j<ad.size();++j)
        {
            if(ad[j]=='0' and ('0'<=ad[j+1] and ad[j+1]<='9'))
            {
                ok=false;
                break;
            }
            ++cnt;
            long long num=0;
            while('0'<=ad[j] and ad[j]<='9')
            {
                num=num*10+((ad[j]-'0')%10);
                ++j;
            }
            if(cnt==5)
            {
                if(num>65535)
                {
                    ok=false;
                    break;
                }
            }
            else
            {
                if(num>255)
                {
                    ok=false;
                    break;
                }
            }
            if(cnt==4)
            {
                if(ad[j]!=':')
                {
                    ok=false;
                    break;
                }
            }
            else if(cnt<4)
            {
                if(ad[j]!='.')
                {
                    ok=false;
                    break;
                }
            }
        }
        if(ok==false)
        {
            cout<<"ERR"<<endl;
            continue;
        }
        if(op=="Server")
        {
            if(ads[ad])
                cout<<"FAIL"<<endl;
            else
            {
                cout<<"OK"<<endl;
                ads[ad]=i;
            }
        }
        else
        {
            if(ads[ad])
                cout<<ads[ad]<<endl;
            else
                cout<<"FAIL"<<endl;
        }
    }
    return 0;
}
