#include<bits/stdc++.h>
using namespace std;
const int N=8000+5;
int n,q,a[N],op,x,v;
struct SortNumber
{
    int num,flag=false;
}
b[N];
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    scanf("%d%d",&n,&q);
    for(int i=1;i<=n;++i)
    {
        scanf("%d",&a[i]);
        b[i].num=a[i];
    }
    for(int t=1;t<=q;++t)
    {
        scanf("%d",&op);
        if(op==1)
        {
            scanf("%d%d",&x,&v);
            a[x]=v;
        }
        else
        {
            scanf("%d",&x);
            b[x].flag=true;
            for(int i=1;i<=n;++i)
                b[i].num=a[i];
            for(int i=1;i<=n;++i)
                for(int j=i;j>=2;--j)
                    if(b[j].num<b[j-1].num)
                        swap(b[j],b[j-1]);
            for(int i=1;i<=n;++i)
            {
                if(b[i].flag)
                {
                    printf("%d\n",i);
                    b[i].flag=false;
                    break;
                }
            }
        }
    }
    return 0;
}
