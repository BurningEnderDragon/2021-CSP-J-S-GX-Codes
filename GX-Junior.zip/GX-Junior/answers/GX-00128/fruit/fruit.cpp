#include<bits/stdc++.h>
using namespace std;
const int N=2*1e5+5;
int n,cnt;
struct fruit
{
    int knd,num;
}f[N];
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    f[0].knd=-1;
    scanf("%d",&n);
    for(int i=1;i<=n;++i)
    {
        scanf("%d",&f[i].knd);
        f[i].num=i;
    }
    while(n)
    {
        cnt=0;
        for(int i=1;i<=n;++i)
        {
            if(f[i].knd==f[i-1].knd)
                f[++cnt]=f[i];
            else
                printf("%d ",f[i].num);
        }
        printf("\n");
        n=cnt;
    }
    return 0;
}
