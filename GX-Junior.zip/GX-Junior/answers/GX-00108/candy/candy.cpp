#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    long long n,l,r,sum=0,sum1=0;
    cin>>n>>l>>r;
    sum=l/n*n+n-1;
    if(sum>r) cout<<r%n;
    else cout<<sum%n;
    return 0;
}
