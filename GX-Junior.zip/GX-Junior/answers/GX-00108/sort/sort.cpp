#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int n;
    long long q,a[8002],x,v,b[8002],t;
    cin>>n>>q;
    for(int i=1;i<=n;i++)
        cin>>a[i];
    for(long long i=0;i<q;i++)
    {
        for(int j=1;j<=n;j++)
        {
            b[j]=a[j];
        }
        cin>>t;
        if(t==1)
        {
            cin>>x>>v;
            a[x]=v;
        }
        if(t==2)
        {
            cin>>x;
            for(int j=1;j<=n;j++)
            {
                for(int w=j;w>=2;w--)
                {
                    if(b[w]<b[w-1])
                    {
                        int p=b[w-1];
                        b[w-1]=b[w];
                        b[w]=p;
                        if(x==w) x--;
                        else if (x==w-1)x++;
                    }
                }
            }
            cout<<x<<endl;
        }
    }
    return 0;
}
