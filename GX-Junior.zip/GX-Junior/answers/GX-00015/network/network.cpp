#include <bits/stdc++.h>

using namespace std;

int main()
{
int u;
cin>>u;

string h[u];

for(int p=0;p<=u;p++)

}









}
