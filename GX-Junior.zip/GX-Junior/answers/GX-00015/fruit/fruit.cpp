#include <bits/stdc++.h>

using namespace std;


int main()
{
    int op=0;

    cin>>op;


    char a[op];
    cin.get(a,'/n');
cout<<a;


}
