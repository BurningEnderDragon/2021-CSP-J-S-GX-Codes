#include <bits/stdc++.h>

using namespace std;

int main()
{
   freopen("candy.in","r",stdin);

  freopen("candy.out","w",stdout);

    int n;

    int L,R;

    cin>>n>>L>>R;
    int op;
    if(L<R)
    {
        op=R-L;
        op=op+1;
    }
    else
    {
        op=10;

    }

    int op2=99;
    int mun=L;
    int sh=L;
    int show=0;
    int u=L;
    for(int op1=0;op1<=op;op1++)
    {

        for(int m=0;m<=op2;m++)
        {
            if(u>=n)
            {
                u=u-n;
            }

        }

        if(show<u)
        {

            show=u;
        }
        if(show>u)
        {
            u=show;

        }

        u=L+op1;


    }

   cout<<show;
   return show;

}
