#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	int n,Q;
	cin>>n>>Q;
	cout<<Q;
	return 0;
}
