#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	int n;
	char a[1000000]
	cin>>n;	
	for(int i=1;i<=n;++i)
	{
		cin>>a[i];
	cout<<"FAIL";
	}
	return 0;
}
