#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	int n,L,R,x,z,b,o,t;
	int a[1000000];
	cin>>n>>L>>R;
	z=R-L+1;
	o=L;
	for(int i=1;i<=z;++i)
	{
		t=o;
		x=o-n;
		if(o==R)
		{
			break;
			}
		if(x>n)
		{
			o=x;
			}
		if(x<n)
		{
			a[i]=x;
			o=t;
		
		if(a[i]>a[i-1])
			{
				b=a[i];
				o++;
				}
		else if(a[i]<=a[i-1])
		{
			b=a[i-1];
			o++;
			}
		}
	}
	cout<<b;
	return 0;
}
