#include<iostream>
using namespace std;
int main(){
     freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int n,q,a[1000],m[1000],s[1000];
    cin>>n>>q;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    for(int i=1;i<=q;i++){
        cin>>m[i]>>s[i];
    }
    for(int i=1;i<=n;i++){
        s[i]=a[i];
    }
    for(int i=1;i<=n;i++){
         for(int j=i;j>=2;j--){
             if(a[j]<a[j-1]){
                int t=a[j-1];
                a[j-1]=a[j];
                a[j]=t;
              }
          }
    }
    for(int i=1;i<=n;i++){
        for(int j=n;j>i;j--){
            if(s[i]==a[i]){
                cout<<n<<endl;
            }
        }
    }
    return 0;
}
