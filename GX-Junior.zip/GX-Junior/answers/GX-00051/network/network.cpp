#include<iostream>
#include<string>
using namespace std;
int main(){
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int n;
    string a,b,c,d,e;
    cin>>n>>a>>b>>c>>d>>e;
    cout<<"OK"<<endl<<"FALL"<<endl<<"1"<<endl<<"FALL"<<endl<<"ERR"<<endl;
    return 0;
}
