#include<iostream>
using namespace std;
int main(){
    //freopen("candy.in","r",stdin);
    //freopen("candy.out","w",stdout);
    long n,l,k=0,r,a[1000],p=0;
    cin>>n>>l>>r;
    for(int i=l;i<=r;i++){
        k=k+1;
        a[k]=i;
    }
    for(int i=1;i<=k;i++){
        while(a[i]>=n){
            a[i]=a[i]-n;
        }
    }
    p=a[1];
    for(int i=2;i<=k;i++){
        if(a[i]>p){
            p=a[i];
        }
    }
    cout<<p;
    return 0;
}
