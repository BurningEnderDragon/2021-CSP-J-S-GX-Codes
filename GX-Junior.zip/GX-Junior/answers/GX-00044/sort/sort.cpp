#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int n,Q;
    cin>>n>>Q;
    int a[n-1]={};
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
