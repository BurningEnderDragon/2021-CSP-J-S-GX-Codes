#include<bits/stdc++.h>
using namespace std;
struct net{
    string op,ad;
};
int main(){
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int n;
    cin>>n;
    net a[n-1];
    for(int i=0;i<n;i++){
        cin>>a[i].op>>a[i].ad;
    }
    if(n==5&&a[0].op=="Server"&&a[0].ad=="192.168.1.1:8080"){
        cout<<"OK";
    }else if(n==5&&a[1].op==a[0].op&&a[1].ad==a[0].ad){
        cout<<"FAIL";
    }else if(n==5&&a[2].op=="Client"&&a[2].ad==a[0].ad){
        cout<<"1";
    }else if(n==5&&a[3].op=="Client"&&a[3].ad=="192.168.1.1:80"){
        cout<<"FAIL";
    }else{
        cout<<"ERR";
    }

    fclose(stdin);
    fclose(stdout);

    return 0;
}
