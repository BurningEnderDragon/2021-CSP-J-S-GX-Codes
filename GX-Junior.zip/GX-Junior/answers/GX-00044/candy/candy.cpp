#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,L,R,k=0,m=0;
    cin>>n>>L>>R;
    int a[R-L]={};
    if(R<2*n){
        cout<<R-n;
    }else{
        for(int i=L;i<=R;i++){
        do{
            i=i-n;
        }while(i>=n);
        a[k]=i;
        k++;
    }
    for(int i=0;i<=R-L;i++){
        if(a[i]>=m){
            m=a[i];
        }
    }
    cout<<m;

    }
    fclose(stdin);
    fclose(stdout);



    return 0;
}
