#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","r",stdout);

    int n,k,l,r;
    cin>>n>>l>>r;
    for(int i=l;i<=r;i++)
    {
        k=i%n;
        int maxs;
        if(k>=maxs)
        {
            maxs=k;

        }
    }
    cout<<maxs;
    return 0;
}
