#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);

    int n,q,a[8005],x,v;
    cin>>n>>q;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
    }
    int ways;
    for(int j=1;j<=q;j++)
    {
        cin>>ways>>x>>v;
        if(ways==1)
        {
            a[x]=v;
        }
        else
        {
            for (int i1 = 1; i1 <= n; i1++)
                for (int j1 = i1; j1>=2; j1‐‐)
                    if ( a[j]1 < a[j1‐1] ){
                        int t = a[j1‐1];
                        a[j1‐1] = a[j1];
                        a[j1] = t;

                        }
            for(int k=1;k<=n;k++)
            {
                if(a[k]==a[x])
                {
                    int x1=k;
                }
            }
            cout<<k;
        }
    }
    return 0;
}
