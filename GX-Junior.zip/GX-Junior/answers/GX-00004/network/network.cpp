#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);

    int n;
    char op,ad;
    for(int i=1;i<=n;i++)
    {
        cin>>op>>ad;
    }
    return 0;
}
