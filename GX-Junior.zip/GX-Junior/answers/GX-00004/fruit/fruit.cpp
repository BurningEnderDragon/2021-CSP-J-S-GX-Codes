#include<bits/stdc++.h>
using namespace std;
void sort(s[sa]);
void sort(x[xa])
{
    for(int z=1;z<=xa;z++)
    {
        for(int o=1;o<=xa-1;o++)
        {
            if(x[xa]>x[xa+1])
            {
                int temp1=x[xa];
                x[xa]=x[xa+1];
                x[xa+1]=temp1;
            }
            cout<<x[xa]<<" ";
        }
    }
    return 0;
}
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);

    int n,a[2000];
    int tot=0,x[2000];
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];


    }
    int xa=1;
    for(int k=1;k<=n;k+=tot)
    {
        for(int j=k;j<=n;j++)
        {
            if(a[j]==a[j+1])
            {
                tot++;
            }
            else
            {
                tot++;
                x[xa]=a[j-1]-tot;
                xa++
                break;
            }
            sort(x[xa]);
        }
        cout<<endl;
    }
    return 0;
}
