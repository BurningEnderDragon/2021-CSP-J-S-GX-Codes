#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);

    int n,L,R,k,s,j,a[j];
    cin>>n>>L>>R;
    for(k=L;k<=R;k++)
    {
        for(int i=1;i<=k/n;i+=1)
        {
            for(int j=1;j<=i;j++)
            {
                a[j]=k-n;
                if(a[j]>a[j-1])
                    s=a[j];
                if(a[j]<=a[j-1])
                    a[j]=a[j-1];
                    s=a[j];
            }
        }
    cout<<s;
    return 0;
    }
}

