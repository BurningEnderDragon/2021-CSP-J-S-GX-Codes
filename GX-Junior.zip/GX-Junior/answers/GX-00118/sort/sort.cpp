#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int a[8000+5],b[8000+5];
int n,q;
int y,x,v,c;
int ans=0;
int made2(int x)
{
	for(int i=1;i<=n;i++)
		b[i]=a[i];
	ans=x;
	for(int i=1;i<=n;i++)
		for(int j=i;j>=2;j--)
			if(b[j]<b[j-1])
			{
				
				int t=b[j-1];
				b[j-1]=b[j];
				b[j]=t;
				if(j-1==ans)
				{
					ans++;
					continue;
				}
				if(j==ans)
				{
					ans--;
					continue;
				}
			}
	return ans;
}
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int w=1;w<=q;w++)
	{
		scanf("%d",&c);
		if(c==1)
		{
			scanf("%d%d",&x,&v);
			a[x]=v;
		}
		if(c==2)
		{
			scanf("%d",&y);
			made2(y);
			printf("%d",ans);
			cout<<endl;
		}
	}
	return 0;
}
