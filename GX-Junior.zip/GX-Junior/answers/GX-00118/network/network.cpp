#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
using namespace std;

int main()
{
	
}
