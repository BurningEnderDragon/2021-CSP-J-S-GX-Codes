#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
long long l,r,n;
long long ans=0;
long long r1,r2,w,r3,r4;

int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%lld%lld%lld",&n,&l,&r);
	int q=0;
	long long m=n-1;
	r1=r-m;
	if(r1<n)
	{
		ans=r-n;
		w=r;
	}
	if(r1>m)
	{
		r2=r1%n;
		r3=r1/n;
		w=r-r2;
		ans=m;
	}
	while(1)
		if(w<l)
		{
			q=1;
			w++;
			ans++;
			if(ans==n)
			{
				ans=0;
				r3++;
			}
		 }
		 else break;
	if(q==1)
		if(ans<r-r3*n)
			ans=r-r3*n;
	printf("%lld",ans);
	return 0;
}
