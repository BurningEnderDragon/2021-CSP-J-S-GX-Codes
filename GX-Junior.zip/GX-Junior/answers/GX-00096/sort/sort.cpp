#include<bits/stdc++.h>
using namespace std;
int a[8050];
int n,q,x,k;
int crsort(){
    int b[8050];
    for(int i=1;i<=n;i++){
        b[i]=a[i];
    }
    int p=x;

    for(int i=1;i<=n;i++){
        for(int j=i;j>=2;j--){
            if(b[j] < b[j-1]){
                int t = b[j-1];
                b[j-1]=b[j];
                b[j] = t;
                if(j==p){
                    p--;
                }
                else if(j-1==p){
                    p++;
                }
            }
        }
    }

    return p;
}

int main(){
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);

    cin>>n>>q;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    for(int i=1;i<=q;i++){
        cin>>k>>x;
        if(k==1){
            cin>>a[x];
        }
        else{
            cout<<crsort()<<endl;
        }
    }

    return 0;
}
