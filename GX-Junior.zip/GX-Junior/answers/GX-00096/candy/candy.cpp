#include<bits/stdc++.h>
using namespace std;

int main(){
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,l,r,s=0;
    cin>>n>>l>>r;
    while(r>=l){
        int mid=(r+l)/2;
        int x=mid%n;
        if(x>s){
            s=x;
            l=mid+1;
        }
        else{
            r=mid-1;
        }
    }
    cout<<s;
    return 0;
}
