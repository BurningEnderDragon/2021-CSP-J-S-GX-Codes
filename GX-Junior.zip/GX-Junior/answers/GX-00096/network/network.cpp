#include<bits/stdc++.h>
using namespace std;

bool adckeck(string a){
    int nd=0,nm=0,nf=0;
    for(int i=0;i<a.size();i++){
        if(a[i]=='.'){
            nd++;
            nf++;
        }
        if(a[i]==':' and nf==3){
            nm++;
        }
    }
    if(nd==3 and nm==1){
        int l=0;
        for(int i=0;i<a.size();i++){
            if(a[i]=='.' or a[i]==':'){
                if(i-1-l>1 and a[l]=='0'){
                    return false;
                }
                if(i-1-l<0){
                    return false;
                }
                int x=0;
                for(int j=l;j<i;j++){
                    x=x*10+a[j]-'0';
                }

                if(x<0 or x>255){
                    return false;
                }
                l=i+1;
            }
        }
        int x=0;
        for(int j=l;j<a.size();j++){
            x=x*10+a[j]-'0';
        }
        if(x<0 or x>65535){
            return false;
        }
        return true;
    }
    else{
        return false;
    }
}

int sf[1010];
string server[1010];

int main(){
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int n,sn=0;
    cin>>n;
    for(int i=0;i<n;i++){
        string op,ad;
        cin>>op>>ad;
        if(adckeck(ad)){
            if(op=="Server"){
                int f=1;
                for(int j=0;j<sn;j++){
                    if(server[j]==ad and sf[j]==1){
                        f=0;
                        break;
                    }
                }
                server[sn]=ad;
                if(f){
                    sf[sn]=1;
                    sn++;
                    cout<<"OK"<<endl;
                }
                else{
                    sf[sn]=-1;
                    sn++;
                    cout<<"FAIL"<<endl;
                }
            }
            if(op=="Client"){
                int f=1;
                for(int j=0;j<sn;j++){
                    if(server[j]==ad and sf[j]==1){
                        cout<<j+1<<endl;
                        f=0;
                        break;
                    }
                }
                server[sn]=ad;
                sn++;
                if(f){
                    cout<<"FAIL"<<endl;
                }
            }
        }
        else{

            server[sn]=ad;
            sf[sn]=-1;
            sn++;

            cout<<"ERR"<<endl;
        }
    }
    return 0;
}
