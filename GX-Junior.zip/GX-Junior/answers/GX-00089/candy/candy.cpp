#include<iostream>
#include<cstdio>
#include<map>
#include<string>
#include<cstring>
#include<cmath>
using namespace std;
int n,l,r,x;
int ans=1;
void q()
{
	cin>>n>>l>>r;
}
void w()
{
	for(x=l;x<=r;x++) {int s=x%n;ans=max(ans,s);}
    cout<<ans;
}
int main()
{
   freopen("candy.in","r",stdin);
   freopen("candy.out","w",stdout);
   q();
   w();
   return 0;
}
