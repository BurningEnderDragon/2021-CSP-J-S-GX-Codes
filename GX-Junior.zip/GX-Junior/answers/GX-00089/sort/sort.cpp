#include<iostream>
#include<cstdio>
#include<map>
#include<string>
#include<cstring>
#include<cmath>
using namespace std;
int a[10001],n,m,t;
int main()
{
   freopen("sort.in","r",stdin);
   freopen("sort.out","w",stdout);
   scanf("%d%d",&n,&m);
   for(int i=1;i<=n;i++)
      scanf("%d",&a[i]);
   for(int i=1;i<=n;i++)
      for(int j=i;i>=1;j--)
         if(a[j]<a[j-1])
         {
            t=a[j-1];
            a[j-1]=a[j];
            a[j]=t;
         }
   for(int i=1;i<=n;i++)
   {
	   if(a[i]<a[i]-1)
	   {
		   t+=a[i];
		   a[i-1]-=a[i];
	   }
	   else
	      for(int j=1;j<n;j++)
	      {
			  a[j]+=a[i];
			  a[i-1]-=t;
	      }
   cout<<a[i]<<endl;
   }
   return 0;
}
