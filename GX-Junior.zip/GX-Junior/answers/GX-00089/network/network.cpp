
#include<iostream>
#include<cstdio>
#include<map>
#include<string>
#include<cstring>
#include<cmath>
using namespace std;
int n;
char ch[101]=" ";
string a;
void happy(string q)
{
	for(int x=1;x<=n;x++)
	   for(int i=x;i>=1;i--)
	   {
		   if(a[x]==a[x-1])
		      q[i]+=a[x-1];
		   else
		      a[i]=a[x]*n;
	   }
}
int main()
{
   freopen("network.in","r",stdin);
   freopen("netkork.out","w",stdout);
   scanf("%d",&n);
   for(int x=1;x<=n;x++)
      cin>>a[x];
   for(int x=1;x<=n;x++)
   {  
	 ch[x]=a[x+1];
	 if(a[x]<ch[x])
	    cout<<"OK"<<endl;
	 if(a[x]==a[x])
	    cout<<"FAIL"<<endl<<1<<endl;
     if(a[x]>ch[x])
        cout<<"ERR"<<endl;
   }
   return 0;
}
