#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cmath>
#include<string>
using namespace std;
int n,len=0;
string ch;
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	{
		cin >> ch;
		len=ch.size();
		for (int j=1;j<=len;j++)
		{
			cin >> ch[i];
			if (ch[8]=='0')	
					cout << "ERR";
		}
	}
	return 0;
}

