#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<algorithm>
using namespace std;
int n,a[1000001];
int main()
{
		freopen("fruit.in","r",stdin);
		freopen("fruit.out","w",stdout);
		scanf("%d",&n);
		for (int i=1;i<=n;i++)
			cin >> a[i];
		
	
	
	return 0;
}








