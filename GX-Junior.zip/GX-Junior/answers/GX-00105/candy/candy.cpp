#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;

int n,L,R,ans,max;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin >> n >> L >> R;
	ans=R/n;
	if (R-n<n)	
		cout << R-n;
	else	
		cout << ans*n-ans*n+n-1;
	
	return 0;
}
