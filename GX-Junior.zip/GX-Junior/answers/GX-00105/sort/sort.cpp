#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cmath>
#include<string>
using namespace std;

int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	
	return 0;
}

