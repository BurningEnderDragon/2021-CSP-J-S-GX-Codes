#include<iostream>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,l,r,c=0,b=0;
    cin>>n>>l>>r;
    for(int i=l;i<r;i++)
    {
        c=i;
        abc:
        c=c-n;
        if(c>=n)
            goto abc;
        else
            {
                if(c>b)
                {
                    b=c;c=0;
                }
                else
                {
                    ;
                }
            }
    }
    cout<<b<<endl;
    return 0;
}
