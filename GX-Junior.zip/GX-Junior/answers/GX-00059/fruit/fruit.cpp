#include<iostream>
using namespace std;
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    int n,a[1005];
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    return 0;
}
