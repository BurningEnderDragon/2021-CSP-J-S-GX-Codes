#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n, L, R;
    int sum =0;
    int max = 0;
    cin >> n >> L >> R;
    for(int i = 1; i <= R - L; i++)
    {
        sum = L + i;
        while(sum - n >= 0)
        {
            sum = sum - n;
            if(sum - n < 0 && sum > max)
            {
               max = sum;
               break;
            }
        }
    }
    cout << max;
    return 0;
}
