#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<algorithm>
using namespace std;
int n,q,a[100000000];
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	cin>>n;
	
	for (int i = 1; i <= n; i++)
        for(int i=1;i<=n;i++)
	        cin>>a[i];
	    for (int j = i; j>=2; j‐‐)
            if(a[j]<a[j‐1])
            {
                int t = a[j‐1];
                a[j‐1] = a[j];
                a[j] = t;
                cout<<a[j]<<endl;
            }
    return 0;
}
