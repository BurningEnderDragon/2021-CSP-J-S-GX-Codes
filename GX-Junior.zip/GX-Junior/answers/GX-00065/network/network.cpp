#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<string>
using namespace std;
int n;
string s[1001];
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	    cin>>s[i];
	for(int i=1;i<=n;i++)
	{
	    if(cin>>'Server'||cin>>'Client')
	        
	        	
    }
