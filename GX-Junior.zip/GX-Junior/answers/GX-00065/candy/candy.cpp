#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<algorithm>
using namespace std;
int n,l,r,x,y,z;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>n>>l>>r;
	for(int i=l;i<=r;i++)
	{
		x=i/n;
		y=i-x*n;
		if(y>z)
		    z=y;
		
	}
	cout<<z;
	return 0;
}
