#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<string>
using namespace std;
int n;
int a[200001];
int ans=0;
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>a[i];
    for(int i=1;i<=n;i++)
    {
	    if(a[i]==1)
	        cout<<i<<" ";
	        if(a[i]==a[i+1])
	            i++;
	    if(a[i]==0)
	        cout<<i<<" ";
	        if(a[i]==a[i+1])
	            i++;
	         
	}
	return 0;
}
