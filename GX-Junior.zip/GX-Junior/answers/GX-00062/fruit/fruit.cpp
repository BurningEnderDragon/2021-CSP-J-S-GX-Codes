#include<iostream>
#include<cstdio>
#include<queue>
using namespace std;
const int MAX=2*10e5+20;
struct node{
    int le,ri,sum;
}ff;
int n;
int a[MAX];
queue<node> l;
queue<node> r;
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    cin>>n;
    scanf("%d",&a[1]);
    int before=a[1];
    ff.le=1;
    ++ff.sum;
    for(int i=2;i<=n;++i)
    {
        scanf("%d",&a[i]);
        if(a[i]!=before)
        {
            ff.ri=i-1;
            l.push(ff);
            ff.le=i;
            ff.sum=1;
            before=a[i];
        }
        else
        {
            ++ff.sum;
        }
    }
    ff.ri=n;
    l.push(ff);
    node mid;
    while(!l.empty()||!r.empty())
    {
        if(r.empty())
        {
            int ret=l.size();
            for(int i=1;i<=ret;++i)
            {
            mid=l.front();
            printf("%d ",mid.le);
            ++mid.le;
            --mid.sum;
            if(mid.sum)r.push(mid);
            l.pop();
            }
        }
        else
        {
            int ret=r.size();
            for(int i=1;i<=ret;++i)
            {
            mid=r.front();
            printf("%d ",mid.le);
            ++mid.le;
            --mid.sum;
            if(mid.sum&&mid.le<=mid.ri)l.push(mid);
            r.pop();
            }
        }
        printf("\n");

    }
    return 0;
}
