#include<iostream>
#include<cstdio>
#include<map>
#include<string>
#include<cstring>
using namespace std;

bool wari=0;
int n;
int main()
{
    freopen("network.in","r",stdin);
    //freopen("network.out","w",stdout);
    cin>>n;
    string in,ip;
    if(n==5)
    {
        cin>>ip;
    }
    /*while(n--)
    {
        cin>>in;
        if(in[0]=='S')
        {
            cin>>ip;
            int sum=0,num=0,e=0,big=0;
            for(int i=0;i<in.length();++i)
            {
                if(sum>3||num>3)
                {
                    cout<<"ERR"<<endl;
                    break;
                    }
                if(big>255||big<0){
                        cout<<"ERR"<<endl;
                        break;
                }
                if(ip[i]>='0'&&ip[i]<='9')
                {
                    ++sum;
                    big*=10;
                    big+=ip[i]-'0';
                    continue;
                }
                else if(ip[i]=='.')
                {
                    sum=0;
                    big=0;
                    ++num;
                }
                else if(num==3&&ip[i]==':')
                {
                    long long p=0;
                    wari=0;
                    for(int j=i+1;j<in.length();++j)
                    {
                        if(p>5||e>65536||e<0)
                        {
                            wari=1;
                            cout<<"ERR"<<endl;
                            break;
                        }
                        e*=10;
                        e+=ip[j]-'0';
                        ++p;
                    }

                }
                else if(num<3&&ip[i]>'9'&&ip[i]<'0'&&ip[i]!='.')
                {
                    cout<<"ERR"<<endl;
                    break;
                }
            }
            if(wari=1)break;
            if(mapp[ip])cout<<"FAIL"<<endl;
            else mapp[ip]=1;
        }
        else
        {
            cin>>ip;
            int sum=0,num=0,e=0,big=0;
            for(int i=0;i<in.length();++i)
            {
                if(sum>3||num>3)
                {
                    cout<<"ERR"<<endl;
                    break;
                    }
                if(big>255||big<0){
                        cout<<"ERR"<<endl;
                        break;
                }
                if(ip[i]>='0'&&ip[i]<='9')
                {
                    ++sum;
                    big*=10;
                    big+=ip[i]-'0';
                    continue;
                }
                else if(ip[i]=='.')
                {
                    sum=0;
                    big=0;
                    ++num;
                }
                else if(num==3&&ip[i]==':')
                {
                    long long p=0;
                    wari=0;
                    for(int j=i+1;j<in.length();++j)
                    {
                        if(p>5||e>65536||e<0)
                        {
                            wari=1;
                            cout<<"ERR"<<endl;
                            break;
                        }
                        e*=10;
                        e+=ip[j]-'0';
                        ++p;
                    }

                }
                else if(num<3&&ip[i]>'9'&&ip[i]<'0'&&ip[i]!='.')
                {
                    cout<<"ERR"<<endl;
                    break;
                }
            }
                                if(wari=1)break;
                    if(mapp[ip]){
                            cout<<mapp[ip]<<endl;
                            mapp[ip]+=1;
                    break;
                    }
                    else cout<<"FAIL"<<endl;
        }*/
    }
    return 0;
}
