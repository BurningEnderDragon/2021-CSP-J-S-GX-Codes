#include<iostream>
#include<cstdio>
using namespace std;
long long n,L,R;
int main()
{
     freopen("candy.in","r",stdin);
     freopen("candy.out","w",stdout);
     cin>>n>>L>>R;
     if(R-L>=n)cout<<n-1<<endl;
     else if(R-L<n)cout<<(R-n)%n<<endl;
    return 0;
}
