#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
const int MAX=10e5+20;
long long n,q;
long long a[MAX];
struct node{
    int x;
    long long val;
}head[MAX];
bool cmp(node a,node b)
{
    return a.val<b.val;
}
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    cin>>n>>q;
    for(int i=1;i<=n;++i)
    {
        scanf("%lld",&a[i]);
        head[i].val=a[i];
        head[i].x=i;
    }
    sort(head+1,head+1+n,cmp);
    for(int qp=1;qp<=q;++qp)
    {
        //cout<<"text"<<endl;
        int in;
        scanf("%d",&in);
        if(in==1)
        {
            int inx,iny;
            scanf("%d%d",&inx,&a[inx]);
            //a[inx]=iny;
            for(int i=1;i<=n;++i)
            {
                head[i].x=i;
                head[i].val=a[i];
            }
            sort(head+1,head+1+n,cmp);
        }
        if(in==2)
        {
            int in3;
            scanf("%d",&in3);
            for(int i=1;i<=n;++i)
            {
                /*if(head[i].x==in3)
                {
                    printf("%d\n",in3);
                }*/
             cout<<"1"<<endl;
            }
        }
    }
    return 0;
}
