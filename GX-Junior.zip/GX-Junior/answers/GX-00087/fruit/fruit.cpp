#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
struct t{
  int s,e,nx,pi,sn,si,s1[21],en,ei,e1[21];
}d[200001];
int n,num;
int main()
{
  freopen("fruit.in","r",stdin);
  freopen("fruit.out","w",stdout);
  scanf("%d",&n);
  d[0].pi=5418;
  for(int i=1,k;i<=n;i++)
  {
	  scanf("%d",&k);
	  if(k!=d[num].pi)
	  {
		  num++;
		  d[num].s=i;
		  d[num].nx++;
		  d[num].pi=k;
	  }
	  else 
	  {
		  d[num].e++;
		  d[num].nx++;
	  }
  }
  while(n>0)
  {
	  for(int i=1;i<=num;i++)
	  {
		  if(d[i].nx>=0)
		  {
		  printf("%d ",d[i].s);
		  d[i].nx--;
		  n--;
		  d[i].s++;  
		  if(d[i].s==d[i].s1[d[i].si])
		  {
			d[i].si++;
			d[i].ei++;
		    d[i].s=d[i].e1[i];
		    d[i].e=d[i].e1[i];
	      }
	      if(d[i].nx==-1&&d[i-1].pi==d[i+1].nx)
	      {
			  d[i-1].e=d[i+1].e;
			  d[i-1].nx+=d[i+1].nx;
			  d[i+1].nx=-1;
			  d[i-1].en++;
			  d[i-1].s1[d[i-1].en]=d[i-1].e+1;
			  d[i-1].e1[d[i-1].en]=d[i+1].s-1;
		  }
	  }
	}
	printf("\n"); 
  }
  return 0;
}

