#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int n,m,num,d,t;
struct dy{
	string h;
	int ik;
};
dy f[1001];
bool p(string str)
{
	for(int i=0;i<str.size();i++)
	{
		if(str[i]=='.'&&m!=1)  
		  if(num>255) {
			   return false;
			   d++;
			   num=0;
		    }
		if(((str[i]>='0')||(str[i]=='0'&&num!=0))&&str[i]<='9')
		  num=num*10+int(str[i]-'0');
		else return false;
		if(str[i]==':'&&d==3)
		{
		  m=1;
		  if(num>255) {
			   return false;
			   d++;
			   num=false;
		   }			
		   else return false;
		}
		else return false;
	}
	if(num>=65535) return false;
	return true;
}
int main()
{
  freopen("network.in","r",stdin);
  freopen("network.out","w",stdout);                                                                           
  cin>>n;
  for(int j=1;j<=n;j++)
  {
	  string str1,str2;
	  cin>>str1>>str2;
	  if(str1=="Server") 
	  {
		  bool flag=false;
		  if(p(str2))
		  {
		  for(int i=1;i<=t;i++)
		    {
			  if(str2==f[i].h)
			  {
				  flag=true;
				  break;
			  }
	        }
		    if(flag==false)
		    {
			  cout<<"OK"<<endl;
			  t++;
			  f[t].h=str2;
			  f[t].ik=j;
	        }
	        else cout<<"FAIL"<<787<<j<<endl;
	      }
	      else cout<<"ERR"<<endl;
	  }
	  else
	  {
		  if(p(str2))
		  {
			  bool flag=false;
			  for(int i=1;i<=t;i++)
			  {
				  if(str2==f[i].h)
				  {
					  cout<<f[i].ik<<endl;
					  flag=true;
					  break;
				  }
			  }
			  if(flag==false)
			    cout<<"FAIL"<<"878"<<endl;
		  }
		  else cout<<"ERR"<<endl;
	  }
  }
  return 0;
}
