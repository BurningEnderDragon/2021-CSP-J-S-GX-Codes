#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int n,m,a[8001],b[8001];
void fu() {
	for(int i=1;i<=n;i++)
	  b[i]=a[i];
}
bool cmp(int a,int b)
{
	return a>b;
}
int main()
{
  freopen("sort.in","r",stdin);
  freopen("sort.out","w",stdout);
  cin>>n>>m;
  for(int i=1;i<=n;i++)
  {
	cin>>a[i];
	b[i]=a[i];
  }
  for(int i=1;i<=m;i++)
  {
	  int x,A,B;
	  cin>>x;
	  if(x==1)
	  {
		  cin>>A>>B;
		  a[A]=B;
		  b[A]=B;
	  }
	  if(x==2)
	  {
		  cin>>A;
		  sort(b+1,b+n+1,cmp);
		  cout<<b[A]<<endl;
		  fu(); 
	  }
  }
  return 0;
}

