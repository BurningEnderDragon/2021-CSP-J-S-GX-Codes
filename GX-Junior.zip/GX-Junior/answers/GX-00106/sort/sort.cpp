#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
long long n,Q,c[8010];
struct cpo
{
  long long id,num;
}a[8010];
bool cmp(cpo x,cpo y)
{
  if(x.num==y.num)  return x.id<y.id;
  else  return x.num<y.num;
}
void change(long long &x,long long &y)
{
  long long t=x;
  x=y;
  y=t;
}
int main()
{
  freopen("sort.in","r",stdin);
  freopen("sort.out","w",stdout);
  cin>>n>>Q;
  for(int i=1;i<=n;i++)
  {
    scanf("%lld",&a[i].num);
    a[i].id=i;
  }
  sort(a+1,a+1+n,cmp);
  for(int i=1;i<=n;i++)
    c[a[i].id]=i;
  for(int i=1,pd,s,v;i<=Q;i++)
  {
    cin>>pd;
    if(pd==1)
    {
      cin>>s>>v;
      int g=c[s],flag=0;
      a[g].num=v;
      while(a[g+1].num<=a[g].num&&g<n)
      {
        flag=1;
        change(a[g+1].num,a[g].num);
        change(a[g+1].id,a[g].id);
        c[a[g+1].id]++;
        c[a[g].id]--;
        g++;
      }
      if(!flag)
      {
        while(a[g-1].num>a[g].num&&g>=2)
        {
          change(a[g-1].num,a[g].num);
          change(a[g-1].id,a[g].id);
          c[a[g].id]++;
          c[a[g-1].id]--;
          g--;
        }
      }
    }
    else
    {
      cin>>s;
      cout<<c[s]<<endl;
    }
  }
  return 0;
}

