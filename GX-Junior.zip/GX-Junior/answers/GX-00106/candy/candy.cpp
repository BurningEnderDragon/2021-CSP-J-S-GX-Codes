#include<iostream>
#include<cstdio>
using namespace std;
long long n,k,l;
int main()
{
  freopen("candy.in","r",stdin);
  freopen("candy.out","w",stdout);
  cin>>n>>k>>l;
  long long a=n;
  n*=(k/n);
  for(int i=a-1;i>=0;i--)
  {
    if(n+i<=l)  {cout<<i;return 0;}
  }
  return 0;
}
