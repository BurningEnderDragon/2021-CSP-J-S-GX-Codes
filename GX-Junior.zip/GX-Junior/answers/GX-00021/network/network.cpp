#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    string ad,op,zt[100001];
    int n,jt[100001];
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>op>>ad;
    }
    for(int i=1;i<=n;i++)
    {
        for(int y=1;i<=sizeof(ad);y++)
        {
            for(int k=1;k<=4;k++)
            {
                if(ad[y]=='.')
                {
                    if(ad[y-1]+ad[y-2]*10+ad[y-3]*100>=255)
                    {
                        zt[i]=='ERR';
                        if(op[i]=='Server'&&jt[op[i]]!=1)
                        {
                            jt[i]=="OK";
                        }
                        else jt[i]=='Fail';
                    }
                }
            }
    }
    cout<<zt[1];
}
