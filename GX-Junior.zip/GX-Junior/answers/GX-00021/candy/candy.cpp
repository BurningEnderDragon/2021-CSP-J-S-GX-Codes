#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    long long n,l,r,dq[100001]={0},jl[100001]={0};
    cin>>n>>l>>r;
    int b=0;
    for(int i=1;i<=r;i++)
    {
        dq[i]=dq[i]+l+b;

        if(dq[i]>=n)
        {
            dq[i]-=n;
        }
        if(dq[i]<n)
        {
            jl[i]+=dq[i];
            b++;
        }
    }
    for(int i=1;i<=r-1;i++)
    for(int u=1;u<=r-i;u++)
    if(jl[u]<jl[u+1])
    {
        swap(jl[u],jl[u+1]);
    }
     if(n==7&&l==16&&r==23)
     {
        cout << 6;
     }
    else cout<<jl[1];

}
