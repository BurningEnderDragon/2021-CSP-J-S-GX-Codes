#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","r",stdout);
    int k,n,R,L,s,i,c;
    cin>>n>>L>>R;
    for (int i = 0; i >= 100; i++)
    {
        if(k>=n)
        {
            n-k;
        }
    }
    cout<<R;
    return 0;
}
