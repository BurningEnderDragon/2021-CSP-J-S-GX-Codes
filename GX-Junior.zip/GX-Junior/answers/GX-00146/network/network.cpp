#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
#include<queue>
using namespace std;//if you was the same as me,your mother was died!!!
int n,flag;
struct computer
{
	int niceid;
	string s,where,areyouok;
}a[1001];
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++)
    {
		cin>>a[i].s>>a[i].where;
		a[i].areyouok="";
	}
	for(int i=1;i<=n;i++)
	{
		flag=0;
		for(int j=1;j<=n;j++)
		{
			if(i==j||a[j].areyouok=="FAIL"||a[j].areyouok=="ERR")
			{
				continue;
			}
			if(a[i].areyouok=="FAIL"||a[i].areyouok=="ERR")
			{
				break;
			}
			if(a[i].s=="Server")
			{
				if(a[i].where==a[j].where)
				{
					if(a[j].s=="Server")
					{
						a[j].areyouok="FAIL";
						continue;
					}
					if(a[j].s=="Client")
					{
						a[i].areyouok="OK";
					    a[j].niceid=i;
					    flag=1;
					}
				}
			}
			if(a[i].s=="Client")
			{
				if(a[j].s=="Server"&&a[i].where==a[j].where)
				{
					a[i].niceid=j;
					a[j].areyouok="OK";
					flag=1;
				}
			}
		}
		if(flag!=1&&a[i].areyouok!="ERR"&&a[i].areyouok!="FAIL")
		{
			a[i].areyouok="FAIL";
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(a[i].areyouok!="")
		{
			cout<<a[i].areyouok;
		}
		else
		{
			cout<<a[i].niceid;
		}
		cout<<endl;
	}
    return 0;	
}
