#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
#include<queue>
using namespace std;//if you was the same as me,your mather was died!
int n,l,r,ans=-1;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    cin>>n>>l>>r;
    for(int i=r;i>=l;i--)
    {
		ans=max(ans,i%n);
		if(ans==n-1)
		{
			break;
		}
	}
	cout<<ans;
    return 0;	
}

