#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
#include<queue>
using namespace std;//if you was the same as me,your mather was died!
int n,q,a[8001];
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    cin>>n>>q;
    for(int i=1;i<=n;i++)
    {
		scanf("%d",&a[i]);
	}
    for(int i=1;i<=q;i++)
    {
		int x,y,z;
		scanf("%d %d",&x,&y);
		if(x==1)
		{
			scanf("%d",&z);
			a[y]=z;
		}
		else
		{
			int ans=1;
			for(int i=1;i<=y-1;i++)
			{
				if(a[i]<=a[y])
				{
					ans++;
				}
			}
			for(int i=y+1;i<=n;i++)
			{
				if(a[i]<a[y])
				{
					ans++;
				}
			}
			cout<<ans<<endl;
		}
	}
    return 0;	
}

