#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
#include<queue>
using namespace std;
int n,a[200000];
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
		scanf("%d",&a[i]);
	}
	int m=n;
    while(m>0)
    {
		int flag=2;
		for(int i=1;i<=n;i++)
		{
			if(a[i]!=2&&flag==2)
			{
				flag=a[i];
			}
			if(a[i]!=2&&a[i]==flag)
			{
				flag=1-a[i];
				a[i]=2;
				m--;
				printf("%d ",i);
			}
		}
		cout<<endl;
	}
    return 0;	
}

