#include<iostream>
using namespace std;
int main()
{
    //freopen("candy.in","r",stdin);
    //freopen("candy.out","w",stdout);
    int n;
    char op,ad;
    cin>>n>>op;
    for(int i=1;i<=n;i++)
    {
        cin>>ad;
        if(op==ad)
        {
            if(op==ad&&n==ad)
            {
                cout<<"OK";
            }
            else if(n==op&&op!=ad)
            {
                cout<<"FAIL";
            }
            else if(n!=op&&op!=ad)
            {
                cout<<"ERR";
            }
        }
        else if(ad==op)
        {
             if(ad==op&&n==op)
             {
                cout<<n;
             }
             else if(n==ad&&ad!=op)
             {
                cout<<"FAIL";
             }
             else if(n!=ad&&ad!=op)
             {
                cout<<"ERR";
             }
         }
    }
    return 0;
}
