#include<iostream>
using namespace std;
int main()
{
    //freopen("candy.in","r",stdin);
    //freopen("candy.out","w",stdout);
    int n,a[101];
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
        if(a[i]==6)
        {
            n=a[6]-1;
        }
    }
    cout<<n;
    return 0;
}
