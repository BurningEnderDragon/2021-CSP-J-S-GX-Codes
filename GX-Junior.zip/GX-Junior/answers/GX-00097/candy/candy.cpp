#include<iostream>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,L,R,k;
    cin>>n>>L>>R;
    if(L>=n)
    {
        k=R-n;
        if(k>=n)
        {
            cout<<k-n;
        }
        else
        {
            cout<<k;
        }
    }
    return 0;
}
