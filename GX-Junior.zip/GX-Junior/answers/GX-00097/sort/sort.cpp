#include<iostream>
using namespace std;
int main()
{
    //freopen("sort.in","r",stdin);
    //freopen("sort.out","w",stdout);
    int n,a[5001],t;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
        for(int j=i;j>=2;j--)
        {
            if(a[j]<a[j-1])
            {
                t=a[j-1];
                a[j-1]=a[j];
                a[j]=t;
            }
        }
    }
    cout<<t;
    return 0;
}
