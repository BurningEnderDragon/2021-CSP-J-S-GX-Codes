#include<bits/stdc++.h>
using namespace std;
struct com{
    bool op;
    string ad;
}c[1005];
int n;
string s;
bool f(string str,int num){
    if(num==1)return 0;
    for(int i=1;i<num;i++){
        if(c[i].op&&str==c[i].ad)return 1;
    }
    return 0;
}
int f1(string str,int num){
    if(num==1)return 0;
    for(int i=1;i<num;i++){
        if(c[i].op&&str==c[i].ad)return i;
    }
    return 0;
}
int main(){
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>s;
        if(s=="Server")c[i].op=1;
        else c[i].op=0;
        cin>>c[i].ad;
        if(c[i].op==1){
            if(f(c[i].ad,i)){
                cout<<"FAIL"<<endl;
                continue;
            }
            cout<<"OK"<<endl;
        }
        else{
            if(!f1(c[i].ad,i)){
                cout<<"FAIL"<<endl;
            }
            else{
                cout<<f1(c[i].ad,i)<<endl;
            }
        }
    }

}
