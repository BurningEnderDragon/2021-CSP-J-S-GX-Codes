#include<bits/stdc++.h>
using namespace std;
struct node{
    int n;
    int laxb;
}a[8005],sta[8005];
int n,q,x,y;

void in(int x,int y){
    a[x].n=y;
}
bool cmp(node x,node y){
    return x.n<y.n;

}


int st(int x){
    memcpy(sta,a,sizeof(a));
    sort(sta+1,sta+n+1,cmp);
    for(int i=1;i<=n;i++){
        if(sta[i].laxb==x){
            return i;
        }
    }
}
int main(){
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    cin>>n>>q;
    for(int i=1;i<=n;i++){
        cin>>a[i].n;
        a[i].laxb=i;
    }
    for(int i=1;i<=q;i++){
        cin>>x;
        if(x==1){
            cin>>x>>y;
            in(x,y);
        }
        else{
            cin>>y;
            cout<<st(y)<<endl;
        }
    }

}
