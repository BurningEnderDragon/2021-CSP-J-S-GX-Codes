#include<bits/stdc++.h>
using namespace std;
int n,l,r,f,c;
int main(){
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    cin>>n>>l>>r;
    f=floor(r*1.0/n);
    c=r-l;
    int a=n*f+n;
        if(a-1>=l&&a-1<=r){
            cout<<n-1;
            return 0;
        }
        if(a>l){
            for(int i=1;;i++){
                if(n*(f-i)+n-1<=r){
                    if(n*(f-i)+n-1<=r&&n*(f-i)+n-1>=l){
                        cout<<n-1;return 0;
                    }
                    else{
                        cout<<r-n*(f-i+1);return 0;
                    }
                }
            }
        }

}
