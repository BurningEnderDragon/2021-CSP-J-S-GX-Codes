#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;

long long n,L,R,maxx=0;


int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);	
	cin>>n>>L>>R;
	for(int i=L;i<=R;i++)
	{
		maxx=max(maxx,i%n);
	}
	cout<<maxx;
	return 0;
}
