#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
using namespace std;

string s;
int n;
int a[1000+10],b[1000+10];

int huan(string s)
{
	int nw=0,len=s.size();
	for(int i=0;i<=len-1;i++)
	{
		nw+=(s[i]-'0')
	}
}
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);	
	cin>>n;
	int f=1,k=1;
	for(int i=1;i<=n;i++)
	{
		cin>>s;
		string a,b,c,d,e;
		
		getline(cin,a,'.');
		getline(cin,b,'.');
		getline(cin,c,'.');
		getline(cin,d,':');
		cin>>e;
		if(s=="Server")
		{
			
		}
	}
	return 0;
}
