#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;

struct ma
{
	int id,place,number;
}a[8000+10];
int n,Q;

bool cmp(ma x,ma y)
{
	if(x.number==y.number)return x.place<y.place;
	
	return x.number<y.number;
}
bool cmp1(ma x,ma y)
{
	return x.id<y.id;
}
int  verb2(int x)
{
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
	{
		a[i].place=i;
	}
	int ans=a[x].place;
	sort(a+1,a+n+1,cmp1);
	
	return ans;
}




int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);	
	cin>>n>>Q;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].number;
		a[i].place=a[i].id=i;
	}	
	for(int i=1;i<=Q;i++)
	{
		int q,x,v;
		cin>>q>>x;
		if(q==1)
		{
			cin>>v;
			a[x].number=v;
		}
		if(q==2)
		{
			cout<<verb2(x)<<endl;
		}
	}
	return 0;
}

