#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
int n,l,r;
int main()
{
  freopen("candy.in","r",stdin);
  freopen("candy.out","w",stdout);
  scanf("%d %d %d",&n,&l,&r);
  if(r>=2*n-1) cout<<n-1;
  else cout<<r-n;
  
  return 0;	
}
