#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
int n,q,g,h,r,j;
long a[8001],b[8001];
bool gz(int x,int y)
{
  return x<y;	
}
int main()
{
  freopen("sort.in","r",stdin);
  freopen("sort.out","w",stdout);
  scanf("%d %d",&n,&q);
  for(int i=1;i<=n;i++)
    cin>>a[i];
  for(int i=1;i<=n;i++)
    b[i]=a[i];
  for(int i=1;i<=q;i++)
  {
    cin>>r;
    if(r==1){cin>>g>>h;b[g]=h;a[g]=h;}
    else
    {
	  cin>>j;
	  sort(b+1,b+1+n,gz);
	  for(int v=1;v<=n;v++)
	    if(b[v]==a[j]) {cout<<v<<endl;break;}
	}
  }
   
  
  return 0;	
}
