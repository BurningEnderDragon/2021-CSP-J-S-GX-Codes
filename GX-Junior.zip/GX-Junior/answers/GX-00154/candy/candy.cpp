#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,l,r,s;
    cin>>n>>l>>r;
    if(n<l&&2*n>r)
    {
         cout<<r-n;
         return 0;
    }
    for(int i=1;i<=1000;i++)
    {
        s=n*i;
        if(s<=r)
        {
            if(r-s<n&&s+n-1>l)
                cout<<n-1;
        }
    }
    return 0;
}
