#include<bits/stdc++.h>
int i;
using namespace std;
int main(){
	freopen("network","r",stdin);
	freopen("network","w",stdout);
	char a[1001];
	int n,b;
	string q1,q2;
	cin>>n;
	for(i=1;i<=n;i++){
	cin>>q1>>q2;
	if(q1=="Server")
	cout<<"OK";
	if(q1=="Client")
	cout<<i-1;
	
}
        return 0;
	}
