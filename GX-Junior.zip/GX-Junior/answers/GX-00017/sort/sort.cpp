#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("sort","r",stdin);
    freopen("sort","w",stdout);
    cout<<"zhenshigeiyezhengwuyula";
    return 0;
}

}

