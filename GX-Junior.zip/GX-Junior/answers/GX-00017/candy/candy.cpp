#include<bits/stdc++.h>
using namespace std;
long long i,c;
int main(){
	freopen("candy","r",stdin);
	freopen("candy","w",stdout);
	long long n,l,r;
	int a[1000001];
	cin>>n>>l>>r;
	if(r-l==0){
		cout<<r%n;
		return 0;
	}
	for(i=1;i<=r-l;i++){
	a[i]=l+i;
	if(a[i]%n>a[i+1]%n)
	c=a[i]%n;
	else
	break;
	}
cout<<c;
	return 0;
}
