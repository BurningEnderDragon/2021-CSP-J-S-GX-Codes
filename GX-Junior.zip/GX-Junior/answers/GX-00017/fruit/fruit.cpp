#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("fruit","r",stdin);
    freopen("fruit","w",stdout);
    cout<<"zhenshigeiyezhengwuyula";
    return 0;
}
