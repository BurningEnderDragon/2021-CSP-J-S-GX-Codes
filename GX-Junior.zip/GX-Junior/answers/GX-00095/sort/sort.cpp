#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int a[8010],n,q;
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d %d",&n,&q);
	for(int i=1;i<=n;i++)
	    scanf("%d",&a[i]);
	for(int i=1;i<=q;i++)
	{
	    int l,w,g;
	    scanf("%d %d",&l,&w);
        if(l==1)
        {
		    scanf("%d",&g);
		    a[w]=g;
	    }    
        if(l==2)
        {
			int x=a[w];
	        for(int j=1;j<=n;j++)
                for(int k=j;k>=2;k--)
                    if(a[k]<a[k-1])
                    {
                        int t=a[k-1];
                        a[k-1]=a[k];
                        a[k]=t;
                    }
            for(int j=1;j<=n;j++)
                if(a[j]==x)
                {
					printf("%d\n",j);
					break;
			    }
	    }
	}    
    return 0;	
}
