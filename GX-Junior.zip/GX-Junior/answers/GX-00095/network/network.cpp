#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n;
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	scanf("%d",&n);
    return 0;	
}

