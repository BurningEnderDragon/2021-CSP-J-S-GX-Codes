#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n,L,R,mx=-1;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d %d %d",&n,&L,&R);
	for(int i=L;i<=R;i++)
	{
	    int a=i%n;
	    mx=max(mx,a);	
	}
	printf("%d",mx);
    return 0;	
}
