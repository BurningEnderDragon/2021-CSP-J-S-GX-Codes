#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n;
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	scanf("%d",&n);
    return 0;	
}

