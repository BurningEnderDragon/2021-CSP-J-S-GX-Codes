#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
int n;
struct net
{
  string x1;
  int y1,y2,y3,y4,y5;	
  char z1,z2,z3,z4;
}a[1001];
int main()
{
  freopen("network.in","r",stdin);
  freopen("network.out","w",stdout);
  scanf("%d",&n);
  for(int i=1; i<=n; i++)
  {
	getline(cin,a[i].x1);
	scanf("%d %c %d %c %d %c %d %c %d",&a[i].y1,&a[i].z1,&a[i].y2,&a[i].z2,&a[i].y3,&a[i].z3,&a[i].y4,&a[i].z4,&a[i].y5);  
	if(a[i].y1>255||a[i].y1<0||a[i].y2>255||a[i].y2<0||a[i].y3>255||a[i].y3<0||a[i].y4>255||a[i].y4<0||a[i].y5>255||a[i].y5<0||a[i].z1!='.'||a[i].z2!='.'||a[i].z3!='.'||a[i].z4!=':')
	  {printf("ERR\n");continue;}
	 
  }
  return 0;
}

