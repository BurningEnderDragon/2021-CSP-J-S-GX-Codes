#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
int n,l,r;
int k;
int ans;
int w;
int main()
{
  freopen("candy.in","r",stdin);
  freopen("candy.out","w",stdout);
  scanf("%d %d %d",&n,&l,&r);
  for(k=l; k<=r; k++)
  {
    w=n;
    ans=max(ans,k%n);
  }
  printf("%d",ans);
  return 0;
}
