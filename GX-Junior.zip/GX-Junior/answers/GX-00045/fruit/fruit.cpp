#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
int n;
int a[200001];
int t;
int ans=0;
int main()
{
  freopen("fruit.in","r",stdin);
  freopen("fruit.out","w",stdout);
  scanf("%d",&n);
  for(int i=1; i<=n; i++)
  {
	 scanf("%d",&t);
	 a[i]=t+1;  
  }
  while(1)
  {
	t=0;
    for(int i=1; i<=n; i++)
    {
	    if(t!=a[i]&&a[i]!=0) 
	    {
			printf("%d %s",i,"");
			t=a[i];
			a[i]=0;
	    }
	    if(a[i]==0) ans++;
	    
	}

    if(ans==n) return 0;
	    else ans=0;
    printf("\n");
  }
  return 0;
}
