#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int n,q;
int a[8010];
struct sor
{
  int shu;
  int xvhao;	
}b[8010];
bool cmp(sor a,sor b)
{
  return a.shu<b.shu;	
}
int c,x,v;
int main()
{
  freopen("sort.in","r",stdin);
  freopen("sort.out","w",stdout);
  cin>>n>>q;
  for(int i=1; i<=n; i++)
    cin>>a[i];
  for(int ii=1; ii<=q; ii++)
  {
	 if(ii==q)
    {
	   cin>>c;
	   if(c==1)
	   {
		   cin>>x>>v;
		   a[x]=v;
	   }
	   if(c==2)
	   {
		   cin>>x;
		   for(int i=1; i<=n; i++)
		   {
		     b[i].xvhao=i;
		     b[i].shu=a[i];	 
	       }
	     
		   sort(b+1,b+n+1,cmp);
            for(int i=1; i<=n; i++)
			   if(b[i].xvhao==x) printf("%d",i); 
	   }
     }
     else
     {
		 
	   cin>>c;
	   if(c==1)
	   {
		   cin>>x>>v;
		   a[x]=v;
	   }
	   if(c==2)
	   {
		   cin>>x;
		   for(int i=1; i<=n; i++)
		   {
		     b[i].xvhao=i;
		     b[i].shu=a[i];	 
	       }
	     
		   sort(b+1,b+n+1,cmp);
            for(int i=1; i<=n; i++)
			   if(b[i].xvhao==x) printf("%d\n",i); 
	   }  
     }
  }
  return 0;
}

