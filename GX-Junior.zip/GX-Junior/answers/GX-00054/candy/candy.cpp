#include<iostream>
using namespace std;
int main()
{
   int n=0,k=0,r=0 l=0;
   cin>>n>>l>>r;
   l=n+r;
   while(k<l)
   {
     cout<<l<<endl;
   }
}
