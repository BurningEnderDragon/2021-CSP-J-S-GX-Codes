#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    int n,fruit[200000+10],m=1;
    bool f[200000+10];
    cin>>n;
    for(int i=1;i<=n;++i)
        cin>>fruit[i];
    for(int i=1;i<=n;++i)
        f[i]=true;
    cout<<m;
        f[m]=false;
    for(int i=1;i<=n+1;++i)
        if(fruit[i]!=fruit[i-1] and f[i]==true)
        {
            cout<<" "<<i;
            f[i]=false;
        }
    cout<<endl;
    for(int i=1;i<=n;++i)
        if(f[i]==true)
        {
            m=i;
            break;
        }
    while(m<n)
    {
        for(int i=1;i<=n;++i)
            for(int j=1;j<=n;++j)
                if(fruit[i]!=fruit[j] and i<j and f[i]==true and f[j]==true)
                {
                    cout<<j;
                    f[j]=false;
                    break;
                }
        for(int i=1;i<=n;++i)
        if(f[i]==true)
        {
            m=i;
            break;
        }
    }
    return 0;
}
