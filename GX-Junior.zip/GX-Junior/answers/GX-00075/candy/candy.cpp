#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,L,R,m;
    cin>>n>>L>>R;
    int ans=INT_MIN;
    for(int i=L;i<=R;++i)
    {
        m=i%n;
        if(m>ans)
            ans=m;
    }
    cout<<ans;
    return 0;
}
