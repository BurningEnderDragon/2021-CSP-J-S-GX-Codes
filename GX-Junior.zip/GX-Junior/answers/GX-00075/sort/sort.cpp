#include<bits/stdc++.h>
using namespace std;
int n,Q,a[8000+10],num[200000+10],x[200000+10],v[200000+10];
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    cin>>n>>Q;
    for(int i=1;i<=n;++i)
        cin>>a[i];
    for(int i=1;i<=Q;++i)
    {
        cin>>num[i];
        if(num[i]==1)
            cin>>x[i]>>v[i];
        else if(num[i]==2)
            cin>>x[i];
    }
    for(int i=1;i<=Q;++i)
    {
        if(num[i]==1)
            a[x[i]]=v[i];
        else if(num[i]==2)
        {
            for (int k = 1; k <= n; k++)
                for (int j = k; j>=2; j--)
                    if ( a[j] < a[j-1] )
                    {
                        int t = a[j-1];
                        a[j-1] = a[j];
                        a[j] = t;
                    }
            for(int j=1;j<=n;++j)
                if(j==x[i])
                    cout<<j<<endl;
        }
    }
    return 0;
}
