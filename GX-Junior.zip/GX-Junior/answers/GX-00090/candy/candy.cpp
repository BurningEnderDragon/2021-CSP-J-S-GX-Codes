#include<iostream>
#include<cstring>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    long long i,k,n,m,ans=0;
    cin>>k>>n>>m;
    for(i=n;i<=m;i++)
    {
        if(i%k>=ans)
        {
            ans=i%k;
        }
    }
    cout<<ans;
    return 0;
}
