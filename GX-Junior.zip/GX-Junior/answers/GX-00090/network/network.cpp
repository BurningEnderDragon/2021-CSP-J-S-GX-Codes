#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    char a[1001][26],b[1001][7],c[1001][7],q,w,e=0,r,t;
    int i,j,n,m,k;
    cin>>n;
    for(i=0;i<n;i++)
    {
		e=0;
		cin>>b[i]>>a[i];
		while()
		{
			e++;
			if(
			)
		}
		if(b[i]=='Server')
	}
    return 0;
}
