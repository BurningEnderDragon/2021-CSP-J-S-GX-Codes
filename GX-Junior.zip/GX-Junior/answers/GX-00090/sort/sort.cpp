#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int i,j,k,c,v,n,w,m,h,b[100002]={0},a[100002]={0};
    cin>>h>>k;
    for(i=0;i<l;i++)
    {
		cin>>b[i];
	}
    for(int l=0;l<k;l++)
    {
		cin>>c;
		if(c==1)
		{
			cin>>i>>v
			b[i]=v;
		}
		else
		{
			cin>>v;
			for(i=0,i<l;i++)
			{
				a[i]=b[i];
				if(i+1=v)
				{
					w=b[i];
					a[i]=-10000;b[i]=-10000;
				}
			}
			for (i = 1; i <= n; i++)
			{
				for (j = i; j>=2; j‐‐)
				{
					if ( a[j] < a[j‐1] )
					{
						t = a[j‐1];
						a[j‐1] = a[j];
						a[j] = t;
					}
				}
			}
			for(i=0;i<l;i++)
			{
				if(a[i]==-10000)
				{
					cout<<i+1<<endl;
					b[i]=w;
				}
			}
		}
	}
    return 0;
}
