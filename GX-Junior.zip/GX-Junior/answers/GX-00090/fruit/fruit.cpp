#include<iostream>
#include<cstring>
int a[3][100005];
using namespace std;
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    int i,j,n,m,u=0;
    cin>>n;
    for(i=0;i<n;i++)
    {
		cin>>a[0][i];
		a[1][i]=i+1;
		a[2][i]=a[0][i];
	}
	m=n;
	for(i=0;i<=1;i++)
	{
		u=0;
		a[0][0]=2;
		for(j=1;j<m;j++)
		{
			if(a[2][j]!=a[2][j-1])
			{
				a[0][j]=2;
			}
		}
		for(j=0;j<m;j++)
		{
			if(a[0][j]!=2)
			{
				cout<<a[1][j]<<" ";
			}
		}
		cout<<endl;
		for(j=0;j<m;j++)
		{
			if(a[0][j]!=2)
			{
				a[0][u]=a[0][j];
				a[1][u]=a[1][j];
				a[2][u]=a[2][j];
				u++;
			}
		}
		m=u+1;
		if(m<=1)
		{
			i=23;
		}
		else
		{
			i--;
		}
	}
    return 0;
}
