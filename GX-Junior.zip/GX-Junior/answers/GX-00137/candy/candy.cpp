#include<iostream>
#include<cstdio>
using namespace std;
int n, l, r, ans;
int main()
{
   freopen("candy.in","r",stdin);
   freopen("candy.out","w",stdout);
   cin >> n >> l >> r;
   ans = l/n*n;
   if(ans+n-1 <= r)
      cout << n-1;
   else
      cout << r - ans;
   return 0;
}
