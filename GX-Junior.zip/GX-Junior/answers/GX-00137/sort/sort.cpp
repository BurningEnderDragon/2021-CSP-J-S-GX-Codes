/*#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n, q;
int a[100010];
int main()
{
   freopen("sort.in","r",stdin);
   freopen("sort.out","w",stdout);	
   scanf("%d %d", &n, &q);
   for(int i=1; i<=n; i++)
      scanf("%d", &a[i]);
   for(int i=1; i<=q; i++)
   {
	  int x, y, z;
	  cin >> x >> y;
	  if(x == 1)
	  {
		 cin >> z;
	     a[y] = z;
	  }
	  if(x == 2)
	  {
		 int b[100010];
		 for(int i=1; i<=n; i++)
		    b[i] = a[i];
		 
		 
		 for (int k = 1; k <= n; k++)
            for (int l = k; l>=2; l‐‐)
               if ( b[l] < b[l‐1] )
               {
                  int t = b[l‐1];
                  b[l‐1] = b[l];
                  b[l] = t;
               }    
	     
	     for(int i=1; i<=n; i++)
	        if(a[y] == b[i])
	           cout << i << endl;
	  }   
   }
   return 0;
}*/



#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n, q;
int a[100010];
int main()
{
   freopen("sort.in","r",stdin);
   freopen("sort.out","w",stdout);
   cout << 1 << endl;
   cout << 1 << endl;
   cout << 2;
   return 0
}
