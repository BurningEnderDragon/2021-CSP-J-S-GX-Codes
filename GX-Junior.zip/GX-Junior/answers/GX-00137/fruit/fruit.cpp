#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;

struct dd
{
   int fru, id;
}a[500010];

int b[3];
int n, sum = 100001;

int main()
{
   freopen("fruit.in","r",stdin);
   freopen("fruit.out","w",stdout);	
   scanf("%d", &n);
   for(int i=1; i<=n; i++)
   {
      scanf("%d", &a[i].fru);
      a[i].id = i;
   }

   for(int i=1; i<=n; i++)
   {
	  
	  for(int j=1; j<=n; j++)
      {
	     if(a[j].fru != a[j-1].fru)
	        b[a[j-1].fru] = 0;
	     
	     if(b[a[j].fru] == 0)
	     {
		    cout << a[j].id << " ";	 
		    n--;  
		    b[a[j].fru]++;
		    a[j].id = sum;
		    sum++;
		    if(a[j].fru != a[j+1].fru)
		       b[a[j].fru] = 0;
		    for(int k=j; k<=100010; k++)
		       if(a[k].id > a[k+1].id)
		       {
				  int t = a[k].id, t1 = a[k].fru;
				  a[k].fru = a[k+1].fru;
				  a[k].id = a[k+1].id;
				  a[k+1].fru = t1;
				  a[k+1].id = t;
			   }
		    j--;
		 }
	  }
	
      cout << endl;  
	  b[1] = 0;
	  b[0] = 0;
   }
   return 0;
}
