#include <stdio.h>
using namespace std
int maim()

{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
}
	return o


