#include<iostream>
#include<cstdio>
#include<string>
#include<queue>
#include<cmath>
#include<algorithm>
using namespace std;
int n, l, r, maxx;
int main ()
{
	freopen ("candy.in", "r", stdin);
	freopen ("candy.out", "w", stdout);
	cin >> n >> l >> r;
	for (int i = l; i <= r; i++)
	{
		maxx = max (maxx, i % n);
	}
	cout << maxx;
	
	return 0;
}
