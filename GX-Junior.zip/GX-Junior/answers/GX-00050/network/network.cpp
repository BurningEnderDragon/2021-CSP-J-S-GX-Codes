#include<iostream>
#include<cstdio>
#include<string>
#include<queue>
#include<cmath>
#include<algorithm>
using namespace std;
string a, s[1001], c[1001];
int n, j;
bool kkkkk(string qq)
{
	for (int i = 1; i <= n; i++)
	{
		if (s[i] == qq)
		{
			return false;
		}
	}
	return true;
}
bool kkkk(string qq)
{
	for (int i = 1; i <= n; i++)
	{
		if (c[i] == qq)
		{
			return true;
		}
	}
	return false;
}
bool kkk(string qq)
{
	int i, len = qq.size(), ll = 0;
	string p = "";
	for (i = 0; i <= len; i++)
	{
		p += qq[i];
		if (qq[i] == '.')
		{
			break;
			ll = 1;
		}
	}
	if (i > 3 || p > "255" || ll == 0)
	{
		return false;
	}
	i++;
	ll = 0;
	
	
	for (; i <= len; i++)
	{
		p += qq[i];
		if (qq[i] == '.')
		{
			break;
			ll = 1;
		}
	}
	if (i > 3 || p > "255" || ll == 0)
	{
		return false;
	}
	ll = 0;
	i++;
	
	
	for (; i <= len; i++)
	{
		p += qq[i];
		if (qq[i] == '.')
		{
			break;
			ll = 1;
		}
	}
	if (i > 3 || p > "255" || ll == 0)
	{
		return false;
	}
	ll = 0;
	i++;
	
	
	for (; i <= len; i++)
	{
		p += qq[i];
		if (qq[i] == ':')
		{
			break;
			ll = 1;
		}
	}
	if (i > 3 || p > "255" || ll == 0)
	{
		return false;
	}
	ll = 0;
	i++;
	return true;
}
int main ()
{
	freopen ("network.in", "r", stdin);
	freopen ("neteork.out", "w", stdout);
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cin >> a;
		if (a == "Server")
		{
			if (!kkk(a))
			{
				cout << "ERR" << endl;
				continue;
			}
			if (kkkkk (a))
			{
				cout << "OK" << endl;
			}
			else
			{
				cout << "FAIL" << endl;
			}
			s[i] = a;
		}
		
		if (a == "Client")
		{
			if (!kkk(a))
			{
				cout << "ERR" << endl;
				continue;
			}
			if (kkkkk (a))
			{
				cout << j << endl;
			}
			else
			{
				cout << "FAIL" << endl;
			}
			c[i] = a;
			j++;
		}
	}
	
	return 0;
}
