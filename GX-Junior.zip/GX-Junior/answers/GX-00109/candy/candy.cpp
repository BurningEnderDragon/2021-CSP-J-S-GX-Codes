#include<iostream>
#include<cstdlib>
using namespace std;
int main(){
    int n,l,r,max=0,q;
    cin>>n>>l>>r;
    for(int k=l;k<=r;k++){
        q=k;
        while(1){
			if(q<n){
				break;
			}
            q=q-n;
        }
          if(q>max){
            max=q;
        }
    }
    cout<<max;
    return 0;
}
