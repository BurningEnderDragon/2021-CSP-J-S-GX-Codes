#include<iostream>
#include<cstdlib>
using namespace std;
int main(){
    int n;
    cin>>n;
    int a[50000],b[50000];
    for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	while(){
		int c=0;
		for(int i=1;i<=n;i++){
			if(a[i]!=2)
		}
	}
    return 0;
}
