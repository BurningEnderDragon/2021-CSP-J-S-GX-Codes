#include<iostream>
#include<cstring>
using namespace std;
int main(){
	int n,q;
	int a[5000];
	cin>>n>>q;
	
}
