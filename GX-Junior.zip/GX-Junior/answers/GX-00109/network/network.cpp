#include<iostream>
using namespace std;
int main(){
	int n;
	cin>>n;
	char op[100];
	char ad[25],ad2[25];
	for(int i=1;i<=n;i++){
		cin>>op[i];
		for(int k=1;k<=n;k++){
			cin>>ad[k]
		}
		
	}
}
