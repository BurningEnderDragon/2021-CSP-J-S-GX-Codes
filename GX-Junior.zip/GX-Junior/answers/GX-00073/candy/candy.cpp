#include <iostream>
#include <cmath>
using namespace std;
int main()
{
    //freopen("candy.in","r",stdin);
    //freopen("candy.out","w",stdout);
    int  n, l ,r, s[1000],k,maxx=-1;
    cin >> n >> l >> r;
    for(int i=l;i<=r;i++)
    {
        k=i;
         for(int j=1; j<=n;j++)
         {

             k-=n;
             if(k<n)
             {
                 s[i]=k;
                 break;
             }
         }
    }
    for(int i=l;i<=r;i++)
    {
       maxx=max(maxx,s[i]);
    }
    cout << maxx;
    return 0;
}
