#include <iostream>
using namespace std;
int main()
{
    //freopen("sort.in","r",stdin);
    //freopen("sort.out","w",stdout);
    int n, q,a[10000],b[1000],x ,v;
    cin >> n >> q;

    for(int i=1;i<=n;i++)
    {
        cin >> a[i];
    }

    for(int k=1;k<=q;k++)
       {

           cin>> x;
            cin >> v;
            a[x]=v;
            cout << a[x] << endl;
       }
       return 0;
}
