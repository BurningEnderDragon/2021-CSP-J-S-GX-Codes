#include <bits/stdtr1c++.h>
using namespace std;
struct s
{
 int sb[898];
};
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    int n;
    int a[1000000];
    cin >> n;
    for(int i=1;i<=n;i++)
        cin >> a[i];
    for(int i=1;i<=n;i++)
    {
        if(a[i]==a[i+1])
        {

        }
    }
    return 0;
}
