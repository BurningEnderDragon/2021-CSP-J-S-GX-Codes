#include <iostream>

using namespace std;
char a[50];
char b[50][1000]={' '};
char c[50][1000]={' '};
int cp=0;
int v[1000]={0};
void bp(int i){
    int num=0;
    for (int j = 1 ; j<=16 ; j++){
        if (c[j-1][i]='.'&&c[j][i]>='0'&&c[j][i]<='9'&&c[j+1][i]=='.'){
            num=c[j][i]-48;
            if (num>255){
                v[i]=2;
            }
        }
        if (c[j-1][i]='.'&&c[j][i]>='0'&&c[j][i]<='9'&&c[j+1][i]>='0'&&c[j+1][i]<='9'&&c[j+2][i]=='.'){
            num=(c[j][i]-48)*10;
            num=num+c[j+1][i]-48;
            if (num>255){
                v[i]=2;
            }

        }
        if (c[j-1][i]='.'&&c[j][i]>='0'&&c[j][i]<='9'&&c[j+1][i]>='0'&&c[j+1][i]<='9'&&c[j+2][i]>='0'&&c[j+2][i]<='9'&&c[j+3][i]=='.'){
            num=(c[j][i]-48)*100;
            num=num+(c[j+1][i]-48)*10;
            num=num+c[j+2][i]-48;
            if (num>255){
                v[i]=2;
            }
        }
    }
}
bool dp(int p){
    int num=0;
    for (int i = 0 ; i < cp; i ++){
        if (b[p][i]==c[p][i]){
            num++;
        }
    }
    if (num==0){
        return 1;
    }
    else {
        return 0;
    }
}
int main()
{
    int n;
    cin >> n;
    for ( int i = 0 ; i < n ; i++ ){
        cin >> a;
        if (a[1]=='S'){
            b[0][i]='.';
            for (int j = 6 ; j<40; j++){
                b[j-5][i]=a[j];
            }
            cp++;
        }
        if (a[1]=='C'){
            c[0][i]='.';
            for (int j = 6 ; j<40; j++){
                c[j-5][i]=a[j];
                if(dp(j)){
                    v[i]=1;
                }

            }

        }

    }
    for (int w=0 ; w<n ; w++){
        if (v[w]==0){
            cout <<'OK'<<endl;
        }
        if (v[w]==1){
            cout <<'FAIL'<<endl;
        }
        if (v[w]==2){
            cout <<'ERR'<<endl;
        }
    }
    return 0;
}
//Server 192.168.1.1:80
