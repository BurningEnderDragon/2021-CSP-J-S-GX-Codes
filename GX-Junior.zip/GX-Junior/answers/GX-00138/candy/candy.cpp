#include <iostream>

using namespace std;

int main()
{
    int n,l,r;
    int a=0;
    int num=-1;
    cin>>n>>l>> r;
    for (int i = l ; i <= r ; i++){
        if (i%n>num)
            num=i%n;
    }
    cout<< num;
    return 0;
}
