#include<bits/stdc++.h>
using namespace std;
int s[6],n[6];
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{cin>>s[i];s[i]=n[i];}
	for(int i=1;i<=n;i++)
	{
		if(s[i]==s[i+1]&&s[i]!=-1)
		{
			cout<<i<<' ';s[i]=-1;
			while(s[i]==(s[i+1]||-1))
			i++;
			if(i==5)i=1;cout<<endl;
		}
		else if(s[i]!=s[i-1]&&s[i]!=s[i+1])
		{
			cout<<i<<' ';s[i]=-1;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
