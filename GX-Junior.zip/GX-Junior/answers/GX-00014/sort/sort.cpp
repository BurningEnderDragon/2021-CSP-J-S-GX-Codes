#include<bits/stdc++.h>
using namespace std;
int main()
{
  freopen("sort.in","r",stdin);
  freopen("sort.out","w",stdout);
  int n,q,a,b,qu;
  cin>>n>>q;
  int s[n+1]={0},s2[n+1]={0};
  for(int i=1;i<=n;i++)
  {cin>>s[i];s2[i]=s[i];}
  for(int i=1;i<=q;i++)
  {
	  cin>>qu;
	  if(qu==1)
	  {
		  cin>>a>>b;
		  s[a]=b;
	  }
	  else if(qu==2)
	  {
		  cin>>a;
	      sort(s2,s2+n);
	      for(int j=1;j<=n;j++)
	      {
           if(s[a]==s2[j])
           {
			  cout<<j<<endl;
		   }
	      }
      }
   }
   fclose(stdin);
  fclose(stdout);
  return 0;
}
	 

