#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a,b,c;
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>a>>b>>c;
	int max=0;
	for(int i=b;i<=c;i++)
	{
		if(max<i%a)
		{max=i%a;}
		if(max==a-1)break;
	}
	cout<<max;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
