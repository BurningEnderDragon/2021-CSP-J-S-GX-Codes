include <iostream>
using namespace std;
int main()
{
    freopen("candy.in"."r"stdin);
    freopen("candy.out"."w"stdout);
    int n,L,R,sum=0;
    cin>>n>>L>>R;
    if(L>n)
    {
        sum=L-n;
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            L+=1;

        }
        sum=L-n;
    }
    cout<<sum;
    return 0;
}
