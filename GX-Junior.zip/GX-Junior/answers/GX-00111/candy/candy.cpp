#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<algorithm>
#include<queue>
#include<stack>
using namespace std;
long long n,l,r,t;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    cin>>n>>l>>r;
    t=l%n;
    if(r-l+t<n)
        cout<<r-l+t;
    else
        cout<<n-1;
    return 0;
}
