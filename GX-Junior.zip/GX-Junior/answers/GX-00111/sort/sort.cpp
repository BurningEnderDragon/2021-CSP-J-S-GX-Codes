#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<algorithm>
#include<queue>
#include<stack>
using namespace std;
int n,q,a[8010],b[8010];
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    cin>>n>>q;
    for(int i=1;i<=n;i++)
        cin>>b[i];
    for(int i=1;i<=q;i++)
    {
		int x=0,y=0,z=0;
		cin>>x;
		if(x==1)
		{
			cin>>y>>z;
			b[y]=z;
		}
		else
		{
			cin>>y;
			for (int j=1;j<=n;j++)
			    a[j]=b[j];
			for (int j=1;j<=n;j++)
			    for(int k=j;k>=2;k--)
                    if (a[k]<a[k-1])
                    {
                         int t=a[k-1];
                         a[k-1]=a[j];
                         a[j]=t;
                    }
			cout<<a[y]<<endl;
		}
	}
    return 0;
}

