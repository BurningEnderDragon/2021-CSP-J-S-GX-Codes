#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<algorithm>
#include<queue>
#include<stack>
using namespace std;
int n;
struct fruit
{
	int id,k;
}a[200010];
bool cmp(fruit a,fruit b)
{
	return a.id<b.id;
}
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++)
    {
		scanf("%d",&a[i].k);
		a[i].id=i;
	}
	a[0].k=2;
	int m=n;
	while(n>0)
	{
	    sort(a+1,a+m+1,cmp);
	    int t=0;
	    for(int i=1;i<=n;i++)
	    {
	    	if(a[i-1].k==a[i].k)
	    	    continue;
	    	else
	    	{
	    		cout<<a[i].id<<" ";
	    		a[i].id=0x7fffffff;
	    		t++;
	    	}
	    }
	    n-=t;
	    cout<<endl;
	}
    return 0;
}

