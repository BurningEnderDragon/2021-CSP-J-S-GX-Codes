#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<algorithm>
#include<queue>
#include<stack>
using namespace std;
int n,len;
int t[6],b;
char d='.',y=':';
string f[1010],p="Server",q="Client";
struct work
{
	string c,s;
}a[1010];
void df(string b)
{
	int l=b.size();
	len=l;
}
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++)
    {
		cin>>a[i].c>>a[i].s;
		df(a[i].s);
		if(a[i].c==p)
		{
		     int flag=1;
		     for(int j=1;j<=n;j++)
		     {
				 if(a[i].s==a[j].s)
				 {
				     cout<<"FAIL";
				     flag=0;
				 }
			 }
			 if(flag==1)
		         cout<<"OK";
		}
		if(a[i].c==q)
		{
		     cout<<"FAIL";
		}
	}
    return 0;
}
