#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int n;
int a[10];
int ans;
int b[10];
int main()
{
   freopen("fruit.in","r",stdin);	
   freopen("fruit.out","w",stdout);	
   cin>>n;
   for (int i=1;i<=n;i++)
     cin>>a[i];
   if (n==1)
   cout<<1;
   if (n==2)
   {
     if (a[1]==a[2])
     {
	    cout<<1<<endl;
	    cout<<2;	 
     }
     else
       cout<<1<<" "<<2; 
   }
   if (n==3)
   {
	      cout<<1<<" ";
	      if (a[2]!=a[1])
	      {
	        cout<<2<<" ";
	        if (a[3]!=a[2])
	        {
	          cout<<3<<" ";
	          return 0;
	         }
	         cout<<endl<<3;
	         return 0;
	      }
	      else
	      {
			if (a[3]!=a[2])
			{
			     cout<<3<<endl<<2;	
			}  
			else
			 cout<<endl<<2<<endl<<3;
		  } 
   }
   if (n==4)
   {
	  cout<<1<<" ";
	  if (a[2]==a[1])
	  {
		 if (a[3]==a[2])  
		 {
		    if (a[4]!=a[3])
		    {
		       cout<<4<<endl;
		       cout<<2<<endl<<3;
		     }
		     else
		     cout<<endl<<2<<endl<<3<<endl<<4<<endl;
		 } 
		 else
		 {
			 if (a[4]==a[3])
			 {
		       cout<<3<<" "<<4<<endl;
		       cout<<2;
		      }
		    else
		    {
		     cout<<3<<endl;
		     cout<<2<<" "<<4;
	        }
	      }
	  } 
	  else
	  {
		  if (a[3]!=a[2])
		  {
		     if (a[4]!=a[3])
		     {
			    cout<<2<<" "<<3<<" "<<4;
			    return 0;	 
			 }	  
			 else
			 {
			   cout<<2<<" "<<3<<endl;
			   cout<<4;
			  }
		 }  
		 else
		 {
		    if (a[4]!=a[3])
		    {
			   cout<<2<<" "<<4<<endl;	
			   cout<<3;
			}	 
			else
			{
			   cout<<2<<endl<<3<<endl<<4;	
			}    	
		  }
	    }
   }
   return 0;
}

