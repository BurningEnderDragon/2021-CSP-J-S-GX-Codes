#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
using namespace std;
int n;
int a[10000];
int main()
{
   freopen("network.in","r",stdin);
   freopen("network.out","w",stdout);	
   cin>>n;
   for (int i=1;i<=n;i++)
   {
	  string ch1; 
	   cin>>ch1;   
	   if (ch1=="Server")
	   {
		      int b,c,d,e,f;
		      cin>>b>>c>>d>>e>>f;
		      if (a[b]==1 && a[c]==1 && a[d]==1 && a[e]==1 && a[f]==1)
		      {
				  cout<<"FAIL"<<endl;
			  }
		      else
		      { 
				   a[b]=1;
				   a[c]=1;
				   a[d]=1;
				   a[e]=1;
				    a[f]=1;
				   cout<<"OK"<<endl;
			  } 
	   }
   }
   return 0;
}
