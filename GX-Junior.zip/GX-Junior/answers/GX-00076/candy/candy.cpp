#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
long long n,m,l;
long long ans;
int main()
{
   freopen("candy.in","r",stdin);	
   freopen("candy.out","w",stdout);	
   scanf("%lld%lld%lld",&l,&n,&m);
   for (int i=n;i<=m;i++)
   {
	      ans=max(ans,i%l);
   }
   cout<<ans;
   return 0;
}
