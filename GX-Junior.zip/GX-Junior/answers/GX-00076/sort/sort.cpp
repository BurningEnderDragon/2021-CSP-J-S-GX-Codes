#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;

int n,m;
struct nx
{
   int id;
   int num;	
}a[9000];
struct nx1
{
   int id1;
   int num1;	
}b[9000];
bool gz(nx1 x1,nx1 x2)
{
  if (x1.num1!=x2.num1)
   return x1.num1<x2.num1;
  return x1.id1<x2.id1;	
}
int main()
{
   freopen("sort.in","r",stdin);	
   freopen("sort.out","w",stdout);	
   cin>>n>>m;
   for (int i=1;i<=n;i++)
   {
     scanf("%d",&a[i].num);
     a[i].id=i;
   }
   for (int i=1;i<=m;i++)
   {
	   int c; 
	   scanf("%d",&c);
	   if (c==1)
	   {
		   int  k,l;
		   scanf("%d%d",&k,&l);
		   a[k].num=l;  
	   }   
	   if (c==2)
	   {
		  int p,x,y;
		  scanf("%d",&p);
		  y=a[p].num;
		  x=a[p].id;
          for (int j=1;j<=n;j++)
          {
            b[j].num1=a[j].num;
            b[j].id1=a[j].id; 
	      }
          sort(b+1,b+n+1,gz);
          for (int j=1;j<=n;j++)
           if (y==b[j].num1 && x==b[j].id1)
           {
            cout<<j<<endl;
            break;
           }
	   }
   }
   return 0;
}

