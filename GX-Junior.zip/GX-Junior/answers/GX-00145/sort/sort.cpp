#include<bits/stdc++.h>
using namespace std;
int a[]={6,10,2,10,3,6};
int main(){
	freopen("sort.in","r",stdin);
	freopen("sort.ans","w",stdout);
	for(int i=0;i<7;i++) cout<<a[i]<<endl;
	return 0;
}
