#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("candy.in","r",stdin);
	freopen("candy.ans","w",stdout);
	long long n,k=0,l,r,i;
	cin>>n>>l>>r;
	if(r-n<n){
		cout<<r-n;
		return 0;
		}
	for(i=n-1;i>0;i--){
		k+=n;
		if(k+i<=r && k+i>=l){
			cout<<i;
			return 0;
			}
		}
}
