#include<bits/stdc++.h>
using namespace std;
struct tcp{
	string name;
	string dz;
	};
tcp net[1010];
char sz(string n){
	int len=strlen(n);
	int ans=1;
	for(int i=len;i>=0;i--){
		int k=1;
		if(n[i]=='.' || n[i]==':') ans++;
		if(ans==1){
			if(n[i]>='0' && n[i]<='9'){
				return ans;
				}
			}
		
		}
	}
int main(){
	freopen("network.in","r",stdin);
	freopen("network.ans","w",stdout);
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>net[i].name>>net[i].dz;
		if(net[i].name=='Server'){
			int len=strlen(net.dz);
			bool jl;
			for(int j=i-1;j>=0;j--) if(net[i].dz==net[j].dz) cout<<"FAIL",jl=true;
			if(!jl) for(int j=0;j<len-2;j++){
						if(net[i].dz[j]==0 && j==0){cout<<"ERR";break;}
						if((net[i].dz[j]=='.' || net[i].dz[j]==':') && net[i].dz[j+1]=='0' && (net[i].dz[j+2]=='.' || net[i].dz[j+2]==':')){cout<<"ERR";break;}
						}
			}
	}
	return 0;
}
