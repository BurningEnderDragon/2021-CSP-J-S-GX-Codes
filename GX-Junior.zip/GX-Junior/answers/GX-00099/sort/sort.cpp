#include<iostream>

using namespace std;


int main()
{
	int
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
}
