#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("netwoke.in","r",stdin);
	freopen("netwoke.out","w",stdout);
	int n,a,b,c,d,e;
	char f,h,i,j,k;
	for(int t=n;n>0;n--;);
	{
	cin>>n;
	cin>>f>>a>>h>>b>>i>>c>>j>>d>>k>>e;
	if(a+b+c+d<1200);
		cout<<"ERR"<<endl;
	else
	{
		if(0>=e);
		cout<<"ERR"<<endl;
		else
		{
			if(e>=655355);
			cout<<"ERR"<<endl;
			else
			{
				if(h==i==j==k);
				{
					cout<<"OK"<<endl;
					}
					else
					cout<<"ERR"
				}
				
			}
		
}
}
	fclose(stdin)
	fclose(stdout)
	return 0;
	}
