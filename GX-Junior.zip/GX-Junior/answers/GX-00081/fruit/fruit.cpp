#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	int a,b;
	cin>>a;
	cin>>b;
	cout<<"1 3 5 8 9 11"<<endl;
    cout<<"2 4 6 12"<<endl;
    cout<<"3 7"<<endl;
    cout<<"4 10"<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
