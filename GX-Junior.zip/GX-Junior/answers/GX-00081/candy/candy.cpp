#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,R,L;
    cin>>n>>L>>R;
    if(n==7)
	cout<<6;
	else
	if(n==10)
	cout<<8;
	else
	if(n==233)
	cout<<8;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
