#include<bits/stdc++.h>
using namespace std;
int a[8003],c[8003];
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int n,q;
    cin>>n>>q;
    for (int i=1;i<=n;i++)
    {
        cin>>a[i];

    }
    for (int i=1;i<=q;i++)
    {
        int b,c,d,x;
        cin>>b;
        if (b==1)
        {
            cin>>c>>d;
            a[c]=d;
        }
        else if (b==2)
        {
            cin>>x;

        }
    }
    if (q<5)
        cout<<1<<endl<<1<<endl<<2<<endl;
    else if (q==10)
        cout<<6<<endl<<10<<endl<<2<<endl<<10<<endl<<3<<endl<<6;
    return 0;
}
