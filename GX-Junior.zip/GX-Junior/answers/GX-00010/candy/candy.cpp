#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    long long n,l,r,maxnumber=0;
    cin>>n>>l>>r;
    for (int i=l;i<=r;i++)
    {
        long long sum=i;
        while (sum>=n)
        {
            sum=sum-n;
        }
        if (sum>maxnumber)
        {
            maxnumber=sum;
        }
    }
    cout<<maxnumber;

    return 0;
}
