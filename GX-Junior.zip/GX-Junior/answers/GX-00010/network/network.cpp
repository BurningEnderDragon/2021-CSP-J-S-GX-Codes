#include<bits/stdc++.h>
using namespace std;
struct com
{
    string op,ad,bc;
    int cd,bj;
};
com s[1003],c[1003],d[1003];
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int n,ssum=1,csum=1;
    cin>>n;
    for (int i=1;i<=n;i++)
    {
      cin>>d[i].op>>d[i].ad;
    }
    for (int i=1;i<=n;i++)
    {
        if (d[i].op=="Server")
        {
            s[ssum].op=d[i].op;
            s[ssum].ad=d[i].ad;
            s[ssum].bc=d[i].bc;
            s[ssum].cd=d[i].cd;
            s[ssum].bj=d[i].bj;
            ssum++;
        }
        else if (d[i].op=="Client")
        {
            c[csum].op=d[i].op;
            c[csum].ad=d[i].ad;
            c[csum].bc=d[i].bc;
            c[csum].cd=d[i].cd;
            c[csum].bj=d[i].bj;
            csum++;
        }
    }
    for (int i=1;i<=ssum;i++)
    {
        for (int j=1;j<=csum;j++)
        {
            if (s[i].ad==c[j].ad)
            {
                s[i].bc="OK";
                s[i].bj=1;
                c[j].cd=i;
                c[i].bj=1;
            }
            if (s[i].bj!=1)
                s[i].bc="FAIL";
        }
    }
    for (int i=1;i<=csum;i++)
    {
        if (c[i].bj!=1)
            c[i].bc="FAIL";
    }
    for (int i=1;i<=n;i++)
    {
        if (d[i].op=="Server")
            cout<<d[i].bc<<endl;
        else if (d[i].op=="Client")
        {
            if (d[i].bj==1)
                cout<<d[i].cd<<endl;
            else
                cout<<d[i].bc<<endl;
        }

    }
    return 0;
}
