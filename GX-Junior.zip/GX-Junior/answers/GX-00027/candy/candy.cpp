#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    long long n=0,l=0,r=0;
    cin>>n>>l>>r;
    long long maxn=0;
    for(long long i=l;i<=r;i++)
    {
        maxn=max(i%n,maxn);
    }
    cout<<maxn;
    return 0;
}
