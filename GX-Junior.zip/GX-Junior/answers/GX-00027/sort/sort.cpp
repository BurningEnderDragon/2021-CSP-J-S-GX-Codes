#include<bits/stdc++.h>
using namespace std;
long long n,q,meiyong;
struct sign
{
    long long number;
    long long shu;
};
sign a[8005];
sign b[8005];
/*bool cmp(sign c,sign d)
{
    if(c.shu<d.shu)
    {
        return true;
    }
    return false;
}*/
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    cin>>n>>q;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i].shu;
        a[i].number=i;
        b[i].shu=a[i].shu;
        b[i].number=a[i].number;
    }
    for(int i=1;i<=q;i++)
    {
        cin>>meiyong;
        int x=0,y=0,z=0;
        if(meiyong==1)
        {
            cin>>x>>y;
            a[x].shu=y;
            b[x].shu=y;
        }
        else
        {
            cin>>z;
            for(int j=1;j<=n;j++)
            {
                for(int k=j;k>=2;k--)
                {
                    if(b[k].shu<b[k-1].shu)
                    {
                        swap(b[k-1].shu,b[k].shu);
                        swap(b[k-1].number,b[k].number);
                    }
                }
            }
            //sort(b+1,b+n+1,cmp);
            for(int j=1;j<=n;j++)
            {
                if(b[j].number==z)
                {
                    cout<<j<<endl;
                    break;
                }
            }
            for(int j=1;j<=n;j++)
            {
                b[j].shu=a[j].shu;
                b[j].number=a[j].number;
            }
        }
    }
    return 0;
}
