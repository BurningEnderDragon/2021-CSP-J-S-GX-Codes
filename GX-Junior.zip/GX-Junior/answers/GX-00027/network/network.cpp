#include<bits/stdc++.h>

using namespace std;

int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    return 0;
}
