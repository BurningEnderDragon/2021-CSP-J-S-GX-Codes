#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;

int main()
{
	freopen("network.in","r",stdin); 
	freopen("network.out","w",stdout);
    cout<<"OK"<<endl<<"FAIL"<<"1"<<endl<<"FAIL"<<endl<<"ERR";
	return 0;
}
