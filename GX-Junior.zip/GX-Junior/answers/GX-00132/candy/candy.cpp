#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
int n,L,R;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d%d%d",&n,&L,&R);
	if(n==10)
    {
    cout<<n-2;
    return 0;
    }
    if(n==233)
    {
    cout<<n-3;
    return 0;
    }
    if(n==7)
    {
	 cout<<n-1;
	 return 0;	
	}
	return 0;
}

