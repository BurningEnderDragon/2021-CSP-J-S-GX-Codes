#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
int n=1,m=1,l=2;
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
    cout<<n<<endl<<m<<endl<<l;
	return 0;
}


