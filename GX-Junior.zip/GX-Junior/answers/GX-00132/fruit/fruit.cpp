#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
    

   
	return 0;
}


