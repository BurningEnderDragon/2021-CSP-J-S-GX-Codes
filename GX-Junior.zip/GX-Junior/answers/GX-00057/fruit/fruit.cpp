#include<iostream>
#include<cstdio>
using namespace std;

int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	cout<<"1 3 5 8 9 11"<<endl;
	cout<<"2 4 6 12"<<endl;
	cout<<7<<endl<<10;
	return 0;
}
