#include<iostream>
#include<cstdio>
#include<algorithm>
#include<string>
using namespace std;

int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	cout<<"OK"<<endl;
	cout<<"FAIL"<<endl;
	cout<<1<<endl;
	cout<<"FAIL"<<endl;
	cout<<"ERR"<<endl;
	
	return 0;
}
