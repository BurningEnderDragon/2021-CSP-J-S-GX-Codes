#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;

int n,L,r,ans,k;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d%d%d",&n,&L,&r);
	for(int i=L; i<=r; i++)
	{
		k=i%n;
		ans=max(ans,k);
		if(k==0) {cout<<n-1;return 0;}
	}
	printf("%d",ans);
	return 0;
}
