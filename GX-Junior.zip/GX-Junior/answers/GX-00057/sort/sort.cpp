#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
struct dnn
{
	int x,id;
}a[8010],b[8010];
int n,Q,way,v,w;
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d%d",&n,&Q);
	for(int i=1; i<=n; i++)
	{	
		scanf("%d",&a[i].x);
		a[i].id=i;
	}
	while(Q--)
	{
		scanf("%d",&way);
		if(way==1)
		{
			scanf("%d%d",&w,&v);
			a[w].x=v;
		}
		if(way==2)
		{
			scanf("%d",&w);
			for(int j=1; j<=n; j++)
				b[j]=a[j];
			for(int i=1; i<=n; i++)
				for(int j=i; j>=2; j--)
					if(b[j].x<b[j-1].x)
						swap(b[j],b[j-1]);
			for(int i=1; i<=n; i++)
				if(b[i].id==a[w].id) {printf("%d\n",i);break;}
		}
	}
	
	return 0;
}
