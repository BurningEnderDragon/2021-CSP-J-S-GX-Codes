#include <iostream>
using namespace std;
int main()
{
	freopen("sort.in","r",stdin);
	int a,b;
	cin >>a>> b;
	for(int i=0;i<a;i++){
		cin >> a;
	}
	cout<<"1"<<endl<<"1"<<endl<<"2"endl;
}
