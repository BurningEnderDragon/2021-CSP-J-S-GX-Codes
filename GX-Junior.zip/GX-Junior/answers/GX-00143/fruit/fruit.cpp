#include <iostream>
using namespace std;
int lhf[300000] = {};
int main()
{
	freopen("fruit.in","r",stdin);
	int a,l=114514,p = 1919810;
	cin >> a;
	for(int i =0;i<a;i++){
		cin >> lhf[i];
	}
	for(int i =0;i<a;i++){
		if (lhf[i] != -1){
			for(int i =0;i<a;i++){
				if (lhf[i] == -1){
					continue;
				}
				else if (l != lhf[i]){
					l = lhf[i];
					cout << i<<" ";
					p = i;
					lhf[i]=-1;
				}
		
			}
		}
	}
	return 0;	
}
	
