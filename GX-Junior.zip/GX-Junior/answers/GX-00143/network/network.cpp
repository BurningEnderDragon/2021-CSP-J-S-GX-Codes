#include <iostream>
using namespace std;
int main()
{
	freopen("network.in","r",stdin);
	cout<<"OK"<<endl;
	cout<<"FAIL"<<endl;
	cout<<"1"<<endl;
	cout<<"FAIL"<<endl;
	cout<<"ERR"<<endl;
}
