#include <iostream>
using namespace std;
int main()
{
	freopen("candy.in","r",stdin);
	int n,l,r,a=0;
	cin >> n >> l >> r;
	while(a<l){
		a +=n;
		if(a == l){
			cout<<r-l;
			break;
		}
		if(a<l){
			if(a+n-1>l && a+n-1<r){
				cout<<a+n-1;
				break;
			}
			else if(a+n-1>r){
				cout <<r-a;
				break;
			}
			else{
				continue;
			}
		}
	}
	return 0;
		
}
