#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int n,q,s,x,v;
    cin>>n>>q;
    int a[n+5],b[q+5],c[n+5];
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    for(int m=1;m<=q;m++){
        cin>>b[m];
        if(b[m]==1){
            cin>>x>>v;
            a[x]=v;
        }
        else{
            cin>>s;
            for(int i=1;i<=n;i++){
                c[i]=a[i];
            }
            for (int i=1;i<=n;i++)
                for (int j=i;j>=2;j--)
                    if (c[j]<c[j-1]){
                        if(j==s)
                            s--;
                        int t=c[j-1];
                        c[j-1]=c[j];
                        c[j]=t;
                    }
            cout<<s<<endl;
        }
    }
    return 0;
}
