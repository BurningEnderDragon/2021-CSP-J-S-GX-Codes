#include<bits/stdc++.h>
using namespace std;
int op[1005],zt[1005]={0};
string id[1005];
struct id{
    string c;
};
int main(){
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int n;
    cin>>n;
    string a;
    for(int i=1;i<=n;i++){
        cin>>a;
        if(a=="Server")
            op[i]=0;
        else
            op[i]=1;
        getline(cin,id[i].c())
    }
    for(int i=1;i<=n;i++){
        cout<<op[i]<<" "<<id[i]<<endl;
    }
    return 0;
}
