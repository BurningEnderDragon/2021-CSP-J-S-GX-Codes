#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,l,r,k=0;
    cin>>n>>l>>r;
    for(int i=l;i<=r;i++){
        if(i%n>k)
        k=i%n;
    }
    cout<<k;
    return 0;
}
