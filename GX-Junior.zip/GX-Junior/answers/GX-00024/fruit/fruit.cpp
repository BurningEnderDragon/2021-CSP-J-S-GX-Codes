#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    int n;
    cin>>n;
    int a[n+5]={-1},b[n+5],c=0,d[n+5]={0};
    for(int i=1;i<=n;i++){
        cin>>a[i];
        if(a[i]=a[i-1]){
            b[i]=c;
        }
        else{
            c++;
            b[i]=c;
        }
    }
    while(n>0){
        int g=1;

        for(int i=1;i<=n;i++){
            if(b[i]==g){
                d[i]=1;
                cout<<i;
                n--;
            }
        }
        for(int i=1;i<=n;i++){
        cin>>a[i];
        if(a[i]=a[i-1]){
            b[i]=c;
        }
        else{
            c++;
            b[i]=c;
        }
        }
    }
    return 0;
}
