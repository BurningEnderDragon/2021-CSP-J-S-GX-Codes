#include<bits/stdc++.h>
using namespace std;
int main(){
freopen("candy.in","r",stdin);
freopen("candy.out","w",stdout);
int n,l,r,a,b;
cin>>n>>l>>r;
a=r/n; 
b=l/n;
if(l-n>=n)
{
	if(r/n==l/n)
	cout<<r-a*n;
	if(a>b)
	{
		if(r-a*n>l-b*n)cout<<r-a*n;
		else cout<<l-b*n;
	}
	
}
else if(r-n<n)
{
	cout<<r-n;
}	
return 0;
}
