#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
using namespace std;
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
    for (int i = 1; i <= n; i++)
    for (int j = i; j>=2; j‐‐)
    int a[100] j;
    if ( a[j] < a[j‐1] ){
     int t = a[j‐1];
    a[j‐1] = a[j];
    a[j] = t;
}

return 0;
} 
