#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	int n[1005];
	int a,b[255],c,d,e[65535];
	

return 0;
}
