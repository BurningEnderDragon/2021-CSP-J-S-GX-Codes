#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
long long n,l,r;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>n>>l>>r;	
    long long k=l%n;
    if(k==0)
    long long ans=min(r-l,n-1);
    else()
    long long ans=min(r-l,n-1);
    printf("lld"/)

return 0;
}
