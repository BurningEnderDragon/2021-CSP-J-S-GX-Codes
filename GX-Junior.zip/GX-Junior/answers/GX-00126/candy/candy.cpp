#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
long long n,l,r,ans;
int main()
{
  freopen("candy.in","r",stdin);	
  freopen("candy.out","w",stdout);
  cin>>n>>l>>r;
  ans=r-l;
  l=l%n;
  r=r%n;
  if(n-l<ans) cout<<n-1;
  else 
    printf("%lld",r);
  return 0;
}
