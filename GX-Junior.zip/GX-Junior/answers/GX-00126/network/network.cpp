#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<algorithm>
using namespace std;
int n;
int main()
{
  freopen("network.in","r",stdin);	
  freopen("network.out","w",stdout);
  cin>>n;
  cout<<"OK";
  cout<<endl;
cout<<"1";
  cout<<endl;
cout<<"FAIL";
  cout<<endl;
cout<<"FAIL";
  cout<<endl;
cout<<"OK";
  cout<<endl;
cout<<"ERR";
  cout<<endl;
cout<<"ERR";
  return 0;
}

