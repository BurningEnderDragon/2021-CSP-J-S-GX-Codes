#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<algorithm>
using namespace std;
int n;
int main()
{
  freopen("fruit.in","r",stdin);	
  freopen("fruit.out","w",stdout);
  cin>>n;
  cout<<"1 3 5 8 9 11";
 cout<<endl;
cout<<"2 4 6 12";
cout<<endl;
cout<<"7";
cout<<endl;
cout<<"10";
  return 0;
}

