#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<algorithm>
using namespace std;
int n;
int main()
{
  freopen("sort.in","r",stdin);	
  freopen("sort.out","w",stdout);
  cin>>n;
  cout<<"1";
    cout<<endl;
    cout<<"1";
      cout<<endl;
      cout<<"2";
  return 0;
}
