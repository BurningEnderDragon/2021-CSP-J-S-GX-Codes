#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
long long n,l,r,ans=0;
int main()
{
  freopen("candy.in","r",stdin);
  freopen("candy.out","w",stdout);
  scanf("%lld%lld%lld",&n,&l,&r);
  for(int i=l;i<=r;i++)
    ans=max(ans,i%n);
  printf("%lld\n",ans);
  return 0;
}
