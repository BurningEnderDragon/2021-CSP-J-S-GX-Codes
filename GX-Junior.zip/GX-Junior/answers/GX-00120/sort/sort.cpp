#include<iostream>
#include<cstring>
#include<cstdio>
#include<string>
#include<algorithm>
using namespace std;
int n,q;
struct pai
{
	int no,z;
}a[10010],f[10010];
bool cmp(pai a,pai b)
{
  return a.z<b.z;	
}
int main()
{
  freopen("sort.in","r",stdin);
  freopen("sort.out","w",stdout);
  scanf("%d%d",&n,&q);
  for(int i=1;i<=n;i++)
  {
    scanf("%d",&a[i].z);
    a[i].no=i;
  }
  for(int k=1;k<=q;k++)
  {
	int x;
	scanf("%d",&x);
    if(x==1)
    {
	  int m,t;
	  scanf("%d%d",&m,&t);
	  for(int i=1;i<=n;i++)
	    for(int j=1;j>=1;j--)
	      if(a[j].z<a[j-1].z)
	      {
			int g=a[j-1].z;
			a[j-1].z=a[j].z;
			a[j].z=g;  
		  }
      a[m].z=t;
	}
	else
	{
	  int m;
	  scanf("%d",&m);
	  int w1=a[m].z,w2=a[m].no;
	  for(int i=1;i<=n;i++)
	  {
		f[i].z=a[i].z;
		f[i].no=a[i].no;
	  }
	  sort(a+1,a+n+1,cmp);
	  for(int i=1;i<=n;i++)
	    if(w1==a[i].z && w2==a[i].no)
	    {
	      printf("%d\n",i);
	      break;
	    }
	  for(int i=1;i<=n;i++)
	  {
		a[i].z=f[i].z;
		a[i].no=f[i].no;
	  }
	}
  }
  return 0;
}
