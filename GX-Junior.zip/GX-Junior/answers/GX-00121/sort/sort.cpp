#include<iostream>
using namespace std;
int main(){
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	int n,Q[10001];
	for(int i=1;i<=n;i++)
		for(int j=i;j>=2;j--)
			if(Q[j]<Q[j-1]){
				int t=Q[j-1];
				Q[j-1]=Q[j];
				Q[j]=t;
				}
	return 0;
}
