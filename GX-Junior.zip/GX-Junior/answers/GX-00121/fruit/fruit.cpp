#include<iostream>
using namespace std;
int main(){
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	int n,i;
	cin>>i>>n;
	
	}
