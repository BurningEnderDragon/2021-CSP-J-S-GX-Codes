#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
using namespace std;
int n,l,r,a[10000000],b;
int main()
{
     freopen("candy1.in","r",stdin);
     freopen("candy.out","w",stdout);
     int j=1;
     scanf("%d %d %d",&n,&l,&r);
     for(int i=r;i>=l;i--)
     {
		  if(i>=n)
	          i-=n;
	      if(i<n)
	          a[j]=i;
	       	 j++;
     }
     for(int i=1;i<=1000;i++)
          b=max(b,a[i]);
     cout<<b;
     return 0;
}
