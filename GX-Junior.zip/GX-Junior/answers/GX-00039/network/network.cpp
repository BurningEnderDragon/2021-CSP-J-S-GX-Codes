#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
using namespace std;
 int n;
int main()
{
     freopen("candy.in","r",stdin);
     freopen("candy.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++)
    {
		 cout<<"OK"<<endl;
	}
     return 0;
}
