#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
using namespace std;
int n,a[1000000];
int main()
{
     freopen("fruit.in","r",stdin);
     freopen("fruit.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++)
        scanf("%d",&a[i]);
    for(int i=1;i<=n;i++)
    {
		if(a[i]==a[i+1])
		{
			cout<<a[i]<<" ";
			i++;
			a[i]=a[i+1];
			if(i==n-1)
			for(int j=1;j<=n/2;j++)
    {
		if(a[j]==a[j+1])
		{
			cout<<a[j]<<" ";
			j++;
			a[j]=a[j+1];
			if(j==n/2-1)
			for(int p=1;p<=n/2/2;p++)
    {
		if(a[p]==a[p+1])
		{
			cout<<a[p]<<" ";
			++;
			a[p]=a[p+1];
		}
		else
		{
			cout<<a[p]<<" ";
			a[p]=a[p+1];
		}
    }
		}
		else
		{
			cout<<a[p]<<" ";
			a[p]=a[p+1];
		}
    }
		}
		else
		{
			cout<<a[p]<<" ";
			a[p]=a[p+1];
		}
    }
     return 0;
}
