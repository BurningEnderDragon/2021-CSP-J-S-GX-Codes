#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("fruit.in","r",stdin);
	freopen("furit+.out","w",stdout);
	int n;
	cin>>n;
	return 0;
}
