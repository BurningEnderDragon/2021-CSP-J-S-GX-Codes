#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	int n;
	cin>>n;
	char op,ad;
	cin>>op>>ad;
	return 0;
	
	
}
