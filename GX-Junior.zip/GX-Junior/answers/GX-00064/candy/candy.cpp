#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	int n,l,r,k;
	cin>>n>>l>>r;
	k=r;
	while(n>=r){
		k%n=l;
		
		
		
		
		
		
	}
		
		
	
	
	return 0;
	









}
