#include <bits/stdc++.h>
using namespace std;
int main(){
freopen("candy.in","r",stdin);
freopen("candy.out","w",stdout);
    int n,l,r;
    cin>>n>>l>>r;
    int k=l,max=-1,ans=0;
    while(k<=r){
        int i=k;
    while(i>=n){
        i=i-n;
        ans=i;
    }
        if(ans>max){
            max=ans;
        }
        k++;
    }
    cout<<max;
return 0;
}
