#include <bits/stdc++.h>
using namespace std;
int main(){
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int n,q;
    cin>>n>>q;
    int a[8005],b[8005],xb[8005],xb1[8005],out[8005],tmp=1,sum=0;
    for(int i=1;i<=n;i++){
    	cin>>a[i];
    	xb[i]=i;
    }
    int id,x,v;
    for(int u=1;u<=q;u++){
        cin>>id;
        if(id==1){
            cin>>x>>v;
            a[x]=v;
        }
        if(id==2){
            sum++;
            cin>>x;
            for(int l=1;l<=n;l++){
                b[l]=a[l];
                xb1[l]=xb[l];
            }
 for(int i=1;i<=n;i++){
        for(int j=i;j>=2;j--){
            if(b[j]<b[j-1]){
                int t=b[j-1],t1=xb1[j];
                b[j-1]=b[j];
                xb1[j]=xb1[j-1];
                b[j]=t;
                xb1[j-1]=t1;
            }
        }
    }
    for(int e=1;e<=n;e++){
        if(xb1[e]==x){
            out[tmp]=xb[e];
            tmp++;
        }
    }
        }
    }

    for(int i=1;i<=sum;i++){
        cout<<out[i]<<endl;
    }
return 0;
}
