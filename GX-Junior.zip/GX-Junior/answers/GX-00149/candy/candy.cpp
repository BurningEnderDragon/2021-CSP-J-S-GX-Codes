#include<iostream>
#include<cstdio>
using namespace std;
long long n,L,R;
long long ans;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>n>>L>>R;
	ans=L%n;
	if(ans-L+R>n-1)
	  cout<<n-1;
	else
	  cout<<ans+R-L;
	return 0;
}
