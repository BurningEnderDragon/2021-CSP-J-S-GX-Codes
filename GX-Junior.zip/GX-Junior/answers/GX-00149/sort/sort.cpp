#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
struct edge
{
	int v;
	int id;
}b[10000];
int a[10000];//sort list 
int n,q;
void mysort()
{
	for (int i = 1; i <= n; i++)
		for(int j=i;j>=2;j--)
			if(b[j].v<b[j-1].v){
				edge t=b[j-1];
				b[j-1]=b[j];
				b[j] = t;

				}
}
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	cin>>n>>q;
	for(int i=1;i<=n;i++)
	{
	  cin>>a[i];
	  b[i].v=a[i],b[i].id=i;
    }
	mysort();
	for(int i=1,s1,s2,s3;i<=q;i++)
	{
		cin>>s1;
		if(s1==1)
		{
			cin>>s2>>s3;
			a[s2]=s3;
			for(int j=1;j<=n;j++)
			  b[j].v=a[j],b[j].id=j;
			mysort();
		}
		else
		{
			cin>>s2;
			for(int j=1;j<=n;j++)
			  if(b[j].id==s2)
			  {
				  cout<<j<<endl;
				  break;
			  }
		}
	}
	return 0;
}
