#include<iostream>
#include<cstdio>
using namespace std;
int n;
struct Fruit
{
	int id;//in a pos
	int f;//What fruit
	int vis;//in box?
}a[200010];
int k[200010];
void fenkuai()
{
	k[1]=1;
	for(int i=2,j=1;i<=n;i++)
	{
	  if(a[i].f==a[i-1].f)
	    k[i]=j;
	  else
	    j+=1,k[i]=j;
	 }
}
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	cin>>n;
	getchar();
	for(int i=1;i<=n;i++)
	  a[i].f=getchar()-48,a[i].vis=0,a[i].id=i,getchar();
	fenkuai();
	while(n>0)
	{
		int m=n;
		for(int i=1;i<=n;i++)
		  if(k[i]!=k[i-1])
		  {
			  printf("%d ",a[i].id);
			  a[i].vis=1;
			  m--;
		  }
		for(int j=1;j<=n-m;j++)
		  for(int i=1;i<=n-j+1;i++)
		    if(a[i].vis)
		      swap(a[i],a[i+1]);
		 n=m;
		 cout<<endl;
		 fenkuai();
	}
	return 0;
}
