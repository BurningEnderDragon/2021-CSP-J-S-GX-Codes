#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
bool hf(string s)
{
	int ns=0,len=s.size()-1;
	for(int i=1;i<=4;i++)
	{
		int n=0,flag=0;
		for(;1>0;ns++)
		{
			if(s[ns]=='0' && flag==0)
			{
		      //printf("ERROR IP:Head '0'\n");
			  return false;
			}
			if(s[ns]=='.' || s[ns]==':')
			{
				if((s[ns]==':' && i!=4) || (s[ns]=='.' && i==4))
				{
			      //cout<<"ERROR IP:More '.' or ':'\n";
				  return false;
				}
				if(n>256)
				{
			      //cout<<"ERROR IP:Big Number\n";
				  return false;
			    }
				ns++;
				break;
			}
			n=n*10+s[ns]-48;
			flag=1;
		}
	}
	int n=0;
	for(int i=ns;i<=len;i++)
	  n=n*10+s[i]-48;
	if(n>65536)
	{
      //cout<<"ERROR IP: BIG Number\n";
	  return false;
    }
	return true;
}
string s[10000];
int b[10000];
int n,m,len;
//m=How many right Client
//len=How many right Server
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		string id,ip;
		cin>>id>>ip;
		if(!hf(ip)) {cout<<"ERR\n";continue;}
		if(id=="Server")
		{
			bool flag=true;
			for(int j=1;j<=len;j++)
			  if(ip==s[j])
			  {
				flag=false;
			    cout<<"FAIL\n";
			    break;
			  }
			if(flag)
			{
			  s[++len]=ip;
			  b[len]=i;
			  cout<<"OK\n";
			}
		}
		else
		{
			bool flag=false;
			for(int j=1;j<=len;j++)
			  if(ip==s[j])
			  {
				flag=true;
			    cout<<b[j]<<endl;
			    break;
			  }
			if(!flag)
			  cout<<"FAIL\n";
		}
	}
	return 0;
}
