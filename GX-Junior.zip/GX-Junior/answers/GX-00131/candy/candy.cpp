#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
    int i,n,L,R,k,sum=0,maxs=0;//n is the children;L is I can zhi shao;R is my can do;sum is my pleased;
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    cin>>n>>L>>R;
    for(i=L;i<=R;++i)
    {
        k=i;
        sum=k%n;
        if(maxs<sum)
        {
            maxs=sum;
        }
    }
    cout<<maxs;
    return 0;
}
