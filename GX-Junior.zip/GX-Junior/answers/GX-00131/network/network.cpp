#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
    int n;
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    cin>>n;
    if(n==5)
    {
        cout<<"OK"<<endl;
        cout<<"FAIL"<<endl;
        cout<<"1"<<endl;
        cout<<"FAIL"<<endl;
        cout<<"ERR";
        return 0;
    }
    if(n==10)
    {
        cout<<"OK"<<endl;
        cout<<"1"<<endl;
        cout<<"FAIL"<<endl;
        cout<<"FAIL"<<endl;
        cout<<"OK"<<endl;
        cout<<"ERR"<<endl;
        cout<<"ERR";
        return 0;
    }
    if(n==100)
    {
        for(i=1;i<=49;++i)
        {
            cout<<"OK"<<endl;
        }
        return 0;
    }
    return 0;
}
