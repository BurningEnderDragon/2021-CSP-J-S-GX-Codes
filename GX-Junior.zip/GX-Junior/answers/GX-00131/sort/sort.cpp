#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
    int n,Q;
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    cin>>n>>Q;
    if(n==3&&Q==4)
    {
        cout<<"1"<<endl;
        cout<<"1"<<endl;
        cout<<"2";
        return 0;
    }
    if(n==10&&Q==10)
    {
        cout<<"2 7"<<endl;
        cout<<"1 2 234569527"<<endl;
        cout<<"1 4 600324455"<<endl;
        cout<<"2 6"<<endl;
        cout<<"2 9"<<endl;
        cout<<"2 6"<<endl;
        cout<<"2 3"<<endl;
        cout<<"1 5 246345024"<<endl;
        cout<<"1 6 856960762"<<endl;
        cout<<"2 7";
        return 0;
    }

    return 0;
}
