#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    long long n,l,r,ma=0;
    cin>>n>>l>>r;
    for(int a=l;a<=r;a++)
    {
        if(a%n>=ma)
            ma=a%n;
    }
    cout<<ma;
    return 0;
}
