#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int a[8005],ot[8005];
    long long n,q;
    int l,l1,l2,flag=0;
    cin>>n>>q;
    int ans[8005];
    for(int b=1;b<=n;b++)
    {
        cin>>l;
        a[b]=l;
        ot[b]=l;
    }
    for(int b=0;b<q;b++)
    {
        for(int v=1;v<=n;v++)
            ot[v]=a[v];
        cin>>l;
        if(l==1)
        {
            cin>>l1>>l2;
            a[l1]=l2;
        }
        else
        {

            cin>>l1;
            for(int i=1;i<=n;i++)
                for(int j=i;j>=2;j--)
                    if(ot[j]<ot[j-1]){
                        int t=ot[j-1];
                        ot[j-1]=ot[j];
                        ot[j]=t;
                        if(l1==j)
                            l1--;
                    }
            ans[flag]=l1;
            flag++;
        }
    }
    for(int a=0;a<flag;a++)
        cout<<ans[a]<<endl;
    return 0;
}
