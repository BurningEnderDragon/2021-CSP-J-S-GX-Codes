#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int sever[105];
    int client[105];
    string af[100];
    int n;
    for(int a=0;a<n;a++)
    {
        cin>>af[a];
    }
    for(int a=0;a<n;a++)
    {

    }
    return 0;
}
