#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    int n,flag=0,f=2,k;
    cin>>n;
    int fr[50005];
    int bol[50005];
    for(int a=1;a<=n;a++)
    {
        cin>>fr[a];
        bol[a]=1;
    }
    for(int a=1;a<=n;a++)
    {
        if(fr[a]!=fr[a-1])
            flag++;
    }
    for(int a=1;a<=flag;a++)
    {
        f=2;
        for(int b=1;b<=n;b++)
        {
            if(fr[b]!=f&&bol[b]!=2)
            {
                f=fr[b];
                cout<<b<<" ";
                bol[b]=2;
            }
        }
        k=0;
        for(int c=1;c<=n;c++)
        {
            if(bol[c]!=2)
            {
                k++;
                break;
            }
        }
        if(k==0)
            break;
        cout<<endl;
    }
    return 0;
}
