#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    int a[3],i,s1,s2,x,y;
    bool m=false,n=false;
    for(i=1; i<=3; ++i)
    {
        cin>>a[i];
    }
    cin>>x>>y;
    for(i=1; i<=3; ++i)
    {
        if(m=false)
        {
            if(a[i]==x)
            {
                s1=i;
                m=true;
            }
        }
        if(n=false)
        {
            if(a[i]==y)
            {
                s2=i;
                n=true;
            }
        }
    }
    swap(a[s1],a[s2]);
    for(i=1; i<=i; ++i)
    {
        cout<<a[i]<<" ";
    }
    return 0;
}

