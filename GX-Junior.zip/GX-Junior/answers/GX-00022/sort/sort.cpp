#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    //freopen("sort.in","r",stdin);
    //freopen("sort.out","w",stdout);
    long long a[10001],i,j,n,Q,p,x,y,z,t,k;
    cin>>n>>Q;
    for(i=1; i<n; ++i)
    {
        cin>>a[i];
    }
    for ( i = 1; i <= n; i++)
    {
        for ( j = i; j>=2; j--)
        {
            if ( a[j] > a[j-1] )
            {
                swap(a[j-1],a[j]);
            }
        }
    }
    for(i=1; i<=Q; ++i)
    {
        cin>>p;
        if(p==2)
        {
            cin>>x;
            for(i=1; i<=n; ++i)
            {
                if(a[i]==x)
                {
                    cout<<i<<endl;
                    break;
                }
            }
        }
    }
    if(p==1)
    {
        cin>>y>>z;
        for(i=1;i<=n;++i)
        {
            if(a[i]==y)
            {
                t=i;
            }
            if(a[i]==z)
            {
                k=i;
            }
        }
        swap(a[t],a[k]);
    }
    return 0;
}

