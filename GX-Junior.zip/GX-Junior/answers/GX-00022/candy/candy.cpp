#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    long long n,L,R,a[10005],i,b=0,max1=-1000,s;
    cin>>n>>L>>R;
    for(i=L;i<=R;++i)
    {
        a[b]=i%n;
        ++b;
    }
    for(i=0;i<R-L+1;++i)
    {
        if(a[i]>max1&&a[i]<n)
        {
            max1=a[i];
        }
    }
    cout<<max1<<endl;
    return 0;
}
