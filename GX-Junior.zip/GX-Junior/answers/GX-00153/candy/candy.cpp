#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
long long rs,tsx,txx;
cin>>rs>>tsx>>txx;
if(rs>=tsx>=txx)
{

cout<<rx;
}
    return 0;
}
