#include <bits/stdc++.h>
#include <iostream>
using namespace std;
int main ()
{
  long long a,b,c;
  cin>>a>>b>>c;
  long long k;
  for(int f=b;f<=c;f++)
  {
	  
	  if(k>=a)
	  {
		  k=k-a;
	  }
	  else
	  {
		  cout<<k;
		  break;
	  }
  }
}
