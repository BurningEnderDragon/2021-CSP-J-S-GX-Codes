#include <bits/stdc++.h>
#include <iostream>
using namespace std;
int main ()
{
  
}
