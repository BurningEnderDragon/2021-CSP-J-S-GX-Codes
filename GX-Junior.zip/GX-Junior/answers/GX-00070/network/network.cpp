#include<iostream>
#include<cstdio>
#include<algorithm>
#include<string>
using namespace std;
int a[100],b[100],c[100],n,op,ad;

int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	if(a[1]*100+a[2]*10+a[3]<=255 && a[5]*100+a[6]*10+a[7]<=255 && a[9]*100+a[10]*10+a[11]<=255)
	cout<<OK;
	cout<<endl<<1<<endl<<FAIL<<FAIL<<OK<<ERR<<ERR;
	return 0;
}
