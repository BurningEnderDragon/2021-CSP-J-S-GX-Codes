#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
using namespace std;

int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	int n,a;
	cin>>n;
	sort(a+1,a+n+1);
	cout<<a;
	return 0;
}
