#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
using namespace std;
int n,a[50001],sum,b[50001];
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++)
      scanf("%d",&a[i]);
      sum=a[i];
      for(int i=1;i<=n;i++)
      scanf("%d",&b[i]);
      cout<<a[i]<<endl<<n[i];
       
    return 0;
}
