#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>

using namespace std;

int n,l,r,k;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    cin>>n>>l>>r;
    while(l>=n)
    {
		l=l-n;
		
	}
    return 0;
}
