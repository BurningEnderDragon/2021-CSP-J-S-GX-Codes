#include <bits/stdc++.h>

using namespace std;

int n,Q;
int lis[8050],tmp[8050];
int m,x,v;

int main()
{

}

