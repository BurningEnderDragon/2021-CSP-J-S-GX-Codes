#include <bits/stdc++.h>

using namespace std;

long long n,l,k,ans;

int main()
{
    scanf("%d%d%d",&n,&l,&k);
    ans = l%n;
    //printf("%d %d %d\n",n,l,k);
    for(int i = l+1;i<=k;i++){
        ans++;
        //printf("%d %d\n",ans,i);
        if(ans==n-1)break;
    }

    printf("%d",ans);
    return 0;
}

