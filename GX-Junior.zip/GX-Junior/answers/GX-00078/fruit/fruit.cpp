#include <bits/stdc++.h>

using namespace std;

int n,lis[200050];
int curr=2,mrk=0;
bool whlflag=false;

int main()
{
    scanf("%d",&n);
    for(int i =1;i<=n;i++){
       scanf("%d",&lis[i]);
    }

    while(whlflag == false){
        whlflag = true;
        mrk--;
        curr = 2;
        for(int i = 1;i<=n;i++){
            if(lis[i]>=0){
				whlflag = false;
			}
            else{
            	i++;
//            	if(i<=n)
//            		continue;
			}

            if(lis[i]!=curr&&lis[i]>=0){
                curr = lis[i];
                lis[i] = mrk;
            }
        }
//    for(int i =1;i<=n;i++){
//        printf("%d ",lis[i]);
//    }
//    printf("\n");
    }
    for(int i = -1;i>=mrk;i--){
    	for(int j = 1;j<=n;j++){
    		if(lis[j]==i){
    			printf("%d ",j);
			}
		}
		printf("\n");
	}
    return 0;
}
