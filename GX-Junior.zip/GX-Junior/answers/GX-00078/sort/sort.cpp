#include <bits/stdc++.h>

using namespace std;

int n,Q;
int lis[8050],tmp[8050];
int m,x,v;

int main()
{
    scanf("%d%d",&n,&Q);
    for(int i = 1;i<=n;i++){
        scanf("%d",&lis[i]);
    }

    for(int p = 1;p<=Q;p++){
        scanf("%d",&m);
        if(m==1){
            scanf("%d%d",&x,&v);
            lis[x] = v;
        }else{
            scanf("%d",&x);
            for(int i = 1;i<=n;i++)
                tmp[i] = lis[i];

            for (int i = 1; i <= n; i++){
                for(int q = i;q>=2;q--){
                    if(tmp[q]<tmp[q-1]){
                        swap(tmp[q],tmp[q-1]);
                        if(q==x)x--;
                        else if(q-1==x)x++;
                    }
                }
            }
            printf("%d\n",x);
        }
    }
    return 0;
}

