#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int n,q=0;
    cin>>n;
    string st[n],st1[n];
    int a[n],b[n],c[n],d[n],e[n];
    for (int i=0;i<n;i++){
        cin>>st[i]>>st1[i];
    }
    for (int i=0;i<n;i++){
        for(int j=0;st1[i][j]!='.';j++){
            q++;
            if(st1[i][j]=='1'){
                a[i]=a[i]+1*10;
            }if(st1[i][j]=='2'){
                a[i]=a[i]+2*10;
            }if(st1[i][j]=='3'){
                a[i]=a[i]+3*10;
            }if(st1[i][j]=='4'){
                a[i]=a[i]+4*10;
            }if(st1[i][j]=='5'){
                a[i]=a[i]+5*10;
            }if(st1[i][j]=='6'){
                a[i]=a[i]+6*10;
            }if(st1[i][j]=='7'){
                a[i]=a[i]+7*10;
            }if(st1[i][j]=='8'){
                a[i]=a[i]+8*10;
            }if(st1[i][j]=='9'){
                a[i]=a[i]+9*10;
            }if(st1[i][j]=='0'){
                a[i]=a[i]*10;
            }
        }for(int j=q+2;st1[i][j]!='.';j++){
            q++;
            if(st1[i][j]=='1'){
                b[i]=b[i]+1*10;
            }if(st1[i][j]=='2'){
                b[i]=b[i]+2*10;
            }if(st1[i][j]=='3'){
                b[i]=b[i]+3*10;
            }if(st1[i][j]=='4'){
                b[i]=b[i]+4*10;
            }if(st1[i][j]=='5'){
                b[i]=b[i]+5*10;
            }if(st1[i][j]=='6'){
                b[i]=b[i]+6*10;
            }if(st1[i][j]=='7'){
                b[i]=b[i]+7*10;
            }if(st1[i][j]=='8'){
                b[i]=b[i]+8*10;
            }if(st1[i][j]=='9'){
                b[i]=b[i]+9*10;
            }if(st1[i][j]=='0'){
                b[i]=b[i]*10;
            }
        }for(int j=q+2;st1[i][j]!='.';j++){
            q++;
            if(st1[i][j]=='1'){
                c[i]=c[i]+1*10;
            }if(st1[i][j]=='2'){
                c[i]=c[i]+2*10;
            }if(st1[i][j]=='3'){
                c[i]=c[i]+3*10;
            }if(st1[i][j]=='4'){
                c[i]=c[i]+4*10;
            }if(st1[i][j]=='5'){
                c[i]=c[i]+5*10;
            }if(st1[i][j]=='6'){
                c[i]=c[i]+6*10;
            }if(st1[i][j]=='7'){
                c[i]=c[i]+7*10;
            }if(st1[i][j]=='8'){
                c[i]=c[i]+8*10;
            }if(st1[i][j]=='9'){
                c[i]=c[i]+9*10;
            }if(st1[i][j]=='0'){
                c[i]=c[i]*10;
            }
        }for(int j=q+2;st1[i][j]!=':';j++){
            q++;
            if(st1[i][j]=='1'){
                d[i]=d[i]+1*10;
            }if(st1[i][j]=='2'){
                d[i]=d[i]+2*10;
            }if(st1[i][j]=='3'){
                d[i]=d[i]+3*10;
            }if( st1[i][j]=='4'){
                d[i]=d[i]+4*10;
            }if(st1[i][j]=='5'){
                d[i]=d[i]+5*10;
            }if(st1[i][j]=='6'){
                d[i]=d[i]+6*10;
            }if(st1[i][j]=='7'){
                d[i]=d[i]+7*10;
            }if(st1[i][j]=='8'){
                d[i]=d[i]+8*10;
            }if(st1[i][j]=='9'){
                d[i]=d[i]+9*10;
            }if(st1[i][j]=='0'){
                d[i]=d[i]*10;
            }
        }for(int j=q+2;st1[i][j]!='\0';j++){
            if(st1[i][j]=='1'){
                e[i]=e[i]+1*10;
            }if(st1[i][j]=='2'){
                e[i]=e[i]+2*10;
            }if(st1[i][j]=='3'){
                e[i]=e[i]+3*10;
            }if(st1[i][j]=='4'){
                e[i]=e[i]+4*10;
            }if(st1[i][j]=='5'){
                e[i]=e[i]+5*10;
            }if(st1[i][j]=='6'){
                e[i]=e[i]+6*10;
            }if(st1[i][j]=='7'){
                e[i]=e[i]+7*10;
            }if(st1[i][j]=='8'){
                e[i]=e[i]+8*10;
            }if(st1[i][j]=='9'){
                e[i]=e[i]+9*10;
            }if(st1[i][j]=='0'){
                e[i]=e[i]*10;
            }
        }
    }
    for (int i=0;i<n;i++){
        if(st[i][0]=='S'){
            if(0<=a[i]<=255 and 0<=b[i]<=255 and 0<=c[i]<=255 and 0<=d[i]<=255 and 0<=e[i]<=65535){
                for (int j=0;j<n;j++){
                    if(st1[j][0]=='C' and a[i]==a[j] and b[i]==b[j] and c[i]==c[j] and d[i]==d[j] and e[i]==e[i] and i!=j){
                        cout<<"OK"<<'\n';
                    }if(st1[i][1]=='S' and a[i]==a[j] and b[i]==b[j] and c[i]==c[j] and d[i]==d[j] and e[i]==e[i] and i!=j){
                        cout<<"FAIL"<<'\n';
                    }
                }
            }else{
                cout<<"ERR"<<"\n";
            }

        }else if(st[i][0]=='C'){
            if(0<=a<=255 and 0<=b[i]<=255 and 0<=c[i]<=255 and 0<=d[i]<=255 and 0<=e[i]<=65535){
                for (int j=0;j<n;j++){
                    if(st1[j][0]=='S' and a[i]==a[j] and b[i]==b[j] and c[i]==c[j] and d[i]==d[j] and e[i]==e[i] and i!=j){
                        cout<<j+1<<'\n';
                    }else{
                        cout<<"FAIL"<<'\n';
                    }
                }
            }else{
                cout<<"ERR"<<'\n';
            }

        }
    }
    return 0;
}
