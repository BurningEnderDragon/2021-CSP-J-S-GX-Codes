#include <bits/stdc++.h>

using namespace std;

int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,L,R,k,e=0;
    cin>>n>>L>>R;
    for (int i=1;i*n<R;i++){
        if(i*n<L){
            continue;
        }
        int a=i*n;//21
        e=0;
        for (int j=1;j<n;j++){
            int q=i-1;
            q=q*n;

            e=max(e,a-j-q);
        }

    }
    if(e==0){
        e=R-n;
    }
    cout<<e;
    return 0;
}
