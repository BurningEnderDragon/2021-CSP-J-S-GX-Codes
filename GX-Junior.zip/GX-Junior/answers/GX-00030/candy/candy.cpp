#include<fstream>
#include<cstring>
using namespace std;
ofstream fw("candy.out");
ifstream fr("candy.in");
int main()
{
    int n,l,r,k;
    fr>>n>>l>>r;
    //fw<<n<<"  "<<l<<"  "<<r<<endl;
    k=2*n-1;
    while(1)
    {
        if(k>r)
            k--;
        else break;
    }
    fw<<k-n<<endl;
    fw.close();
    fr.close();
    return 0;
}
