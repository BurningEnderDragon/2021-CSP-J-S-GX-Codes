#include<fstream>
#include<cstring>
using namespace std;
ofstream fw("network.out");
ifstream fr("network.in");
int main()
{
    char x[10000][10000],y[10000][10000];
    int z[10000][10000];
    int i,j,n;
    fr>>n;
    fw<<n<<endl;
    for(i=1;i<=n;++i)
        fr>>x[i]>>y[i];
    for(i=1;i<=n;++i)
        fw<<x[i]<<"  "<<y[i]<<endl;
    int a,b,c,d,e,f,g,k;
    i=1;j=1;k=1;
    while(i<=n)
    {
        for(j=1;j<=22;++j)
         {
             if(y[i][j]>='0'&&y[i][j]<='9')
               z[i][k]=z[i][k]*10+y[i][j]-48;
             if(y[i][j]=='.')
             {f++;j++;}
             if(y[i][j]==';')
             {g++;j++;}
             if(j>22)
                break;
            k++;
         }
         i++;
    }
    //for(i=1;i<=n;++i)
    //    fw<<z[i]<<endl;
    fw.close();
    fr.close();
    return 0;
}
