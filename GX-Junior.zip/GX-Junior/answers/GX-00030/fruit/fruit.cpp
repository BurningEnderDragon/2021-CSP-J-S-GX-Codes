#include<fstream>
#include<cstring>
using namespace std;
ofstream fw("fruit.out");
ifstream fr("fruit.in");
int main()
{
    int i,j,n,x[1000],y[1000];
    int a,b;
    fr>>n;
    fw<<n<<endl;
    for(i=1;i<=n;++i)
        fr>>x[i];
    for(i=1;i<=n;++i)
        fw<<x[i]<<" ";
    fw<<endl;
    y[1]=x[1];
    j=1;
    while(1)
        for(i=2;i<=n;++i)
           if(x[i-1]==x[i])
             y[j]=y[j]*10+x[i];
           else {j++;y[j]=x[i];}
    for(i=1;i<=n;++i)
        fw<<y[i]<<"  ";
    fw<<endl;
    fw.close();
    fr.close();
    return 0;
}
