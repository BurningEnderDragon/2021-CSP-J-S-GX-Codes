#include<fstream>
#include<cstring>
using namespace std;
ofstream fw("sort.out");
ifstream fr("sort.in");
int main()
{
    int n,q;
    fr>>n>>q;
    int a1,a2,a3;
    fr>>a1>>a2>>a3;
    fw.close();
    fr.close();
    return 0;
}
