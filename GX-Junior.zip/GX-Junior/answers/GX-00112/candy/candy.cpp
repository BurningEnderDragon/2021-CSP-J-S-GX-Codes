#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n,L,R,k,mx=-1;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d %d %d",&n,&L,&R);
	if(R-L>=n)
	{
	printf("%d",n-1);return 0;
	}
	else
	{
		for(int i=L;i<=R;i++)
		if(i%n>mx) mx=i%n;
		}
	printf("%d",mx);
	return 0;
}
