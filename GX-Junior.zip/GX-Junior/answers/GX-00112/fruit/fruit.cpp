#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int n,a[30001],sum;
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){scanf("%d",&a[i]);if(a[i]==0) a[i]=2;sum+=a[i];}
	while(sum>0)
	{
		int flag=-1;
		for(int i=1;i<=n;i++)
		{	if(a[i]==0) continue;
			if(flag!=a[i]){printf("%d ",i);flag=a[i];a[i]=0;}
		}
		sum=0;
		for(int i=1;i<=n;i++) sum+=a[i];
		printf("\n");
		}
	return 0;
}


