#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int n,q;//,a[10001],b[10001];
struct num{int ma,teshu;}a[10001],b[10001];
bool cmp(num x,num y)
{return x.ma>y.ma;}
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++)	{scanf("%d",&a[i].ma);b[i].ma=a[i].ma;}
	for(int i=1;i<=q;i++)
	{
		int mode;
		scanf("%d",&mode);
		if(mode==1)
		{	int k,v;scanf("%d%d",&k,&v);
			a[k].ma=b[k].ma=v;
		}
		else
		{
			int x;scanf("%d",&x);
			b[x].teshu=1;
			for (int k = 1; k <= n; k++)
			 for (int j=k;j>=2;j--)
				if (b[j].ma<b[j-1].ma){
					num t = b[j-1];
					b[j-1]=b[j];
					b[j] = t;
				}
			for(int j=1;j<=n;j++)  if(b[j].teshu==1){  printf("%d\n",j);b[j].teshu=0;break;}
			
		}
	}
	return 0;
}

