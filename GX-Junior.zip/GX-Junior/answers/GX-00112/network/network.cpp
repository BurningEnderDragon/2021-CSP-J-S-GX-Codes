#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<map>
using namespace std;
int n;
string op[1010],net[1010];
map<string,int>a;
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) 
	{	cin>>op[i]>>net[i];
		int l=net[i].size(),flag=0;
		int sumc=0,num=0,id;
		for(int j=0;j<l;j++)
			if(net[i][j]>='0'&&net[i][j]<='9')
			{
				if(net[i][j]=='0'&&net[i][j-1]=='.'&&net[i][j+1]>='0'&&net[i][j+1]<='9')  {printf("ERR\n");flag=1;break;}
				num=num*10+(net[i][j]-'0');
			}
			else
			{	sumc++;
				if(net[i][j]!='.'&&sumc<4){printf("ERR\n");flag=1;break;}
				
				if(num>255)
				{printf("ERR\n");flag=1;break;}
				num=0;
				if(sumc==4){id=j;break;}
			}
		num=0;
		if(flag==1) continue;
		if(net[i][id]!=':'){printf("ERR\n");continue;}
		for(int j=id+1;j<l;j++){
			if(net[i][j]=='0'&&num==0){printf("ERR\n");continue;}
			num=num*10+(net[i][j]-'0');
		}
		if(num>65535){printf("ERR\n");continue;}
		if(op[i]=="Server")
		{
			if(a[net[i]]>0) {printf("FAIL\n");continue;}
			a[net[i]]=i;printf("OK\n");
		}
		else
		{
				if(a[net[i]]>0) printf("%d\n",a[net[i]]);
				else printf("FAIL\n");
				
		}
	}
	return 0;
}

