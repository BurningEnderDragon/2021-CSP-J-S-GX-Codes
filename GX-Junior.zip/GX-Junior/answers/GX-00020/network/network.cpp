#include<iostream>
#include<string>
#include<cstdio>
using namespace std;
long long n,f,f1;
struct node
{
	string s;
}a[10000001];
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	cin>>n;
	for(int i=0;i<n;i++)
	{
		getline(cin,a[i].s);
	}
	for(int i=0;i<n;i++)
	{
	  	f=0;
	  	if(a[i].s[0]=='S')
	  	{
		  for(int w=0;w<n;w++)
		  {
			  if(a[i].s[w]=='.')
			  {
				  if(a[i].s[w-3]>'2'||a[i].s[w-3]=='2'&&a[i].s[w-2]>'5'||a[i].s[w]-3>'5'&&a[i].s[w-3]=='2'&&a[i].s[w-2]=='5')
				  {
					  cout<<"ERR";
					  f=1;
					  break;
				  }
			  }
			  if(a[i].s[w]==':')
			  {
				  if(a[i].s.size()-w>5) cout<<"ERR";
				  else if(a[i].s.size()-w==5||a[i].s[w+1]>6) cout<<"ERR";
			  }
		  }
		  if(f==0)
		  {
			  for(int j=0;j<i;j++)
			  {
			      if(a[j].s==a[i].s) cout<<"FAIL";
				  f1=1;
				  break;
			  }
			  if(f1==0)
			  {
			 	  cout<<"OK";
				  f1=0;
			  }
		  }
	    } 
	    f=0;
	    else
	    {
		  for(int w=0;w<n;w++)
		  {
			  if(a[i].s[w]=='.')
			  {
				  if(a[i].s[w-3]>'2'||a[i].s[w-3]=='2'&&a[i].s[w-2]>'5'||a[i].s[w]-3>'5'&&a[i].s[w-3]=='2'&&a[i].s[w-2]=='5')
				  {
					  cout<<"ERR";
					  f=1;
					  break;
				  }
			  }
			  if(a[i].s[w]==':')
			  {
				  if(a[i].s.size()-w>5a[i].s.size()-w==5||a[i].s[w+1]>6) 
				  {
				    cout<<"ERR";
				    f==1
				    break
				  }
			  }
		  }
		  if(f==0)
		  {
			  for(int j=0;j<n;j++)
			  {
				  if(a[j].s[17]==a[i].s[17])
				  cout<<a[i].s[17];
			  }
		  } 
	}
}
