#include<iostream>
#include<cstdio>
using namespace std;
long long n;
int f,f1;
struct node
{
	int i,t;
}a[20001];
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	cin>>n;
    for(int j=0;j<n;j++)
    {
		cin>>a[j].t;
		a[j].i=j+1;
	}
	f1=0;
	while(f1==0)
	{
		f1=1;
		f=2;
		for(int i=0;i<n;i++)
		{
			if(a[i].t==a[i+1].t)
			{
				if(a[i].t!=f)
				{
					cout<<a[i].i<<" ";
					for(int j=i;j<n-1;i++)
					{
						a[i].t=a[i+1].t;
						a[i].i=a[i+1].i;
					}
					n--;
					for(int j=0;j<n;j++)
					{
						cout<<a[i].t<<" ";
					}
					i--;
					f1=0;
				}
			}
			else f=2;
		}
		cout<<endl;
	}
	return 0;
}
