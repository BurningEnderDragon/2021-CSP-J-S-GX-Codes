#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
long long w,b,c,d,e,n,q,m[100001];
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	cin>>n>>q;
	for(int i=1;i<=n;i++)
	{
		cin>>m[i];
	}
	for(int i=1;i<=q;i++)
	{
		cin>>w;
		if(w==1)
		{
			cin>>b>>c;
			for(int j=1;j<=n;j++)
			{
				if(m[j]==c) d=j; 
			}
			if(b>d)
			{
				for(int j=d;j<=b;j++)
				{
					m[j]=m[j+1];
				}
			}
			else
			{
				for(int j=d;j>=b;j++)
				{
					m[j]=m[j-1];
				}
			}
			m[b]=c;
		}
		else
		{
			cin>>b;
			cout<<m[b]<<endl;
		}
	}
	return 0;
}
