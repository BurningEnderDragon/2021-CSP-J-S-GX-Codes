#include<iostream>
#include<cstdio>
using namespace std;
long long n,l,r,s,a,b;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>n>>r>>l;
	a=l/n;
	b=r/n;
	if(a-b>=2) cout<<n-1;
	else if(a-b==1) cout<<a*n-b*n-1;
	else if(a==b) cout<<l-a*n;
	return 0;
}
