#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int a[8001],z[8001];
int n,q;
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	cin>>n>>q;
	  for(int i=1;i<=n;i++)
	  {
	   int d;
	   scanf("%d",&d);
	   a[i]=d; 
	   z[i]=d;
	  }	
     for (int i = 1; i <= n; i++)
          for (int j =i+1; j<=n; j++)
            if(a[j]<a[j-1])
            {
			  int t=a[j-1];
			  a[j-1]=a[j];
			  a[j]=t;	
			}
     for(int i=1;i<=q;i++)
     {
	  int s,v,g;
	  scanf("%d",&s);
	  if(s==1)
	  {
		scanf("%d",&v,&g);
		z[a[v]]=g;
		a[v]=g;
		for (int i = 1; i <= n; i++)
          for (int j =i+1; j<=n; j++)
            if(a[j]<a[j-1])
            {
			  int t=a[j-1];
			  a[j-1]=a[j];
			  a[j]=t;	
			}
	  }	
	  else
	  {
		scanf("%d",&v);  
		for(int i=1;i<=n;i++)
		if(a[i]==z[v]) cout<<i<<endl;
	  }
	 } 
    return 0;	
}

