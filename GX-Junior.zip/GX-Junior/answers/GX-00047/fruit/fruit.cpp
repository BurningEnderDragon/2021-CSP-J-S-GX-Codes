#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n,s;
int a[50001];
int b[25001];
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	 cin>>n;
	  for(int i=1;i<=n;i++)
	  {
	   int m;
	   scanf("%d",&m);
	   a[i]=m;
	   }	
	   for(int i=1;i<=n;i++)
	  {
	   if(a[i]!=a[i-1]) {cout<<i<<" ";s++;}
	  }
	while(1)
	{
		 if(s==n) break;
		 cout<<endl;
		 for(int i=1;i<=n;i++)
	  {
	   if(a[i]!=a[i-1]) b[i]=a[i];
	  }
	   	for(int i=1;i<=n;i++)
	  {
	   a[i]=0;
	  }
	  n=s;
	  s=0;
	   for(int i=1;i<=n;i++)
	  {
	   if(b[i]!=b[i-1]) {cout<<i<<" ";s++;}
	  }
	  
	  if(s==n) break;
		 cout<<endl;
		 for(int i=1;i<=n;i++)
	  {
	   if(b[i]!=b[i-1]) a[i]=b[i];
	  }
	   	for(int i=1;i<=n;i++)
	  {
	   b[i]=0;
	  }
	  n=s;
	  s=0;
	   for(int i=1;i<=n;i++)
	  {
	   if(a[i]!=a[i-1]) {cout<<i<<" ";s++;}
	  }
	}
    return 0;	
}
