#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
using namespace std;
int n,l,r,u;
string ox[1001];
string ok[1001];
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
     string s1,s2;
     cin>>s1;
     cin>>s2;
     int len=s2.size();
     if(s1=="Server")
     {
		int w,e;
	   for(int i=0;i<=len-1;i++)
	   {
		 if(s2[i]==".") w++;
		 if(s2[i]==":") e++;
	   }
	   if(w!=3||e!=1) {cout<<"ERR";continue}
	   for(int i=0;i<=1001;i++;)
	   {
	    if(s2==ox[i]) {cout<<"FAIL"<<endl;break;}
	    if(ok[i]=0) break;
	   }
	   else {cout<<"OK"<<endl;ok[u]=s2;u++;}
	 }
     else
     {
	   for(int i=0;i<=1001;i++;)
	   {
	    if(s2==ok[i]) {cout<<i<<endl;break;}
	    if(ok[i]=0) break;
	   }
	  int w,e;
	   for(int i=0;i<=len-1;i++)
	   {
		 if(s2[i]==".") w++;
		 if(s2[i]==":") e++;
	   }
	   if(w!=3||e!=1) {cout<<"ERR";continue}
	   else cout<<"FAIL";
	 }
    }
    return 0;	
}
