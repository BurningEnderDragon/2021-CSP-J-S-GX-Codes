#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n,l,r,el,t,k;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>n>>l>>r;
	  for(int i=n;i>=n;i+=n)
	  {
	   if(i>l) {el=i-n;break;}
	   if(i==l) {el=i;break;}
	   }	
	 el=el+n-1;
	 k=r-el;
	 if(el<=r&&el>=l) t=t+n-1;
	 else {el=r;t=t+el%n;}
	cout<<t;
    return 0;	
}
