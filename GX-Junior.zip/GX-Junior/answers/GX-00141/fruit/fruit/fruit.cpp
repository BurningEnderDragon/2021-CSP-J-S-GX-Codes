#include <iostream>
using namespace std;
int n, a[10];
int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    for (int i = 1; i <= n; i++)
    {
        if (a[i]==1)
        {
            if(a[i-1]=0)
            cout << i;
            a[i]=0;
        }
    }
    return 0;
}