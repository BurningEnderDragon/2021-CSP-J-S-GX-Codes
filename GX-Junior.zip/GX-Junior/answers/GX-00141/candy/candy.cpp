#include <iostream>
#include <algorithm>
using namespace std;
int n, r, l, a[1000000001], b[1000000001], c;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    cin >> n >> l >> r;
    for (int i = l; i <= r; i++)
    {
        a[i] = i;
        while (a[i] >= n)
        {
            a[i] -= n;
        }
        b[i] = a[i];
    }
    for (int i = l; i <= r; i++)
    {
        if (c < b[i + 1])
        {
            c = b[i + 1];
        }
    }
    cout << c << '\n';
    fclose(stdin);
    fclose(stdout);
    return 0;
}