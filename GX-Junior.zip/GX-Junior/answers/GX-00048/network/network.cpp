#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<string>
using namespace std;
int n;
struct dt
{
		string op,id;
		string x[6];
		int y[6],z;
}a[1010];
int main()
{
		freopen("network.in","r",stdin);
		freopen("network.out","w",stdout);
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			int flag;
			cin>>a[i].op>>a[i].id;
			a[i].id+='.';
			int len=a[i].id.size();
			for(int j=0;j<len;j++)
			{
				int s=0,t=1;
				if(a[i].id[j]!='.' || a[i].id[j]!=':')
				{
					a[i].x[t]+=a[i].id[j];
					s=s*10+(a[i].id[j]-'0');
				}
				else
				{
					if(a[i].id[j]==':'&&t==4) flag=1;
					a[i].y[t]=s;
					s=0;
					t++;
				}
			}
			if((a[i].x[1][0]=='0'&&a[i].x[1].size()==1) || (a[i].x[2][0]=='0'&&a[i].x[2].size()==1) || (a[i].x[3][0]=='0'&&a[i].x[3].size()==1) ||(a[i].x[4][0]=='0'&&a[i].x[4].size()==1) || (a[i].x[5][0]=='0'&&a[i].x[5].size()==1) || a[i].y[1]<0||a[i].y[1]>255 ||a[i].y[2]<0||a[i].y[2]>255 || a[i].y[3]<0||a[i].y[3]>255 ||a[i].y[4]<0||a[i].y[4]>255||a[i].y[5]<0||a[i].y[5]>65535)
			{
				cout<<"ERR"<<endl;
				continue;
			}
			else
			{
				if(a[i].op=="Server")
				{
					int t=1;
					if(i!=1)
						for(int j=1;j<=i-1;j++)
							if(a[i].id==a[j].id && a[i].op=="Server" && a[i].op=="Server")
							{
								cout<<"FAIL"<<endl;
								break;
							}
							else 
							{
								a[i].z=t;
								t++;
								cout<<"OK"<<endl;
								break;
							}
					else 
					{
						cout<<"OK"<<endl;
						a[i].z=t;
						t++;
					}
				}
				else
				{
					for(int j=1;j<=i;j++)
						if(a[i].id==a[j].id&&a[j].op=="Server" && a[j].z!=0)
						{
							cout<<a[j].z<<endl;
							break;
						}
						else 
						{
							cout<<"FAIL"<<endl;
							break;
						}
				}
			}
		}
		return 0;
}

