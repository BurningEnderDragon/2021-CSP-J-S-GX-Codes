#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int n,l,r;
int ans;
int main()
{
		freopen("candy.in","r",stdin);
		freopen("candy.out","w",stdout);
		scanf("%d%d%d",&n,&l,&r);
		for(int i=l;i<=r;i++)
			ans=max(ans,i%n);
		cout<<ans;
		return 0;
}
