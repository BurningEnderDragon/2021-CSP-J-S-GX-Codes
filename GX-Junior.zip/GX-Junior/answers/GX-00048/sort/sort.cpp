#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int n,q;
int a[10010],b[10010];
int main()
{
		freopen("sort.in","r",stdin);
		freopen("sort.out","w",stdout);
		scanf("%d%d",&n,&q);
		for(int i=1;i<=n;i++)
			scanf("%d",&b[i]);
		for(int i=1;i<=q;i++)
		{
				int x,y,z;
				cin>>x;
				for(int j=1;j<=n;j++)
						a[j]=b[j];
				if(x==2)
				{
						cin>>y;
						z=a[y];
						for(int j=1;j<=n;j++)
							for(int k=j;k>=2;k--)
								if(a[k]<a[k-1])
								{
										int t=a[k-1];
										a[k-1]=a[k];
										a[k]=t;
								}
						for(int j=1;j<=n;j++)
							if(a[j]==z)
								cout<<j<<endl;
						
				}
			    else
				{
						cin>>y>>z;
						a[y]=z;
				}
		}
		return 0;
}

