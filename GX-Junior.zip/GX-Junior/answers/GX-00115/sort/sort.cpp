#include<iostream>
#include<cstdio>
using namespace std;
int n,q;
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	scnaf("%d",&m);
	for(int i=1;i<=m;i++)
	sort(ans+
	return 0;
}
