#include<iostream>
#include<cstdio>
using namespace std;
int n,l,r,ans=0;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d %d %d",&n,&l,&r);
	while(1)
	for(int i=1;i<=n;i++)
	
	return 0;
}
