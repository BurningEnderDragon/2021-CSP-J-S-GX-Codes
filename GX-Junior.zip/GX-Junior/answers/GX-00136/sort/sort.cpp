#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int n,c;
    int x,u;
    cin>>n>>c;
    int a[100001];
    int b[100001];
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
        b[i]=a[i];
    }
    for(int i=1;i<=c;i++)
    {
        int wz=0;
        int f;
        cin>>f;
        if(f==1)
        {
            cin>>x>>u;
            a[x]=u;
        }
        else
        {
            cin>>x;
            int p=0;
            int r=a[x];
            cout<<a[x];
            for(int i=1;i<=n;i++)
            {
                b[i]=a[i];
                if(a[x]==a[i]) p++;
                if(x==i) break;
            }
            for(int i=1;i<n;i++)
            {
                for(int o=i+1;o<=n;o++)
                {
                    if(b[i]>b[o])
                    {
                        int h=b[o];
                        b[o]=b[i];
                        b[i]=h;
                    }
                }
            }
            int j=0;
            for(int y=1;y<=n;y++)
            {
                if(r==b[y])
                {
                    j++;
                    if(j==p)
                    {
                        cout<<y<<endl;
                        break;
                    }
                }
            }
        }
    }
    return 0;
}
