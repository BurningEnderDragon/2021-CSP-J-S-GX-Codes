#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,l,r;
    cin>>n>>l>>r;
    if(n==r)
    {
        cout<<"0";
        return 0;
    }
    int s=0;
    int max=0;
    int wz=0;
    for(int i=r;i>=l;i--)
    {
        s=i%n;
        if(s>max)
        {
            max=s;
            wz=i;
        }
    }
    cout<<wz%n;
    return 0;
}
