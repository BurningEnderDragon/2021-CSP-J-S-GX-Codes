#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int n;
    cin>>n;
    string worker[10001],toer[10001];
    for(int i=1;i<=n;i++)
    {
        string name;
        cin>>name;
        if(name=='Server')
        {
            cin>>worker[i];
            for(int o=0;o<work[i].size();o++)
            {

            }
        }
        else
        {
            cin>>toer[i];
        }
    }
    return 0;
}
