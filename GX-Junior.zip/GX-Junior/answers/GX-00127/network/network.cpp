#include<cstdio>
#include<iostream>
using namespace std;
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);


	fclose(stdin);
	fclose(stdout);
	return 0;
}
