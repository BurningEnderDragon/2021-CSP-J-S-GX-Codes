#include<cstdio>
#include<iostream>
using namespace std;
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);


	fclose(stdin);
	fclose(stdout);
	return 0;
}
