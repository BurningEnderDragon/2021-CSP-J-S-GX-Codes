#include<cstdio>
#include<iostream>
using namespace std;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);

	int r,n,l,sum[100],o=0,a;
	cin>>n>>l>>r;
	for(int i=l;i<=r;i++)
	{
		sum[o]=i%n;
		o++;
		if(sum[o]>sum[o+1])
		{
			a=sum[i];
		}
		else
			break;
	}
	printf("%d",a);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
