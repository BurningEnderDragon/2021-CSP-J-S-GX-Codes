#include<cstdio>
#include<iostream>
using namespace std;
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);


	fclose(stdin);
	fclose(stdout);
	return 0;
}
