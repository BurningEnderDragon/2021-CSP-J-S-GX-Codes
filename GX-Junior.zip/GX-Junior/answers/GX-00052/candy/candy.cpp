#include<bits/stdc++.h>
#include<cstdio>
using namespace std;
int main()
{
    freopen("candy3.in","r",stdin);
    freopen("candy.out","w",stdout);
    long long l,r,n,i,max1=0;
    scanf("%lld %lld %lld",&n,&l,&r);
    for(i=l;i<=r;i++)
        max1=max(i%n,max1);
    printf("%d",max1);
    return 0;
}
