#include<bits/stdc++.h>
using namespace std;
struct sort1
{
    long long  before,after;
}a[10000];
void print(sort1 a[],int n)
{

    for(int i=1;i<=n;i++)
        cout<<a[i].before<<' '<<a[i].after<<endl;
}
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    long long n,q,i,k,j=1,t,x,i1,sum=1,y,z;
    scanf("%lld %lld",&n,&q);
    for(i=1;i<=n;i++)
    {
        scanf("%lld",&a[i].before);
        a[i].after=a[i].before;
    }
    //cout<<n<<' '<<q;
    for(i=0;i<q;i++)
    {
        cin>>k;
        if(k==1)
        {
            scanf("%lld %lld",&y,&z);
            a[x].after=z;
        }
        if(sum<n)
            for(j=sum;j>=2;j--)
                if(a[j].after<a[j-1].after )
                {
                    swap(a[j].after,a[j-1].after);
                    swap(a[j].before,a[j-1].before);
                }
        sum++;
        if(k==2)
        {
            scanf("%lld",&x);
            for(i1=1;i1<=n;i1++)
            {
                if(a[i1].before==x)
                {
                    printf("%lld\n",i1);
                    break;
                }
            }
        }
        //print(a,n);
    }

    return 0;
}
