#include<bits/stdc++.h>
using namespace std;
struct Server
{
    int a,b,c,d,e;
}a[10000];
struct Client
{
    int a,b,c,d,e;
}b[10000];
int find1(int a1,int b1,int c1,int d1,int e1,int s)
{
    for(int i=0;i<s;i++)
        if (a[i].a==a1&&a[i].b==b1&&a[i].c==c1&&a[i].d==d1&&a[i].e==e1)
            return 1;
        return 0;
}
int find2(int a1,int b1,int c1,int d1,int e1,int s)
{
    for(int i=0;i<s;i++)
        if(a[i].a==a1&&a[i].b==b1&&a[i].c==c1&&a[i].d==d1&&a[i].e==e1)
            return i+1;
        return 0;
}
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    string s;
    int n,i,sum1=0;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        cin>>s;
        if(s=="Server")
        {
            scanf("%d.%d.%d.%d:%d",&a[sum1].a,&a[sum1].b,&a[sum1].c,&a[sum1].d,&a[sum1].e);
            if(a[sum1].a<0||a[sum1].a>255||a[sum1].b<0||a[sum1].b>255||a[sum1].c<0||a[sum1].c>255||a[sum1].d<0||a[sum1].d>255||a[sum1].e<0||a[sum1].e>65535)
                printf("ERR\n");
            else if(find1(a[sum1].a,a[sum1].b,a[sum1].c,a[sum1].d,a[sum1].e,sum1))
                printf("FAIL\n");
            else
                printf("OK\n");
            sum1++;
        }
        else if(s=="Client")
        {
            scanf("%d.%d.%d.%d:%d",&b[sum1].a,&b[sum1].b,&b[sum1].c,&b[sum1].d,&b[sum1].e);
            if(b[sum1].a<0||b[sum1].a>255||b[sum1].b<0||b[sum1].b>255||b[sum1].c<0||b[sum1].c>255||b[sum1].d<0||b[sum1].d>255||b[sum1].e<0||b[sum1].e>65535)
                printf("ERR\n");
            else
            {
                int A=find2(b[sum1].a,b[sum1].b,b[sum1].c,b[sum1].d,b[sum1].e,sum1);
                if(A==0)
                    printf("FAIL\n");
                else
                    printf("%d\n",A);
                sum1++;
            }
        }
    }
    return 0;
}
