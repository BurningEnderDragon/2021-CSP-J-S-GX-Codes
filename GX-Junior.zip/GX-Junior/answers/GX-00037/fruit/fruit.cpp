#include <cstdio>
#include <vector>
#include <algorithm>

using std::vector;
using std::sort;

const int BEG=0;
const int END=200005;

int n,a[200005];

int fruitCnt=0;
struct Fruit
{
	int kind,from,next;
	bool isHead=0,isTail=0;
	int head,tail;
	int fromKind,nextKind;
	bool vis=0;
}f[200005];

int basketCnt=0;
vector<int> basket[200005];

void Init()
{
	f[BEG].from=BEG;
	f[BEG].next=END;
	f[BEG].isHead=1;
	f[BEG].head=BEG;
	f[BEG].isTail=1;
	f[BEG].tail=BEG;
	f[BEG].nextKind=1;
	f[END].from=BEG;
	f[END].next=END;
	f[END].isHead=1;
	f[END].head=END;
	f[END].isTail=1;
	f[END].tail=END;
	return;
}

int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	Init();
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=n;++i)
	{
		f[i].kind=a[i];
		f[i].from=i-1;
		f[i].next=i+1;
		if(i==1 || a[i]!=a[i-1])
		{
			f[i].isHead=1;
		}
		else if(i==n || a[i]!=a[i+1])
		{
			f[i].isTail=1;
		}
		if(i==1)
		{
			f[i].from=BEG;
			f[i].head=1;
			f[i].fromKind=BEG;
		}
		else if(i==n)
		{
			f[i].next=END;
			f[i].head=(f[i].isHead ? i : f[i-1].head);
			f[f[i].head].nextKind=END;
		}
		else
		{
			if(a[i]!=a[i-1])  //head
			{
				f[i].from=BEG;
				f[i].head=i;
				f[i].fromKind=f[i-1].head;
			}
			if(a[i]!=a[i+1])  //tail
			{
				f[i].next=END;
				f[i].head=(f[i].isHead ? i :f[i-1].head);
				f[i].tail=i;
				f[f[i].head].tail=i;
				f[f[i].head].nextKind=i+1;
			}
			if(a[i]==a[i-1] && a[i]==a[i+1])  //middle
			{
				f[i].head=f[i-1].head;
			}
		}
	}
	// for(int i=1;i<=n;++i)
	// {
	// 	printf("id:%d\n",i);
	// 	printf("  isHead=%d,head=%d\n",f[i].isHead,f[i].head);
	// 	printf("  from=%d,next=%d\n",f[i].from,f[i].next);
	// 	printf("  fromKind=%d,nextKind=%d\n",f[i].fromKind,f[i].nextKind);
	// }
	while(fruitCnt<n)
	// for(int i=1;i<=2;++i)
	{
		// printf("new beginning!\n");
		int last=BEG,now=f[BEG].nextKind;
		if(now==END)
		{
			break;
		}
		++basketCnt;
		while(now!=END && now!=BEG)
		{
			// printf("now=%d\n",now);
			if((last==BEG || f[now].kind!=f[last].kind) && (!f[now].vis))
			{
				if(f[now].next==END)
				{
					f[f[now].fromKind].nextKind=f[now].nextKind;
					f[f[now].nextKind].fromKind=f[now].fromKind;
					++fruitCnt;
					basket[basketCnt].push_back(now);
					f[now].vis=1;
					last=now;
					now=f[now].nextKind;
					// printf("goto %d\n",now);
				}
				else
				{
					f[now+1].isHead=1;
					f[now+1].from=BEG;
					f[now+1].tail=f[now].tail;
					f[now+1].fromKind=f[now].fromKind;
					f[now+1].nextKind=f[now].nextKind;
					f[f[now].fromKind].nextKind=now+1;
					f[f[now].nextKind].fromKind=now+1;
					// printf("f[%d].nextKind=%d\n",f[now].fromKind,now+1);
					// printf("f[%d].fromKind=%d\n",f[now].nextKind,now+1);
					++fruitCnt;
					basket[basketCnt].push_back(now);
					f[now].vis=1;
					last=now;
					now=f[now].nextKind;
					// printf("goto %d\n",now);
				}
			}
			else
			{
				f[now].isHead=0;
				f[now].head=f[f[now].fromKind].head;
				f[f[f[f[now].fromKind].head].tail].next=now;
				f[now].from=f[f[f[now].fromKind].head].tail;
				f[now].fromKind=0;
				now=f[now].nextKind;
				// printf("skip ! goto %d\n",now);
			}
		}
	}
	for(int i=1;i<=basketCnt;++i)
	{
		sort(basket[i].begin(),basket[i].end());
		for(int j=0;j<=basket[i].size()-1;++j)
		{
			printf("%d%c",basket[i][j]," \n"[j==basket[i].size()-1]);
		}
	}
	return 0;
}

/*compile
g++ fruit.cpp -O2 -lm -w -o fruit.exe
*/