#include <cstdio>

long long n,L,R;

int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%lld%lld%lld",&n,&L,&R);
	if((R-L)>=((n-1)-(L%n)))
	{
		printf("%lld\n",n-1);
	}
	else
	{
		printf("%lld\n",R%n);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}