#include <cstdio>

int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	puts("AK!");
	return 0;
}