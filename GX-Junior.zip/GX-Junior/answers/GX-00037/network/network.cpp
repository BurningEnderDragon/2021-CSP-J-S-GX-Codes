#include <iostream>
#include <cstdio>
#include <string>
#include <map>

using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::map;

int n;
string op,ad,s[30];
map<string,bool> visited;
map<string,int> id;

bool Check(const string &str)  //OK return true, ERR return flase;
{
	return  ( !((str.length()==0) || (str.length()!=1 && str[0]=='0')) );
}

bool Compare(const string &a,const string &b)  //a>b return true, a<=b return flase
{
	if(a.length()!=b.length())
	{
		return a.length()>b.length();
	}
	else
	{
		for(int i=0;i<=a.length()-1;++i)
		{
			if(a[i]>b[i])
			{
				return true;
			}
			else if(a[i]<b[i])
			{
				return false;
			}
		}
		return false;
	}
}

bool Process()
{
	for(int i=0;i<=4;++i)
	{
		s[i]="";
	}
	int cnt=0,dotCnt=0,ddotCnt=0;
	for(int i=0;i<=ad.length()-1;++i)
	{
		if(ad[i]=='.')
		{
			++dotCnt;
			++cnt;
		}
		else if(ad[i]==':')
		{
			if(dotCnt!=3)
			{
				return false;
			}
			++ddotCnt;
			++cnt;
		}
		else
		{
			s[cnt]+=ad[i];
		}
	}
	if((dotCnt!=3) || (ddotCnt!=1))
	{
		return false;
	}
	else
	{
		return true;
	}
}

int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;++i)
	{
		cin>>op>>ad;
		if(Process())  //a well-format string
		{
			for(int j=0;j<=4;++j)
			{
				if(!Check(s[j]))  //number with leading zero of empty
				{
					cout<<"ERR"<<endl;
					goto Next;
				}
				else if((j<=3 && Compare(s[j],"255")) || (j==4 && Compare(s[j],"65535")))  //number is too large
				{
					cout<<"ERR"<<endl;
					goto Next;
				}
			}
			if(op=="Server")  //Server
			{
				if(!visited[ad])
				{
					visited[ad]=1;
					id[ad]=i;
					cout<<"OK"<<endl;
				}
				else
				{
					cout<<"FAIL"<<endl;
				}
			}
			else
			{
				if(visited[ad])  //Client
				{
					cout<<id[ad]<<endl;
				}
				else
				{
					cout<<"FAIL"<<endl;
				}
			}
			Next:;
		}
		else  //a bad-format string
		{
			cout<<"ERR"<<endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

/*compile
g++ network.cpp -O2 -lm -o network.exe
*/