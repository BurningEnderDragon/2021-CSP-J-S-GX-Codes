#include<bits/stdc++.h>
using namespace std;
int main()
 {
    int n,L,R,k;
    cin>>n>>L>>R;
    L>=n&L<=R;
    k=L;





}
