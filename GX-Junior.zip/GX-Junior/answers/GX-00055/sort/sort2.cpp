#include<iostream>
#include<stdio>
#include<string>
#include<sstream>
#include<cmath>
using namespace std;
int main()
{
    freopen("sort.in","r"stdin);
    freopen("sort.out","w"stdout);
    for i:=1 to n do
        for j:=i downto 2 do
            if a[j]<a[j‐1] then
                begin

                t:=a[i];
                a[i]:=a[j];
                a[j]:=t;
            end;
    return 0;    
}

