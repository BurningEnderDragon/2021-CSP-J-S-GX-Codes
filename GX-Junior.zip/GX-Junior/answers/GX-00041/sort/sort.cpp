#include<bits/stdc++.h>
using namespace std;
long long n,m,v[8000+50],v2[8000+50],o,x,p,ans;
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    cin>>n>>m;
    for(int i=1;i<=n;++i)
        cin>>v[i];
    for(int i=1;i<=m;++i){
        cin>>o;
        if(o==1){
            cin>>x>>p;
            v[x]=p;
        }
        else
        {
            cin>>x;
            for(int i=1;i<=n;++i)
                v2[i]=v[i];
            for(int i=1;i<= n;i++)
				for(int j=i;j>=2;--j)
				if(v2[j]<v2[j-1]){
					if(j==x){
						ans=j-1;
						x=j-1;
					}
					else if(j-1==x){
						ans=j;
						x=j;
					}
					int t=v2[j-1];
					v2[j-1]=v2[j];
					v2[j]=t;
				}
			cout<<ans<<endl;
		}
	}
	return 0;
}
