#include<bits/stdc++.h>
using namespace std;
int n,v[200000+20],cnt,m,f[200000+20],p;
int main()
{
	freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;++i)
        scanf("%d",&v[i]);
    m=n-1;
    cout<<1<<" ";

       while(m>1){
            for(int i=2;i<=n;++i){
				if(v[i]!=v[i-1]&&v[i]!=-1&&v[i-1]!=-1){
					printf("%d ",i);
					printf("\n with v[%d]:  %d\n",i,v[i]);
					f[p]=i;
					++p;
				}
				--m;
			}
			for(int i=0;i<p;++i)v[f[p]]=-1;
			cout<<endl;
        }
    return 0;
}
