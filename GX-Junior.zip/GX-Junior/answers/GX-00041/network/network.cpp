#include<bits/stdc++.h>
using namespace std;
int n,v[1000+20];
string str[1000+20],str2;
int check(string str);
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    cin>>n;
	for(int i=1;i<=n;++i)
	{
		cin>>str2;
		if(str2=="Server")v[i]=1;
		else v[i]=0;
		cin>>str[i];	
	}
	for(int i=1;i<=n;++i)
	{
		int s=check(str[i]);
		if(s==1)
			if(v[i]){
				bool fl=0;
				for(int j=1;j<=n;++j)
					if(v[j]&&str[j]==str[i]&&j!=i&&j<i){
						cout<<"FAIL"<<endl;
						fl=1;
						break;
					}
				if(!fl)cout<<"OK"<<endl;		
			}
			else{
				bool flag=false;
				for(int j=1;j<i;++j)
					if(v[j]&&str[j]==str[i])
					{
						cout<<j<<endl;
						flag=true;
						break;
					}
				if(!flag)cout<<"FAIL"<<endl;
			}
		else cout<<"ERR"<<endl;
	}
    return 0;
}
int check(string str)
{
	int length=str.size();
	int f=0,t=0;
	if(length>25||length<9)
		return 2;
	for(int i=0;i<length;++i)//find 0
		if((str[i]=='0'&&(!i||(str[i-1]=='.'||str[i-1]==':')))&&str[i+1]!='.'&&str[i+1]!=':'&&i!=length-1)return 3;
	for(int i=0;i<length;++i)//find . and :
	{
		if(str[i]=='.')++f;
		if(str[i]==':')++t;
	}	
	if(f!=3||!t)return 4;
	int cnt,cnt2;
	for(int i=length-1;str[i]!=':';--i)//counting number 
		++cnt2;
	for(int i=0;i<length-cnt2-1;i+=cnt+1)
	{
		cnt=0;
		for(int j=i;str[j]!='.'&&str[j]!=':';++j)++cnt;
		if(!cnt||cnt>3)return 5;
		if(cnt==3)
			if(str[i]>='2'){
				if(str[i]>'2'){
					return 7;
				}
				else if(str[i+1]>='5'){
					if(str[i+1]>'5')return 8;
					else if(str[i+2]>='5'){
						if(str[i+2]>'5')return 9;
					}
				}
			}
	}
	int nm=0;
	for(int i=length-cnt2;i<length;++i)//:56789 20
	{
		nm*=10;
		nm+=str[i]-48;
	}
	if(nm>65535)return 6;
	return 1;
}
