#include<bits/stdc++.h>
using namespace std;
int a[1000],n,L,R,k,j;
int main(){
freopen("candy.in","r",stdin);
freopen("candy.out","w",stdout);
cin>>j;
cout<< j <<;




return 0;
}



