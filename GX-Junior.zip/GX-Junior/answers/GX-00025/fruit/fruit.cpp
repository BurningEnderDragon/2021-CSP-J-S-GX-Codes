#include<bits/stdc++.h>
using namespace std;
int a[1000],n,k;
int main(){
freopen("fruit.in","r",stdin);
freopen("fruit.out","w",stdout);






return 0;
}



