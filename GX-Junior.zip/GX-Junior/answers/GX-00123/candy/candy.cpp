#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int n,m,a,ans,sum=-1;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d %d %d",&a,&m,&n);
	  for(int i=m;i<=n;i++)
	{
		ans=i%a;
		sum=max(ans,sum);
    }
    cout<<sum;
	return 0;
}
