#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int n,m,x,v,ans,y,sum=0;
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d %d",&m,&n);
	int a[8010],b[8010];
	for(int i=1;i<=m;i++)
	{scanf("%d",&a[i]);b[i]=a[i];}
	  for(int k=1;k<=n;k++)
	  {
	   cin>>y;
	   sum=0;
	   if(y==2)
	   {
	   scanf("%d",&x);
	   for(int i=1;i<=m;i++)
	      b[i]=a[i];
	     for(int i=1;i<=x;i++)
	     {
			 if(a[x]==a[i]) sum++;
		 }
		 sum--;
	   ans=a[x];
	   
	      for(int i=1;i<=m;i++)
	     {
	     for(int j=i;j>=2;j--)
	     {
		   if(b[j]<b[j-1])
		   {
			   int t=b[j-1];
			   b[j-1]=b[j];
			   b[j]=t;
		   }
	     }
         }
         
          for(int i=1;i<=m;i++)
        {
			if(ans==b[i]&&sum!=0) {sum--;continue;}
			if(ans==b[i]&&sum==0) {cout<<i<<endl;break;}
		}
       }
      sum=0;
      if(y==1)
      {
		  
		  scanf("%d %d",&x,&v);
		  a[x]=v;
		   for(int i=1;i<=m;i++)
	      b[i]=a[i];
	  }
	  sum=0;
     }
	return 0;
}
