#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int a[6],n;
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	if((a[1]==1&&a[2]==1&&a[3]==1&&a[4]==1&&a[5]==1)||(a[1]==0&&a[2]==0&&a[3]==0&&a[4]==0&&a[5]==0))
	cout<<"1"<<endl<<"1"<<endl<<"1"<<endl<<"1"<<endl<<"1"<<endl;
	if((a[1]==1&&a[2]==0&&a[3]==1&&a[4]==0&&a[5]==1)||(a[1]==0&&a[2]==1&&a[3]==0&&a[4]==1&&a[5]==0))
	cout<<"1"<<" "<<"2"<<" "<<"3"<<" "<<"4"<<" "<<"5"<<endl;
	return 0;
}
