#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int n,m,a,ans,sum=-1;
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	
	return 0;
}

