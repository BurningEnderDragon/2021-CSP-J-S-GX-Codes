#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    long int a,v,n;
    cin>>a>>v>>n;
    if (n<=1)
    {
        int x;
       for(x<=n;x<=1;++x)
       {
           cout<<a[x];
       }
    }
    return 0;
}
