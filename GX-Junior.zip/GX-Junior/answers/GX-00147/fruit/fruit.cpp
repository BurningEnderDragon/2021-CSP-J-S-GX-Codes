#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    int n,a,b;
    cin>>n>>a>>b;
    int cut1,cut2;

    for(a>=1;a!=b;++cut1)
    {
        cout<<cut1<<endl;
    }
    for(b>=1;b!=a;++cut2)
    {
        cout<<cut2;
    }
    if(n=a+b)
    {
        cout<<n-a;
        cout<<n-b;
    }
    return 0;
}
