#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    char x,y;
    if(x=y)
    {
        cout<<"ERR";
    }
    else
    {
        cout<<"ok";
    }
    return 0;
}
