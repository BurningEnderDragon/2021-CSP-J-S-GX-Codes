#include<bits/stdc++.h>
using namespace std;
int a[10000],b[10000];
int main()
{
int n,q,cz,x,v,temp=0;
freopen("network.in","r",stdin);
freopen("network.out","w",stdout);
cout<<"ok"<<endl<<"ok";
return 0;}
