#include<bits/stdc++.h>
using namespace std;
int a[1000000],b[1000000];
int main()
{
int n,q,cz,x,v,temp=0;
freopen("sort.in","r",stdin);
freopen("sort.out","w",stdout);
cin>>n>>q;
for(int i=1;i<=n;i++)
	cin>>a[i];
	
	
for(int i=1;i<=q;i++)
{
	for(int i=1;i<=n;i++)//chushihua
	b[i]=a[i];

	cin>>cz;
	if(cz==1)
	{
		cin>>x>>v;
		a[x]=v;
	}
	
	
	
	else //qwewqeq
	{
		cin>>x;
		temp=x;
for (int u = 1; u <= n; u++){  
for(int j=u;j>=2;j--)
if(b[j]<b[j-1])
{
if(j==temp)//1
{
int p=b[j-1];
b[j-1]=b[j];
b[j] = p;
temp=j-1;
	}	
	
	
	
	if(j-1==temp)//2
{
int p=b[j-1];
b[j-1]=b[j];
b[j] = p;
temp=j;
	}	
	
	
else{
int p=b[j-1];
b[j-1]=b[j];
b[j] = p;
	}

}
		

	cout<<temp<<" ";}//chulishuchu
	
	
	return 0;}
	
	
	
	
	
	
	
	
	}}
