#include<bits/stdc++.h>
using namespace std;
long a[100000000]={0};
int main()
{
	int n,l,r,big=0;
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>n>>l>>r;
	

  for(int i=l;i<=r;i++)
  {
	  a[i]=i;
	  for(int k=1;k<=100000;k++)//
    {
	
	if(a[i]>=n)
	{
		a[i]=a[i]-n;
		}
		else break;
	
	}//
	
	  }
	  big=a[l];
for(int i=l+1;i<=r;i++)
{
	if(a[i]>=big)
	big=a[i];
	}	  
cout<<big;	  
return 0;	}
	
	

