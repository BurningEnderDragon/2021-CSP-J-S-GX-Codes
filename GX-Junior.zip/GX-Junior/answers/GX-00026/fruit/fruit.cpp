#iclude<iostream>
#iclude<cstdio>
using namespace std;
scanf a[100010];

int main()
{
    freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	cin>>a;
	for(int i=1;i<=n;i++)
	for(int j=i;j>=i-1;j++)
	if(a[i]<a[j=i])
{	int t=a[j-1];
	a[j-1]=a[j];
	a[j]=t;
}
cout<<a[i]<<" ";
	return 0;
}

