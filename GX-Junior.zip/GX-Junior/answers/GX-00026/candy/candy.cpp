#iclude<iostream>
#iclude<cstdio>
using namespace std;
int a[11],b[21],c[21];
int main()
{
    freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>a>>b>>c;
	for(int i=1;i<=n;)
	  for(int j=i;j-1=i;j--)
	  if(a[i]<a[j])
	  cout<<a[j]" ";
	  else if(a[j]<a[i])
	  cout<<a[i]<<" ";
	return 0;
}
