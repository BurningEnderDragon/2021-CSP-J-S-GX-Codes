#include<iostream>
#include<cstdio>
using namespace std;
int a[256],b[256],c[256],d[256],e[8081]={0};
int u1(int aa,int bb,int cc,int dd,int ee)
{
	if(aa>255&&bb>255&&cc>255&&dd>255&&ee>65535)return 1;
	return 0;
}
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	char t[100];
	int u=0,aa,bb,cc,dd,ee,w=1;cin>>u;
	for(int i=0;i<u;i++){
		for(int i=0;i<6;i++)cin>>t[i];
		w=1;
		if(t[0]=='C'){
			cin>>aa>>t[2]>>bb>>t[2]>>cc>>t[2]>>dd>>t[2]>>ee;
			if(u1(aa,bb,cc,dd,ee)==1){cout<<"ERR"<<endl;w=0;}
			if(a[aa]==2&&b[bb]==2&&c[cc]==2&&d[dd]==2&&e[ee]==2&&w==1)
			{cout<<"OK"<<endl;}
			else if(w)cout<<"FAIL"<<endl;
		}
		if(t[0]=='S')
		{
			cin>>aa>>t[2]>>bb>>t[2]>>cc>>t[2]>>dd>>t[2]>>ee;
			a[aa]=2;b[bb]=2;c[cc]=2;d[dd]=2;e[ee]=2;
			if(u1(aa,bb,cc,dd,ee)==1){cout<<"ERR"<<endl;w=0;}
			if(a[aa]==2&&b[bb]==2&&c[cc]==2&&d[dd]==2&&e[ee]==2&&w)
			{cout<<"FAIL"<<endl;}
			else{if(w){cout<<"OK"<<endl;a[aa]=2;b[bb]=2;c[cc]=2;d[dd]=2;e[ee]=2;}}
		}
    }
    return 0;
}
