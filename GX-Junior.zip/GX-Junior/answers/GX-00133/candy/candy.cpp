#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    long long n,l,r,ac,k;
    cin>>n>>l>>r;k=l/n;k*=n;
    if(r==l){cout<<0;return 0;}
    if(r>n+k){cout<<n-1;return 0;}
    else{
		r-=k;cout<<r;
	}
	return 0;
}
