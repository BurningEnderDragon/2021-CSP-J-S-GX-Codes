#include<iostream>
#include<cstdio>
using namespace std;
int s1,a[100000];
int s(int o)
{
    if(o==s1&&a[o]!=2){
    if(s1==1)s1=2;
    else s1=1;
    return 1;}
    return 0;
}
int main()
{
     int n,sd=0;
     freopen("fruit.in","r",stdin);
     freopen("fruit.out","w",stdout);
     cin>>n;
     for(int i=0;i<n;i++){cin>>a[i];sd+=1;}
     s1=a[0];
     while(sd){
		 int w=1;
         for(int i=0;i<n;i++){
             if(s(a[i])&&sd){sd--;cout<<i<<" ";a[i]=2;w=0;}
             else w++;
         }
         if(w>23)return 0;
         cout<<endl;
     }
     return 0;
}
