#include<iostream>
#include<cstdio>
using namespace std;
long a[8001],b[8001];
int sort(int n,int x){
	for(int i=1;i<=n;i++){b[i]=a[i];}
	for(int i=2;i<=n;i++){
	    for(int j=i;j>=2;j--){
			if(b[j]<b[j-1]){
				int t=b[j];
				b[j]=b[j-1];
				b[j-1]=t;
				if(j==x)x--;
				else{t=j-1;if(t==x)x++;}  //what the f**k?
			}
		}
	}
    return x;
}
int main(){
	freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
	int n,q,cao,x,v;
	cin>>n>>q;
	for(int i=1;i<=n;i++){cin>>a[i];b[i]=a[i];}
	while(q){
		cin>>cao;
		if(cao==2){
			cin>>x;
			cout<<sort(n,x)<<endl;
		}
		else{
			cin>>x>>v;
			a[x]=v;
		}
		q--;
	}
	return 0;
}
