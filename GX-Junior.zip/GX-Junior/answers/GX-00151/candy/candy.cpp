#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
using namespace std;
long long n,l,r;
int main()
{
  freopen("candy.in","r",stdin);
  freopen("candy.out","w",stdout);
  cin>>n>>l>>r;
  while(r>=n)
	  r-=n;
  cout<<r;
  return 0;
}
