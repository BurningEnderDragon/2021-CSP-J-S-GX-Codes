#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
using namespace std;
int n,ans;
string s,c;
int main()
{
  freopen("network.in","r",stdin);
  freopen("network.out","w",stdout);
  cin>>n>>c;
  for(int i=1;i<=n;i++)
  {
	cin>>s;
	if(c=="Server")
	{
		for(int i=1;i<=ng;i++)
		
		}  
  }
  return 0;
}
