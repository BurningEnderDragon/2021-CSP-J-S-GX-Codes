#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
using namespace std;
int a[8010],b[8010],c[8010];
int n,q,ax=1,m=1;
int main()
{
  freopen("sort.in","r",stdin);
  freopen("sort.out","w",stdout);
  cin>>n>>q;
  for(int i=1;i<=n;i++)
    cin>>a[i];
  for(int i=1;i<=q;i++)
  {
    int x,c,v;
    cin>>c;
    if(c==1)
    {
	  cin>>x>>v;
	  a[x]=v;
	}
	else
	{
		cin>>x;
		for(int i=1;i<=n;i++)
		{
		  for(int j=1;j<=m;j++)
		  {
		   if(c[j]==a[x])
		      if(x>b[j])
		        ax++;
			}
		  if(a[i]<a[x])
		    ax++;
		}
		b[m]=x;
		c[m]=a[x];
		m++;
		cout<<ax<<endl;
		ax=1;
    }
  }
  return 0;
}
