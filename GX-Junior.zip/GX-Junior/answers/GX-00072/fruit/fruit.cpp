#include<iostream>
using namespace std;
int main(){
	freopen("fruit.in","r",stdin);
	freopen("fruit.ans","w",stdout);
	int n;
	getline n;
	for(int i=0;i<n;i++){
		for(int j=i+1;j<=n;j++)
		if(n[i]<[j])
			swap(n[i],n[j]);
		else
		;	
	}
	cout<<n;
	return 0;
}
