#include<iostream>
using namespace std;
int main(){
	freopen("candy.in","r",stdin);
	freopen("candy.ans","w",stdout);
	int n,L,R,k=0,a,bask;
	cin>>n>>k>>L>>R;
	/*if(n<2)
		break;
		else
		;*/	
		for(int i=0;i>=n;i++){
			if(L<=k){
				if(k<=R)
				bask=k;
				else
					;
					}
			else
				;
				for(int j=1;j<=n;j++){
					a=R%n;
					}
				}
				cout<<a;
	return 0;
}
