#include<iostream>
using namespace std;
int main()
{
	freopen("netbook.in","r",stdin);
	freopen("netbook.ans","w",stdout);
	int n;
	string op,ad;
	cin>>n;
	getlien>>op>>ad;
	for(int i=0;i<=n;i++){
		for(int j=i+1;j<n;j++)
		if(op>25)
			break;
		else
		    ;
	}	
	cout<<"FAIL"<<"OK"<<endl;
	return 0;
}
