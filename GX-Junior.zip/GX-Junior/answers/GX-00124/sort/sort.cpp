#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
int n,a[5010],t;
int main()
{
  freopen("sort.in","r",stdin);
  freopen("sort.out","w",stdout);
  
  scanf("%d",&n);
  for(int i=1;i<=n;i++)
  {
	 for(int j=i;j>=2;j--)
	 {
		scanf("%d",&a[i]);
		if(a[j]<a[j-1])
        swap(a[j],a[j-1]);
	 }
  }
  for(int j=1;j<=n;j++)
  printf("%d\n",a[j]);
  return 0;
}
