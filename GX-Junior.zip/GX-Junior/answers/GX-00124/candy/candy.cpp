#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
int n,l,r;
int ans=0,pans=0,spare=0;
int main()
{
  freopen("candy.in","r",stdin);
  freopen("candy.out","w",stdout);
  
  scanf("%d%d%d",&n,&l,&r);
  for(int i=1;i<=n;i++)
  {
	int k;
	scanf("%d",&k);
	if(l<=r||k<=r)
	{
	  if(k>=n)
	  {
		k--;
		ans++;
		pans++;
		spare++;
	  }
	  if(k<n)
	  {
		k-=ans;
		ans-=spare;
	  }
	}
  }
  ans-=1;
  printf("%d",ans);
  return 0;
}

