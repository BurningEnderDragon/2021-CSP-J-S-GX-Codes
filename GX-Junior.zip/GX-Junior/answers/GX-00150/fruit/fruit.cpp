#include<iostream>
#include<cstdio>
#include<algorithm>
#include<string>
#include<cmath>
using namespace std;
long long n;
int a[200001];
int ans=0;
int main()
{
   freopen("fruit.in","r",stdin);
   freopen("fruit.out","w",stdout);
   scanf("%lld",&n);
   for(int i=1;i<=n;i++)
   {
      cin>>a[i];
      if(a[i]!=a[i+1])
         ans++;   
   }  
   cout<<ans;
   
   return 0;	
}

