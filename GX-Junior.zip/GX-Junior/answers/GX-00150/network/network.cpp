#include<iostream>
#include<cstdio>
#include<algorithm>
#include<string>
#include<cmath>
using namespace std;
int n;
string s;
int len;
int main()
{
   freopen("network.in","r",stdin);
   freopen("network.out","w",stdout);
   scanf("%d",&n);
   printf("OK\n");
   for(int i=1;i<=n;i++)
   {
      getline(cin,s);
      len=s.size();
	  if(s[10]!='.' || s[14]!='.' || s[16]!='.' || s[18]!=':')
	    printf("ERR\n");
	  else
        printf("FAIL\n");
   }    
   
   return 0;	
}
