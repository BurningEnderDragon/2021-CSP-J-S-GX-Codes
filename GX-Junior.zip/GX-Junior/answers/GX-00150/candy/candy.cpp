#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
long long n,l,r;
long long ans=0;
int maxx=-1;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    scanf("%lld%lld%lld",&n,&l,&r);
    for(int i=r;i>=l;i--)
	{
	   int x=i;
	   ans=x/n;
	   x=x-ans*n;
       if(x>maxx)
          maxx=x; 	
    }
    printf("%d",maxx);
          
    return 0;
}
