#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
long long q;
int n;
int a[8001];
int main()
{
   freopen("sort.in","r",stdin);
   freopen("sort.out","w",stdout);
   scanf("%d%lld",&n,&q);
   for(int i=1;i<=n;i++)
      cin>>a[i];
   for(int i=1;i<=q;i++)
   {
	   cout<<a[i;
   }   
   
   return 0;	
}
