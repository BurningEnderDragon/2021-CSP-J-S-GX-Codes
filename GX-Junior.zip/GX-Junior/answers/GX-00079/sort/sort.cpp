#include <bits/stdc++.h>

using namespace std;
int a[8005] ={0};
int n,q;
int main()
{
    freopen("sort.in", "r",stdin);
    freopen("sort.out", "w",stdout);
    cin>> n >> q;
    for(int i = 1;i <= n;i ++){
        scanf("%d",&a[i]);
    }
    int b;
    int x,v,ans = 1;
    while (q--) {
        ans = 0;
        scanf("%d",&b);
        b--;
            //cout<<b<<endl;
        if(!b){
            scanf("%d%d",&x,&v);
            a[x] = v;
        }else{
            scanf("%d",&v);
            for(int i= 1;i <= n;i++){
                if(a[i] < a[v]){
                    ans++;
                }
                if(a[i]==a[v]){
                    if(i <= v){
                        ans++;
                    }
                }
            }
            printf("%d\n",ans);
        }
    }
    /*for (int i = 1; i <= n; i++)
        for (int j = i; j>=2; j‐‐)
            if ( a[j] < a[j‐1] ){
                int t = a[j‐1];
                a[j‐1] = a[j];
                a[j] = t;

            }*/
    return 0;
}
