#include <bits/stdc++.h>
#include <map>
#include <string>
using namespace std;
struct node{
    int a,b,c,d,e;

};
map<string,int> m;
int n;
string s,jk;
    node temp;
    char c;
    bool correct=0;
void getnum(){
    correct=0;
    temp.a = 0;
    temp.b = 0;
    temp.c = temp.d = temp.e = 0;
    cin>>jk;
    int i = 0;
    while(jk[i] <= '9' &&jk[i] >= '0'&&i < jk.size()-1){
        temp.a*=10;
        temp.a += jk[i] - '0';
        //cout<<jk[i] - '0'<<endl;
        i++;
    }
    c = jk[i++];
    if(c!='.'||temp.a > 255||temp.a < 0)correct = 1;
    while(jk[i] <= '9' &&jk[i] >= '0'&&i < jk.size()-1){
        temp.b*=10;
        temp.b += jk[i] - '0';
        i++;
    }
    c = jk[i++];
    if(c!='.'||temp.b > 255||temp.b < 0)correct = 1;
    while(jk[i] <= '9' &&jk[i] >= '0'&&i < jk.size()-1){
        temp.c*=10;
        temp.c += jk[i] - '0';
        i++;
    }
    c = jk[i++];
    if(c!='.'||temp.c > 255||temp.c < 0)correct = 1;
    while(jk[i] <= '9' &&jk[i] >= '0'&&i < jk.size()-1){
        temp.d*=10;
        temp.d += jk[i] - '0';
        i++;
    }
    c = jk[i++];
    if(c!=':'||temp.d > 255||temp.d < 0)correct = 1;
    while(jk[i] <= '9' &&jk[i] >= '0'&&i < jk.size()){
        temp.e*=10;
        temp.e += jk[i] - '0';
        i++;
    }
    if(temp.e > 65535||temp.e < 0)correct = 1;
    //printf("%d.%d.%d.%d:%d\n",temp.a,temp.b,temp.c,temp.d,temp.e);
}
int main()
{
    freopen("network.in", "r",stdin);
    freopen("network.out", "w",stdout);
    cin>>n;
    for(int i = 1;i <= n;i++){
        cin >> s;
        //cin >> jk;
        getnum();

        if(correct){
            printf("ERR\n");
            continue;
        }
        if(s == "Server"){
            if(m[jk]!=0){
                printf("FAIL\n");
                continue;
            }
            m[jk] = i;
            printf("OK\n");
            continue;
        }else{
            if(m[jk]!=0){
            printf("%d\n",m[jk]);
                continue;
            }
                printf("FAIL\n");
        }
    }
    return 0;
}

