#include <iostream>

using namespace std;
bool f[200005],v[200005];
int n;
int main()
{
    freopen("fruit.in", "r",stdin);
    freopen("fruit.out", "w",stdout);
    cin>>n;
    for(int i = 0;i < n;i++){
        //cout<<n<<endl;
        cin>>f[i];
    }
    bool popnum=1,last = !f[0];
    while(popnum){
        popnum = 0;
        for(int i = 0;i < n;i ++){
            //cout<<v[i]<<" ";
            if((f[i]!=last||!popnum)&&v[i]==0){
                v[i] = 1;
                printf("%d ",i+1);
                last = f[i];
                popnum++;
            }
        }cout<<endl;
    }
    return 0;
}/*12
1 1 0 0 1 1 1 0 1 1 0 0*/
