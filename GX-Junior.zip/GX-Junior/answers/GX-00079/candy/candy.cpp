#include<iosteam>
using namespace std;
int n,l,r;
int main(){
    freopen("candy.in","r",stdin);
    freopen("candy.out", "w",stdout);
    cin >> n >> l >> r;
    int ans = 0;
    for(int i = l;i <= r;i ++){
        if(i%n > ans){
            ans = i%n;
        }
    }
    cout<<ans;
}
