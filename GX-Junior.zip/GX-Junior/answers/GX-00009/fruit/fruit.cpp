#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<stack>
#include<queue>
#include<algorithm>
using namespace std;
int x[200001];
bool y[200001];
int n;
int main(){
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&x[i]);
		y[i]=0;
	}
	int o=n;
	int h=-1;
	for(int i=1;o>0;i++)
	{
		if(!y[i])
		{
			if(x[i]!=h)
			{
				cout<<i<<' ';
				h=x[i];o--;y[i]=1;
			}
		}
		if(i==n)
		{
			i=0;cout<<endl;h=-1;
		}
	}
	return 0;
}
