#include<iostream>
#include<cstdio>
#include<cmath>
#include<stack>
#include<algorithm>
#include<string>
#include<queue>
#include<cstring>
using namespace std;
struct name{
	int q;
	int y;
}a[8002];
int Q,n,h;
bool cmp(name o,name j){
	return o.q<j.q;
}
bool cmq(name o,name j){
	if(o.y!=j.y) return o.y<j.y;
	else return o.q<j.q;
}
int main(){
	freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    scanf("%d%d",&n,&Q);
    for(int i=1;i<=n;i++)
    {
		scanf("%d",&h);
		a[i].y=h;
		a[i].q=i;
	}
	for(int i=0;i<Q;i++)
	{
		int z;
		scanf("%d",&z);
		if(z-1)
		{
			int x;
			scanf("%d",&x);
			sort(a,a+n+1,cmq);
			for(int i=1;i<=n;i++)
			{
				if(a[i].q==x) {cout<<i<<endl;break;}
			}
			sort(a,a+n+1,cmp);
		}
		else
		{
			int x,v;
			scanf("%d%d",&x,&v);
			a[x].y=v;
		}
	}
    return 0;
}
