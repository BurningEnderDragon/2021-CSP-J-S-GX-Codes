#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<algorithm>
#include<queue>
#include<stack>
using namespace std;
int n;
struct name{
	char l;
	string a;
	string z;
	int u;
}w[1002];
int main(){
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		char t;
		string v;
		cin>>v;
		getchar();
		w[i].l=v[0];
		cin>>w[i].a;
	}
	for(int i=1;i<=n;i++)
	{
		if(w[i].l=='S') cout<<"OK"<<endl;
		else
		{   
			w[i].z="FAIL";
			for(int j=1;j<=n;j++)
			{
				
				if(w[j].l=='S')
				{
				    if(w[i].a==w[j].a) w[i].z=j+'0';
				}
			}
			cout<<w[i].z<<endl;
		}
	}
	return 0;
}
