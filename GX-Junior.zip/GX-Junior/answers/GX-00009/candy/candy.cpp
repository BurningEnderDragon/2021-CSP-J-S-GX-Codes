#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<stack>
#include<queue>
#include<cstring>
#include<string>
using namespace std;
int n,L,k,R;
int main(){
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d%d%d",&n,&L,&R);
	k=0;
	for(int i=L;i<=R;i++)
	{
		k=max(k,i%n);
		if(k==n-1) break;
	}
	cout<<k;
	return 0;
}
