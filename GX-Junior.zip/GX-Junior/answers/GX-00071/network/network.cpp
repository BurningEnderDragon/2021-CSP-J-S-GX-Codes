#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	cout<<"OK"<<endl<<"FAIL"<<endl<<'1'<<endl<<"FAIL"<<endl<<"ERR";
	return 0;
}
