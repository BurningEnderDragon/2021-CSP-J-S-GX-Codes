#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
long long x,y,z,a;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>x>>y>>z;
	a=y;
	for(int i=1;i<=z;i++)
	{
		if(y%x==x-i)
		{
			cout<<y%x;
			return 0;
		}
		else
		   if(y==z)
		   {
			   y=a;
		   }
		   else
		   {
		      y++;
		      i--;
		  }
	}
	return 0;
}
