#include<iostream>
#include<cstdio>
#include<string>
#include<cmath>
#include<algorithm>
using namespace std;
int n,sum;
string qq;
int main()
{
	freopen("network.in","r",stdin);
	freopen("network.out","w",stdout);
	scanf("%d",&n);
	for(int sb=1;sb<=n;sb++)
	{
		string s1,s2;
		cin>>s1>>s2;
		if(s1=="Server")
		{
			char hh=sb;
			qq=qq+s2+'&'+hh;
			sum++;
		}
		else
		{
			int len1=qq.size(),len2=s2.size();
			for(int i=0;i<len1;i++)
			for(int j=0;j<len2;j++)
		}
	}
	return 0;
}
