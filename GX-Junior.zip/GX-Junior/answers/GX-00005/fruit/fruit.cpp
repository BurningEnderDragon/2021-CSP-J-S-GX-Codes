#include<iostream>
#include<cstdio>
#include<string>
#include<cmath>
#include<algorithm>
using namespace std;
int n,c[200010],len,j,l;
struct
{
	int q,p;
}a[200010],b[200010];
int main()
{
	freopen("fruit.in","r",stdin);
	freopen("fruit.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
	  scanf("%d",&a[i].q);
	  a[i].p=i;
    }
	while(n-j+1>0)
	{
		l=j;
		for(int i=n-j;i>1;i--)
		if(a[i].q!=a[i-1].q)
		{
		  a[i].q=2;
		  c[++j]=a[i].p;
	    }
	    a[1].q=2;
	    c[++j]=a[1].p;
		for(int i=j;i>=l+1;i--)
		cout<<c[i]<<' ';
		for(int i=1;i<=n;i++)
		if(a[i].q!=2)
		{
		  b[i].p=a[i].p;
		  b[i].q=a[i].q;
		 }
		for(int i=1;i<=n;i++)
		{
		  a[i].p=b[i].p;
		  a[i].q=b[i].q;
		 }
		cout<<endl;
	}
	return 0;
}
