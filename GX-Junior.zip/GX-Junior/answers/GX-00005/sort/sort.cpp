#include<iostream>
#include<cstdio>
#include<string>
#include<cmath>
#include<algorithm>
using namespace std;
int n,q,a[10010],b[10010];
int main()
{
	freopen("sort.in","r",stdin);
	freopen("sort.out","w",stdout);
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	while(q--)
	{
		int a1,a2,a3;
		scanf("%d",&a1);
		if(a1==1)
		{
			scanf("%d%d",&a2,&a3);
			a[a2]=a3;
		}
		else
		{
			scanf("%d",&a2);
			for(int i=1;i<=n;i++)
			b[i]=a[i];
            for (int i = 1; i <= n; i++)
            for (int j = i; j>=2; j--)
            if ( b[j] < b[j-1] ){
            int t = b[j-1];
            b[j-1] = b[j];
            b[j] = t;
            }
			for(int i=1;i<=n;i++)
			if(b[i]==a[a2])
			{
			  cout<<i<<endl;
			  break;
			}
		}
		
	}
	return 0;
}
