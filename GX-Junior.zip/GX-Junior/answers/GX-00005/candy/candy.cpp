#include<iostream>
#include<cstdio>
#include<string>
#include<cmath>
#include<algorithm>
using namespace std;
int n,l,r,mx;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	scanf("%d%d%d",&n,&l,&r);
	if(r-l+l%n>n-1)
	cout<<n-1;
	else
	cout<<r-l+l%n;
	return 0;
}
