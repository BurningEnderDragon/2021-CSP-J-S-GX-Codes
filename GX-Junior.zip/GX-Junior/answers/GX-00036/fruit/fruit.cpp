#include <iostream>
#include <string>
using namespace std;
int main(){
	int n,f1,f2,f3,f4,f5,i = -1;
	int op;
	cin >> n;
	if (n>=1){
		cin >> f1;
	}
	
	if (n>=2){
		cin >> f2;
	}
	if (n>=3){
		cin >> f3;
	}
	
	if (n>=4){
		cin >> f4;
	}
	if (n>=5){
		cin >> f5;
	}
	if (f1 == f2){
		op = 1;
		if (f2 == f3){
			op = 1;
			if (f3 == f4){
			    op = 1;
			    if (f4 == f5)
			    op = 1;
		    }
		}
	}
	else if (f2 == f3){
		op = 2;
		if (f3 == f4){
			op = 2;
			if (f4 == f5){
				op = 2;
			}
		}
	}
	else if (f3 == f4){
		op = 3;
		if (f4 == f5){
			op = 3;
		}
	}
	else if (f4 == f5){
		op = 4;
	}
	else {
		i = 0;
		while(i<n){
			i++;
			cout << i << " ";
		}
	    return 0;
	}
	i = 0;
    while (i <= op){
		i++;
		cout << i << " ";
	}
	return 0;
}
