
#include <iostream>
using namespace std;
int main()
{
	int n,L,R,k = 0;
	int max = 0;
	cin >> n >> L >> R;
	k = L;
	while(k < R){
		k = k+1;
		if (k%n >= max){
			max = k%n;
		}
	}
	cout << max;
	return 0;
}

