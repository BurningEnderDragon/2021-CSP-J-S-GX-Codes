#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
struct dd
{
   int s,h;
}a[100000001],f[100000001];
bool cmp(dd x,dd y)
{
   if(x.s!=y.s)
      return x.s<y.s;
   return x.h<y.h;	
}
int main()
{
   freopen("sort.in","r",stdin);
   freopen("sort.out","w",stdout);
   int n,q;
   cin>>n>>q;
   for(int i=1;i<=n;i++)
   {
	   cin>>a[i].s;
	   a[i].h=i;
	   f[i].s=a[i].s;
	   f[i].h=a[i].h;
   }
  for(int i=1;i<=q;i++)
   {
	   sort(a+1,a+1+n,cmp);
	   int b,t=0;
	   cin>>b;
	   if(b==2)
	   {
		   int c;
		   cin>>c;
		   sort(f+1,f+1+n,cmp);
		   cout<<a[c].h<<endl;
	   }
	   if(b==1)
	   {
		   int c;
		   cin>>c>>t;
		   a[c].s=t;
	   }   
   }
   return 0;
}
