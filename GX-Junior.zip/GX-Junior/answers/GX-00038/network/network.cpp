#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<string>
using namespace std;
int main()
{
   freopen("network.in","r",stdin);
   freopen("network.out","w",stdout);
   int n;
   cin>>n;
   while(n--)
   {
      string a;
      int c,d,e,f,g;
      char h,i,j,k;
      cin>>a>>c>>h>>d>>i>>e>>j>>f>>k>>g;
      cout<<a<<" "<<c<<h<<d<<i<<e<<j<<f<<k<<g<<endl;
   }
   return 0;
}

