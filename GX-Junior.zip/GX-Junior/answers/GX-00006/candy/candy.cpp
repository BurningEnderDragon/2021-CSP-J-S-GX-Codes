#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,L,R,ans=0;

    cin>>n>>L>>R;
    if(R-L>=n)
    {
        cout<<n-1;
        return 0;
    }

    for(int i=R;i>=L;i--)
        if(i%n>ans)ans=i%n;
    cout<<ans;
    return 0;
}
