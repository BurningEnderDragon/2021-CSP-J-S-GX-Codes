#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    cout<<"No time write this (Chinglish wwww)\n";
    cout<<"mengshenbaoyouwoshengyi!!!!!!!!!!!!!!!!!!!!!!!!!";
    return 0;
}
