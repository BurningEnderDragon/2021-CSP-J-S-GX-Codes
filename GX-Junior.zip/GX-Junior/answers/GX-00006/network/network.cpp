#include<bits/stdc++.h>
using namespace std;
struct Serv{
    int s1=0,s2=0,s3=0,s4=0,s5=0,bh=0;
}se[1010];
int sertot=1;

int main()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int n;
    cin>>n;
    for(int ii=1;ii<=n;ii++)
    {
        string op,ad;
        cin>>op>>ad;
        int ad1=-1,ad2=-1,ad3=-1,ad4=-1,ad5=-1;

        //int pointtot=0,tpointtot=0,j2=0;
        //bool ERRflag=false;
        //while(ad[j2]=='1' or ad[j2]=='2' or ad[j2]=='3' or ad[j2]=='4' or ad[j2]=='5' or ad[j2]=='6' or ad[j2]=='7' or ad[j2]=='8' or ad[j2]=='9' or ad[j2]=='0' or ad[j2]=='.' or ad[j2]==':'){
        //    if(ad[j2]=='0' and (ad[j2+1]=='1' or ad[j2+1]=='2' or ad[j2+1]=='3' or ad[j2+1]=='4' or ad[j2+1]=='5' or ad[j2+1]=='6' or ad[j2+1]=='7' or ad[j2+1]=='8' or ad[j2+1]=='9' or ad[j2+1]=='0')){ERRflag=true;break;}
        //    if(ad[j2]==':' and (ad1==-1 or ad2==-1 or ad3==-1 or ad4==-1)){ERRflag=true;break;}
        //    if(ad[j2]=='.')pointtot++;
        //    if(ad[j2]==':')tpointtot++;
        //    j2++;
        //}

        ad1=0,ad2=0,ad3=0,ad4=0,ad5=0;
        int j=0;
        while(ad[j]=='1' or ad[j]=='2' or ad[j]=='3' or ad[j]=='4' or ad[j]=='5' or ad[j]=='6' or ad[j]=='7' or ad[j]=='8' or ad[j]=='9' or ad[j]=='0'){
            ad1*=10;
            ad1+=ad[j]-'0';
            ++j;
        }
        ++j;
        while(ad[j]=='1' or ad[j]=='2' or ad[j]=='3' or ad[j]=='4' or ad[j]=='5' or ad[j]=='6' or ad[j]=='7' or ad[j]=='8' or ad[j]=='9' or ad[j]=='0'){
            ad2*=10;
            ad2+=ad[j]-'0';
            ++j;
        }
        ++j;
        while(ad[j]=='1' or ad[j]=='2' or ad[j]=='3' or ad[j]=='4' or ad[j]=='5' or ad[j]=='6' or ad[j]=='7' or ad[j]=='8' or ad[j]=='9' or ad[j]=='0'){
            ad3*=10;
            ad3+=ad[j]-'0';
            ++j;
        }
        ++j;
        while(ad[j]=='1' or ad[j]=='2' or ad[j]=='3' or ad[j]=='4' or ad[j]=='5' or ad[j]=='6' or ad[j]=='7' or ad[j]=='8' or ad[j]=='9' or ad[j]=='0'){
            ad4*=10;
            ad4+=ad[j]-'0';
            ++j;
        }
        ++j;
        while(ad[j]=='1' or ad[j]=='2' or ad[j]=='3' or ad[j]=='4' or ad[j]=='5' or ad[j]=='6' or ad[j]=='7' or ad[j]=='8' or ad[j]=='9' or ad[j]=='0')
        {
            ad5*=10;
            ad5+=ad[j]-'0';
            ++j;

        }
        //if(pointtot!=3 or tpointtot!=1)ERRflag=true;
        //if(ad1>255 or ad2>255 or ad3>255 or ad4>255 or ad5>65535)ERRflag=true;
        //if(ERRflag){cout<<"ERR\n";continue;}

        if(op=="Server")
        {
            bool OKflag=true;
            for(int i=1;i<=sertot;i++)
            {
                if(se[i].s1==ad1 and se[i].s2==ad2 and se[i].s3==ad3 and se[i].s4==ad4 and se[i].s5==ad5){cout<<"FAIL\n";OKflag=false;break;}
            }
            if(OKflag)
            {
                cout<<"OK"<<endl;
                se[sertot].s1=ad1,se[sertot].s2=ad2,se[sertot].s3=ad3,se[sertot].s4=ad4,se[sertot].s5=ad5,se[sertot].bh=ii;
                ++sertot;
            }
        }
        else if(op=="Client")
        {
            bool FAILflag=true;
            for(int i=1;i<=sertot;i++)
                if(se[i].s1==ad1 and se[i].s2==ad2 and se[i].s3==ad3 and se[i].s4==ad4 and se[i].s5==ad5){cout<<se[i].bh<<endl;FAILflag=false;break;}
            if(FAILflag)cout<<"FAIL\n";
        }
    }
    return 0;
}
