#include<bits/stdc++.h>
using namespace std;
int a[8010];
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    int n,Q;
    cin>>n>>Q;
    for(int i=1;i<=n;i++)
        cin>>a[i];

    for(int ii=1;ii<=Q;ii++)
    {
        int que;
        cin>>que;
        if(que==1)
        {
            int x,v;
            cin>>x>>v;
            a[x]=v;
        }
        else if(que==2)
        {
            int x,tot=0;//int ans=0;
            cin>>x;
            //ans=x;
            for(int i=1;i<=n;i++)
            {
                if(a[i]<a[x])tot++;
                if(a[i]==a[x] and i<=x)tot++;
            }
            cout<<tot<<endl;

/*            for (int i = 1; i <= n; i++)
                for (int j = i; j>=2; j--)
                    if ( a1[j] < a1[j-1] )
                    {
                        int t = a1[j-1];
                        a1[j-1] = a1[j];
                        a1[j] = t;
                        if(j==ans)ans=j-1;
                        else if(j-1==ans)ans=j;
                   }
            cout<<ans<<endl;  hui4chao1shi2  =( */
        }
    }
    return 0;
}
