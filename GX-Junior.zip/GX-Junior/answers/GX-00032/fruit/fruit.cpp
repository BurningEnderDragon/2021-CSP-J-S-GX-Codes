#include <iostream>
using namespace std;
int main()
{
    freopen("fruit.in", "r", stdin);
    freopen("fruit.out", "w", stdout);
    int n, n2;
    int l=2;
    cin>>n;
    n2=n;
    int f[n+1];
    for(int i=1; i<=n; i++) cin>>f[i];
    while(n2!=0)
    {
        for(int i=1; i<=n; i++)
        {
            if(f[i] == 2 || f[i] == l)
            {
                l=f[i];
                continue;
            }
            cout<<i<<" ";
            l=f[i];
            f[i]=2;
            n2--;
        }
        cout<<endl;
    }
    return 0;
}
