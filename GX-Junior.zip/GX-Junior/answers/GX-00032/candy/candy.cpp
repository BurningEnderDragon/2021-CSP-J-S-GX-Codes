#include <iostream>
using namespace std;
int main(){
    freopen("candy.in", "r", stdin);
    freopen("candy.out", "w", stdout);
    long long n, L, R;
    long long s=0;
    cin>>n>>L>>R;
    for(int i=R;i>=L;i--){
        int t=i;
        while(t>=n){
            t-=n;
        }
        if(t>s) s=t;
    }
    cout<<s;
    return 0;
}
