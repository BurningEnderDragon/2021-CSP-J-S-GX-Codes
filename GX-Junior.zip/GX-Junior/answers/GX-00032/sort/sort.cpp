#include <iostream>
using namespace std;
int main(){
    freopen("sort.in", "r", stdin);
    freopen("sort.out", "w", stdout);
    long long n, Q;
    cin>>n>>Q;
    int a[n+1];
    for(int i=1;i<=n;i++) cin>>a[i];
    for(int i=1;i<=Q;i++){
        int mode;
        cin>>mode;
        if(mode==1){
            long long x, v;
            cin>>x>>v;
            a[x]=v;
        }else if(mode==2){
            int t[n+1]={0};
            for(int q=1;q<=n;q++) t[q]=a[q];
            long long p;
            cin>>p;
            for(int j=1;j<=n;j++)
                for(int k=j;k>=2;k--)
                    if(t[k] < t[k-1]){
                        int t2 = t[k-1];
                        t[k-1] = t[k];
                        t[k]   = t2;
                        if(p==(k-1)) p++;
                        else if(p==k) p--;
                    }
            cout<<p<<endl;
        }
    }
    return 0;
}
