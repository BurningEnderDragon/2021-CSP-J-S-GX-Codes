#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a,b,c,i,j,s=0,x=-9999;
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>a>>b>>c;
	for(i=b;i<=c;i++)
	{
		s=i/a;
		n=i-a*s;
		if(n>x)
			x=n;
	}
	cout<<x;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
