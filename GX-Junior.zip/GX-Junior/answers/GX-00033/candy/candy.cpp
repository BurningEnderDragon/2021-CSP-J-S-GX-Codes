#include <bits/stdc++.h>
using namespace std;
int main(){
freopen("candy.in","r",stdin);
freopen("candy.out","w",stdout);
int n,l,r,k=l;
cin>>n>>l>>r;
for(int i=0;i<r;){
    if(k>=n)
        k-=n;
    if(k<n){
        cout<<k<<endl;
        break;
    }
}
return 0;
}
