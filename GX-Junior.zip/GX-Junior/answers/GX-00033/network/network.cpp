#include <bits/stdc++.h>
using namespace std;
int main(){
freopen("network.in","r",stdin);
freopen("network.out","w",stdout);
int n;
string op[n],ad[n];
cin>>n;
for(int i=0;i<n;i++)
    cin>>op[i]>>ad[i];
for(int i=0;i<n;i++){
    if(op[i]=="Server"){
        cout<<"OK"<<endl;
    }
    if(op[i]=="Client"){
        cout<<"FAIL"<<endl;
    }
}
return 0;
}
