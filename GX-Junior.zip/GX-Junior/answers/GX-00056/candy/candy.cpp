#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int  n,k,L;
int a;
int main()
{
	freopen("candy.in","r",stdin);
	freopen("candy.out","w",stdout);
	cin>>n>>k>>L;
    for(int i=k;i>L;i++)
    if(k%n==0)  
    cout<<"0";
    else
    if(k%n!=0) 
    a==k%n;
    cout<<a;
    return 0; 

}
