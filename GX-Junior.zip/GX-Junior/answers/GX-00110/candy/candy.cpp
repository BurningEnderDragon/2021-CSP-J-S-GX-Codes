#include <iostream>
using namespace std;
int main(){
	long long k,n,l,r,a=0,m;
	cin>>n>>l>>r;
	for(k=l;k<=r;k++){
		if(k/n == 1){
			m=r-n;
		}else if(k/n>1){
			m=k%n;
		}
		if(m>a){
			a=m;
		}
	}
	cout<<a<<endl;
	return 0;
}
