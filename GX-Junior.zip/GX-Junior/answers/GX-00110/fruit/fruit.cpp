#include <iostream>
using namespace std;
int i,M=200000,m=0,n;
void F(int a[],int b[]){
	for(i=0;i<n;i++){
		if(a[i]==a[i+1]){
			b[m]=a[i+1];
			m++;
		}else{
			cout<<i;
		}
	}
	cout<<endl;
	F(b,a);
}
int main(){
	int a[M],b[M];
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	F(a,b);
	return 0;
}
