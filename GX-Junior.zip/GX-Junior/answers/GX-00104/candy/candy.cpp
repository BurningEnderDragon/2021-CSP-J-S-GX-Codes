#include<bits/stdc++.h>
using namespace std;
long long n,r,l,cha;
long long s1,s2,s3,ans;
int main()
{
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    cin>>n>>l>>r;
        s1=l-l%n;
        s2=s1+n;
        s3=s2+n;
    //cout<<s1<<endl<<s2<<endl<<s3<<endl;
    ans=max(ans,l-s1);
    ans=max(ans,(r-s1)%n);
    if(s2-1>=l&&s2-1<=r) ans=max(ans,n-1);
//    if(s2-1>=l&&s2-1<=r) ans=max(ans,n-1)
    cout<<ans;


}
