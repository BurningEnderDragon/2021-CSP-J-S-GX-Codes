#include<bits/stdc++.h>
using namespace std;
long long n,q;
struct H{
    long long x,w;
}a[8010],b[8010];
long  lx,x,v;
bool cmp(H x,H y){
    if(x.x==y.x) return x.w<y.w;
    else
    return x.x<y.x;
}
int main()
{
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    cin>>n>>q;
    for(int i=1;i<=n;i++)
    {
        std::cin>>a[i].x;
        //scanf("%.lld",a[i].x);
        a[i].w=i;
        b[i].x=a[i].x;
        b[i].w=a[i].w;
    }
    sort(b+1,b+1+n,cmp);
    for(int t=1;t<=q;t++)
    {
        cin>>lx;
        if(lx==1)
        {
            cin>>x>>v;
            a[x].x=v;
            for(int i=1;i<=n;i++)
            {
                if(b[i].w==x)
                {
                    b[i].x=v;
                    break;
                }
            }

            sort(b+1,b+1+n,cmp);
        }
        else
        {
            cin>>x;
            int k=a[x].w;
            //for(int i=1;i<=n;i++) cout<<"("<<b[i].w<<" "<<b[i].x<<")"<<endl;
            for(int i=1;i<=n;i++)
            {
                if(b[i].w==k)
                {
                    cout<<i<<endl;
                    break;
                }
            }
        }





    }





}
