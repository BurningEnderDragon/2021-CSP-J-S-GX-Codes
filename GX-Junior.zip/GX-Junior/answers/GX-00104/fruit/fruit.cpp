#include<bits/stdc++.h>
using namespace std;
struct H{
    int w,x;
}a[200010];
int n,v[200010];
int main(){
    freopen("fruit.in","r",stdin);
    freopen("fruit.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++) std::cin>>a[i].x,a[i].w=i;
    while(1==1)
    {
        int tx=2,pp=1;
        for(int i=1;i<=n;i++)
        {
            if(a[i].x!=tx&&v[i]==0)
            {
                tx=a[i].x;
                v[i]=1;
                pp=0;
                cout<<a[i].w<<" ";
            }
        }
        cout<<endl;
        if(pp) break;


    }







}
