#include<bits/stdc++.h>
using namespace std;
int n;
string lx,a,ser[1010],cli[1010],k1="Server",k2="Client";
int xs=0,xc=0,serr[1010];
bool cher(string x){
    long long  a=0,b=0,c=0,d=0,e=0,len=x.size();
    int acnt=0,bcnt=0;
    if(len>21) return 0;
    //cout<<"len"<<len<<endl;
    for(int i=0;i<len;i++)
    {
        if(x[i]!='.'&&x[i]!=':'&&(x[i]<'0'||x[i]>'9'))
        {
            //cout<<endl<<1<<endl;
            return 0;
        }

        if(i!=0)
        {
            if(x[i]=='0'&&x[i+1]>='0'&&x[i+1]<='9'&&(x[i-1]<'0'||x[i-1]>'9'))
            {
                    //cout<<endl<<2<<endl;
                    return 0;
            }
        }

        if(x[i]=='.'&&(x[i+1]=='.'||x[i+1]==':'))
        {
            //cout<<endl<<3<<endl;
            return 0;
        }
        if(x[i]=='.')acnt++;
        else
        if(x[i]==':') bcnt++;
        else
        if(acnt==0)a=a*10,a+=x[i]-'0';
        else
        if(acnt==1) b=b*10,b+=x[i]-'0';
        else
        if(acnt==2)
        {
            c=c*10;
            c+=x[i]-'0';
        }
        else
        if(acnt==3&&bcnt==0)
        {
            d*=10;
            d+=x[i]-'0';
        }
        else
        if(bcnt==1)
        {
            e*=10;
            e+=x[i]-'0';
        }
    }
    if(acnt!=3||bcnt!=1||a>255||b>255||c>255||d>255||e>65535)
    {
        //cout<<endl<<a<<" "<<b<<" "<<c<<" "<<d<<" "<<e<<endl;
        return 0;

    }
    return 1;
}
int main ()
{
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    cin>>n;
    for(int t=1;t<=n;t++)
    {
        std::cin>>lx;
        std::cin>>a;
        if(cher(a)==1)
        {
            if(lx==k1)//fuhu
            {
                int txt=1;
                for(int i=1;i<=xs;i++)
                {
                    if(ser[i]==a)
                    {
                        cout<<"FAIL"<<endl;
                        txt=0;
                        break;
                    }
                }
                if(txt==1)
                {
                    xs++;
                    ser[xs]=a;
                    serr[xs]=t;
                    cout<<"OK"<<endl;
                }
            }
            else
            if(lx==k2)//kehu
            {
                int tst=1;
                for(int i=1;i<=xs;i++)
                {
                    if(ser[i]==a)
                    {

                            tst=0;
                            cout<<serr[i]<<endl;
                            break;

                    }

                }
                if(tst) cout<<"FAIL"<<endl;
            }
        }
        else
            cout<<"ERR"<<endl;
    }
}
