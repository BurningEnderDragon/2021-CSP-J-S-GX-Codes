#include<iostream>
#include<cstdio>
using namespace std;
long long n,i;
int main()
{
  freopen("fruit.in","r",stdin);
  freopen("fruit.out","w",stdout);
  cin>>i;
  if(n<=1)
    cout<<i;
  else
    cout<<-1;
  if(n<=2)
    cout<<i;
  else
    cout<<-1;
    if(n<=3)
    cout<<i;
  else
    cout<<-1;
    if(n<=4)
    cout<<i;
  else
    cout<<-1;
    if(n<=5)
    cout<<i;
  else
    cout<<-1;
