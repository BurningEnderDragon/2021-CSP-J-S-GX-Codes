#include<iostream>
#include<cstdio>
using namespace std;
int n,L,R;
int main()
{
  freopen("candy.in","r",stdin);
  freopen("candy.out","w",stdout);
  cin>>n>>L>>R;
  for(int i=1;i<=n;i++){
  if(R-L>=n)
    cout<<-1;
  else
    cout<<n;
}
return 0;
}

