#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    int n,L,R,k,max=0;
    cin >> n >> L >> R;
    if(R<L+n) R=R;
    else R=L+n;
    for( k=L;k<=R;k++){
        if(k%n>max) max=k%n;
    }
    cout << max;
}
