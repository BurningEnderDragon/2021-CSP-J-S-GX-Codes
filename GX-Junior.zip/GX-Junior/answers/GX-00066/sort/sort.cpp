#include<bits/stdc++.h>
using namespace std;
long long a[8005],b[8005],c[8005];
int main(){
    freopen("sort.in","r",stdin);
    freopen("sort.out","w",stdout);
    long long n,q;
    cin >> n >> q;
    for(int o=1;o<=n;o++){
        cin >> a[o];
        b[o]=o;
        c[o]=a[o];
    }
    for(int i = 1; i <= n; i++){
                for(int j = i; j>=2; j--){
                    if( c[j] < c[j-1] ){
                        int t = b[j-1];
                        b[j-1] = b[j];
                        b[j] = t;
                    }
                }
            }
    int y,v,d,p;
    for(int o=1;o<=q;o++){
        cin >> p;
        if(p==2){
            cin >> d;
            for(int m=1;m<=n;m++){
                if(b[m]==d){
                    cout << m << ' ';
                    break;
                }
            }
        }else{
            cin >> y >> v;
            a[y]=v;
            for(int i=1;i<=n;i++){
                b[i]=i;
                c[i]=a[i];
            }
        }
        for(int i = 1; i <= n; i++){
            for(int j = i; j>=2; j--){
                if( c[j] < c[j-1] ){
                    int t = b[j-1];
                    int h = c[j-1];
                    c[j-1] = c[j];
                    b[j-1] = b[j];
                    c[j] = h;
                    b[j] = t;
                }
            }
        }
    }
    return 0;
}
