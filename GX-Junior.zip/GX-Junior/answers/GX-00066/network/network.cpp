#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int n;
    cin >> n;
    char a[100][100],b[100][100];
    for(int i=0;i<n;i++) cin >> a[i]>> b[i];
}
