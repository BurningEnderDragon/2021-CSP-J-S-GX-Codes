#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("network.in","r",stdin);
    freopen("network.out","w",stdout);
    int n;
    cin>>n;
    string a[n];
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    for(int i=0;i<n;i++){
        cout<<"ERR";
    }
}
