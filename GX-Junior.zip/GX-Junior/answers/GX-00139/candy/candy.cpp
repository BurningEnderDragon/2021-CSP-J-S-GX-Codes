#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("candy.in","r",stdin);
    freopen("candy.out","w",stdout);
    long long int n,l,r,k=0;
    cin>>n>>l>>r;
    for(int i=l;i<r;i++){
        if(i%n>k){
            k=i;
        }
    }
    for(int i=n;i<r;i++){
        if(k>=n){
            k=k-n;
        }else if(k<=n){
            cout<<k+4;
            break;
        }
    }
}
